import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { Loader2, Package, Calendar, MapPin, Truck, Clock, Edit2, Check, X } from "lucide-react";
import type { OrderWithItems } from "@shared/schema";
import { PdfDownloadCard } from "@/components/PdfDownloadCard";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  confirmed: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  completed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

export default function MyOrdersPage() {
  const { isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [editingPickup, setEditingPickup] = useState<number | null>(null);
  const [newPickupDate, setNewPickupDate] = useState("");
  const [newPickupTime, setNewPickupTime] = useState("");

  const { data: orders, isLoading: ordersLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/my-orders"],
    enabled: isAuthenticated,
  });

  const updatePickupMutation = useMutation({
    mutationFn: async ({ id, scheduledPickupDate, scheduledPickupTime }: { id: number; scheduledPickupDate: string; scheduledPickupTime: string }) => {
      return await apiRequest(`/api/my-orders/${id}/pickup-schedule`, {
        method: "PATCH",
        body: JSON.stringify({ scheduledPickupDate, scheduledPickupTime }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-orders"] });
      toast({ title: "Updated", description: "Pickup schedule has been updated." });
      setEditingPickup(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update pickup schedule.", variant: "destructive" });
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);

  if (authLoading || ordersLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container px-4 py-8 md:px-6 md:py-12">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display" data-testid="text-page-title">Order History</h1>
            <p className="text-muted-foreground mt-2">View your past orders and their status</p>
          </div>

          <div className="mb-8">
            <PdfDownloadCard apiEndpoint="/api/my-orders/pdf" />
          </div>

          {orders && orders.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No orders yet</h3>
                <p className="text-muted-foreground mt-2">When you place an order, it will appear here.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {orders?.map((order) => (
                <Card key={order.id} data-testid={`order-card-${order.id}`}>
                  <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                    <div className="flex items-center gap-3">
                      <CardTitle className="text-lg">{order.orderRef || `Order #${order.id}`}</CardTitle>
                      <Badge className={statusColors[order.status]} data-testid={`order-status-${order.id}`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </Badge>
                    </div>
                    <span className="text-lg font-bold text-primary" data-testid={`order-total-${order.id}`}>
                      {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(order.totalAmount / 100)}
                    </span>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {order.pickupDate ? new Date(order.pickupDate).toLocaleDateString("en-US", {
                          weekday: "short",
                          month: "short",
                          day: "numeric",
                        }) : "Date TBD"}
                      </div>
                      <div className="flex items-center gap-1">
                        {order.isDelivery ? (
                          <>
                            <Truck className="h-4 w-4" />
                            Delivery
                          </>
                        ) : (
                          <>
                            <MapPin className="h-4 w-4" />
                            Pickup
                          </>
                        )}
                      </div>
                    </div>

                    {order.isDelivery && order.trackingNumber && (
                      <div className="flex items-center gap-2 text-sm bg-blue-50 dark:bg-blue-950/30 rounded-lg p-3 border border-blue-200 dark:border-blue-800" data-testid={`tracking-info-${order.id}`}>
                        <Package className="h-4 w-4 text-blue-600" />
                        <span className="font-medium">Tracking:</span>
                        <span>{order.trackingNumber}</span>
                      </div>
                    )}

                    {!order.isDelivery && order.scheduledPickupDate && (
                      <div className="space-y-2" data-testid={`pickup-info-${order.id}`}>
                        {editingPickup === order.id ? (
                          <div className="bg-muted/50 rounded-lg p-3 border space-y-3">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-primary" />
                              <span className="text-sm font-medium">Change Pickup Time</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <Label htmlFor={`edit-date-${order.id}`} className="text-xs">Date</Label>
                                <Input
                                  id={`edit-date-${order.id}`}
                                  type="date"
                                  value={newPickupDate}
                                  onChange={(e) => setNewPickupDate(e.target.value)}
                                  data-testid={`input-edit-pickup-date-${order.id}`}
                                />
                              </div>
                              <div>
                                <Label htmlFor={`edit-time-${order.id}`} className="text-xs">Time</Label>
                                <Input
                                  id={`edit-time-${order.id}`}
                                  type="time"
                                  value={newPickupTime}
                                  onChange={(e) => setNewPickupTime(e.target.value)}
                                  data-testid={`input-edit-pickup-time-${order.id}`}
                                />
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => updatePickupMutation.mutate({ id: order.id, scheduledPickupDate: newPickupDate, scheduledPickupTime: newPickupTime })}
                                disabled={!newPickupDate || !newPickupTime || updatePickupMutation.isPending}
                                data-testid={`button-save-pickup-${order.id}`}
                              >
                                {updatePickupMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Check className="h-3 w-3 mr-1" />}
                                Save
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => setEditingPickup(null)} data-testid={`button-cancel-pickup-${order.id}`}>
                                <X className="h-3 w-3 mr-1" /> Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between bg-green-50 dark:bg-green-950/30 rounded-lg p-3 border border-green-200 dark:border-green-800">
                            <div className="flex items-center gap-2 text-sm">
                              <Clock className="h-4 w-4 text-green-600" />
                              <span className="font-medium">Pickup:</span>
                              <span>{order.scheduledPickupDate}{order.scheduledPickupTime ? ` at ${order.scheduledPickupTime}` : ""}</span>
                            </div>
                            {(order.status === "pending" || order.status === "confirmed") && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-7 text-xs"
                                onClick={() => {
                                  setEditingPickup(order.id);
                                  setNewPickupDate(order.scheduledPickupDate || "");
                                  setNewPickupTime(order.scheduledPickupTime || "");
                                }}
                                data-testid={`button-change-pickup-${order.id}`}
                              >
                                <Edit2 className="h-3 w-3 mr-1" /> Change
                              </Button>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-2">Items:</h4>
                      <ul className="space-y-1 text-sm">
                        {order.items.map((item) => (
                          <li key={item.id} className="flex justify-between">
                            <span>{item.quantity}x {item.menuItem.name}</span>
                            <span className="text-muted-foreground">
                              {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format((item.price * item.quantity) / 100)}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
