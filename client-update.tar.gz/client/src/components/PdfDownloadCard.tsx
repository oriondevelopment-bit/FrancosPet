import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, FileText, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PdfDownloadCardProps {
  apiEndpoint: string;
  title?: string;
  description?: string;
}

export function PdfDownloadCard({ 
  apiEndpoint,
  title = "Download Purchase History",
  description = "Generate a PDF report of your orders for a specific date range"
}: PdfDownloadCardProps) {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isDownloading, setIsDownloading] = useState(false);
  const { toast } = useToast();

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const params = new URLSearchParams();
      if (startDate) params.append("startDate", startDate);
      if (endDate) params.append("endDate", endDate);
      
      const url = `${apiEndpoint}?${params.toString()}`;
      const response = await fetch(url, {
        credentials: "include",
      });
      
      if (!response.ok) {
        let errorMessage = "Failed to generate PDF";
        try {
          const error = await response.json();
          errorMessage = error.message || errorMessage;
        } catch {
          // Response wasn't JSON, use default message
        }
        throw new Error(errorMessage);
      }
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      
      const contentDisposition = response.headers.get("Content-Disposition");
      const filenameMatch = contentDisposition?.match(/filename="(.+)"/);
      link.download = filenameMatch ? filenameMatch[1] : "purchase-history.pdf";
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      
      toast({
        title: "Download Started",
        description: "Your PDF report is being downloaded.",
      });
    } catch (error: any) {
      toast({
        title: "Download Failed",
        description: error.message || "Failed to generate PDF report.",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const setQuickRange = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - days);
    setStartDate(start.toISOString().split("T")[0]);
    setEndDate(end.toISOString().split("T")[0]);
  };

  return (
    <Card data-testid="pdf-download-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {title}
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setQuickRange(30)}
            data-testid="button-last-30-days"
          >
            Last 30 Days
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setQuickRange(90)}
            data-testid="button-last-90-days"
          >
            Last 90 Days
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setQuickRange(365)}
            data-testid="button-last-year"
          >
            Last Year
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => { setStartDate(""); setEndDate(""); }}
            data-testid="button-all-time"
          >
            All Time
          </Button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="startDate">Start Date</Label>
            <Input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              data-testid="input-start-date"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="endDate">End Date</Label>
            <Input
              id="endDate"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              data-testid="input-end-date"
            />
          </div>
        </div>
        
        <Button 
          onClick={handleDownload} 
          disabled={isDownloading}
          className="w-full"
          data-testid="button-download-pdf"
        >
          {isDownloading ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating PDF...</>
          ) : (
            <><Download className="mr-2 h-4 w-4" /> Download PDF Report</>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
