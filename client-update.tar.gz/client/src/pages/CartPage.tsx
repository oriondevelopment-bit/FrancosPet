import { useCart, ShippingRate, AppliedPromo } from "@/lib/CartContext";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Link } from "wouter";
import { Minus, Plus, Trash2, ArrowRight, Truck, Package, RefreshCw, Loader2, AlertCircle, Store, Tag, X } from "lucide-react";
import { motion } from "framer-motion";
import { useState, useEffect, useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function CartPage() {
  const { 
    items, 
    removeFromCart, 
    updateQuantity, 
    toggleAutoRenewal,
    isDelivery, 
    toggleDelivery, 
    deliveryFee, 
    shippingFee,
    subtotal, 
    total,
    hasPetTreats,
    hasFoodItems,
    hasAutoRenewal,
    selectedShippingRate,
    setSelectedShippingRate,
    petTreatPickup,
    setPetTreatPickup,
    petTreatQuantity,
    qualifiesForFreeShipping,
    appliedPromo,
    setAppliedPromo,
    discountAmount,
  } = useCart();

  const [shippingRates, setShippingRates] = useState<ShippingRate[]>([]);
  const [shippingLoading, setShippingLoading] = useState(false);
  const [shippingErrors, setShippingErrors] = useState<string[]>([]);
  const [shippingZip, setShippingZip] = useState("");
  const [shippingState, setShippingState] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [promoInput, setPromoInput] = useState("");
  const [promoLoading, setPromoLoading] = useState(false);
  const [promoError, setPromoError] = useState("");

  const applyPromoCode = async () => {
    if (!promoInput.trim()) return;
    setPromoLoading(true);
    setPromoError("");
    try {
      const response = await fetch(`/api/promotions/validate/${encodeURIComponent(promoInput.trim().toUpperCase())}`);
      if (!response.ok) {
        setPromoError("Invalid or expired promo code");
        setPromoLoading(false);
        return;
      }
      const promo = await response.json();
      if (promo && promo.id) {
        setAppliedPromo({
          code: promo.code || promoInput.trim().toUpperCase(),
          title: promo.title,
          discountType: promo.discountType,
          discountValue: promo.discountValue,
        });
        setPromoInput("");
      } else {
        setPromoError("Invalid or expired promo code");
      }
    } catch {
      setPromoError("Could not validate promo code");
    }
    setPromoLoading(false);
  };

  const fetchShippingRates = useCallback(async () => {
    if (!shippingZip || shippingZip.length < 5) return;
    
    setShippingLoading(true);
    setShippingErrors([]);
    setHasSearched(true);
    setSelectedShippingRate(null);
    
    try {
      const response = await apiRequest("/api/shipping-rates", {
        method: "POST",
        body: JSON.stringify({
          destinationZip: shippingZip,
          destinationState: shippingState,
          destinationCity: shippingCity,
          quantity: petTreatQuantity,
          subtotalCents: subtotal,
        }),
      });
      
      const data = await response.json();
      setShippingRates(data.rates || []);
      setShippingErrors(data.errors || []);
      
      if (data.rates?.length > 0) {
        setSelectedShippingRate(data.rates[0]);
      }
    } catch (err) {
      console.error("Error fetching shipping rates:", err);
      setShippingErrors(["Unable to fetch shipping rates. Please try again."]);
    } finally {
      setShippingLoading(false);
    }
  }, [shippingZip, shippingState, shippingCity, petTreatQuantity, setSelectedShippingRate]);

  useEffect(() => {
    if (!hasPetTreats) {
      setShippingRates([]);
      setHasSearched(false);
      setSelectedShippingRate(null);
    }
  }, [hasPetTreats]);

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const getCategoryIcon = (category: string) => {
    if (category === 'pet_treats') return <Package className="h-6 w-6 text-primary" />;
    return null;
  };

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12 max-w-4xl mx-auto">
        <h1 className="mb-8 text-4xl font-bold font-display">Your Order</h1>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed p-12 text-center bg-white/50">
            <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">Looks like you haven't added anything yet.</p>
            <Link href="/">
              <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90">
                Browse Menu
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center gap-4 rounded-2xl bg-white dark:bg-gray-800 p-4 shadow-sm border border-border"
                >
                  <div className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-xl bg-orange-50 dark:bg-orange-950/30 text-2xl">
                    {getCategoryIcon(item.category) || (
                      <span className="text-sm font-medium text-muted-foreground">{item.category === 'pizza' ? 'Pizza' : 'Sauce'}</span>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-foreground font-display text-lg">{item.name}</h3>
                    {item.description && (
                      <p className="text-sm text-muted-foreground truncate" data-testid={`cart-item-description-${item.id}`}>
                        {item.description}
                      </p>
                    )}
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-primary font-medium">{formatPrice(item.price)}</p>
                      {item.category === 'pet_treats' && item.isAutoRenewal && (
                        <span className="inline-flex items-center gap-1 text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                          <RefreshCw className="h-3 w-3" /> Monthly
                        </span>
                      )}
                    </div>
                    {item.category === 'pet_treats' && (
                      <button
                        onClick={() => toggleAutoRenewal(item.id)}
                        className="text-xs text-muted-foreground hover:text-primary mt-1 underline"
                        data-testid={`toggle-renewal-cart-${item.id}`}
                      >
                        {item.isAutoRenewal ? "Remove auto-renewal" : "Add monthly auto-renewal"}
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center rounded-lg border bg-background">
                      <button 
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-2 text-muted-foreground hover:text-foreground"
                        data-testid={`btn-decrease-${item.id}`}
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-8 text-center font-medium" data-testid={`qty-${item.id}`}>{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-2 text-muted-foreground hover:text-foreground"
                        data-testid={`btn-increase-${item.id}`}
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                      data-testid={`btn-remove-${item.id}`}
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="rounded-3xl bg-white dark:bg-gray-800 p-6 shadow-lg border border-border/50 sticky top-24">
                <h3 className="text-xl font-bold mb-6 font-display">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-medium">{formatPrice(subtotal)}</span>
                  </div>
                  
                  {hasFoodItems && (
                    <div className="flex items-center justify-between rounded-xl bg-orange-50 dark:bg-orange-950/30 p-4 border border-orange-100 dark:border-orange-800">
                      <div className="flex items-center gap-3">
                        <Truck className="h-5 w-5 text-primary" />
                        <div>
                          <span className="block text-sm font-medium text-foreground">Local Delivery</span>
                          <span className="block text-xs text-muted-foreground">Within town limits (+$5.00)</span>
                        </div>
                      </div>
                      <Switch 
                        checked={isDelivery} 
                        onCheckedChange={toggleDelivery} 
                        className="data-[state=checked]:bg-primary"
                        data-testid="switch-delivery"
                      />
                    </div>
                  )}
                  
                  {isDelivery && hasFoodItems && (
                    <div className="flex justify-between text-sm text-primary animate-in slide-in-from-top-2 fade-in">
                      <span>Delivery Fee</span>
                      <span>{formatPrice(deliveryFee)}</span>
                    </div>
                  )}

                  {hasPetTreats && !qualifiesForFreeShipping && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between rounded-xl bg-blue-50 dark:bg-blue-950/30 p-4 border border-blue-100 dark:border-blue-800">
                        <div className="flex items-center gap-3">
                          <Store className="h-5 w-5 text-blue-600" />
                          <div>
                            <span className="block text-sm font-medium text-foreground">Pick Up Locally</span>
                            <span className="block text-xs text-muted-foreground">Free - 313 S. Merrill Ave, Glendive</span>
                          </div>
                        </div>
                        <Switch
                          checked={petTreatPickup}
                          onCheckedChange={(checked) => {
                            setPetTreatPickup(checked);
                            if (checked) {
                              setSelectedShippingRate(null);
                            }
                          }}
                          className="data-[state=checked]:bg-blue-600"
                          data-testid="switch-pet-pickup"
                        />
                      </div>

                      {!petTreatPickup && (
                        <div className="rounded-xl bg-blue-50 dark:bg-blue-950/30 p-4 border border-blue-100 dark:border-blue-800 space-y-3">
                          <div className="flex items-center gap-2">
                            <Package className="h-5 w-5 text-blue-600" />
                            <span className="text-sm font-medium text-foreground">Ship to Me</span>
                          </div>
                          
                          <p className="text-xs text-muted-foreground">Enter your ZIP code to see shipping rates. Orders $50+ ship free!</p>
                          
                          <div className="flex gap-2">
                            <input
                              type="text"
                              placeholder="ZIP Code"
                              value={shippingZip}
                              onChange={(e) => setShippingZip(e.target.value.replace(/\D/g, "").slice(0, 5))}
                              className="flex-1 rounded-lg border px-3 py-2 text-sm bg-background"
                              maxLength={5}
                              data-testid="input-shipping-zip-cart"
                            />
                            <Button
                              size="sm"
                              onClick={fetchShippingRates}
                              disabled={shippingZip.length < 5 || shippingLoading}
                              data-testid="btn-get-rates"
                            >
                              {shippingLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Get Rates"}
                            </Button>
                          </div>
                          
                          {shippingErrors.length > 0 && (
                            <div className="text-xs text-amber-600 flex items-center gap-1">
                              <AlertCircle className="h-3 w-3" />
                              {shippingErrors[0]}
                            </div>
                          )}

                          {shippingLoading && (
                            <div className="flex items-center justify-center py-3">
                              <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                              <span className="ml-2 text-sm text-muted-foreground">Fetching rates...</span>
                            </div>
                          )}

                          {!shippingLoading && shippingRates.length > 0 && (
                            <div className="space-y-2">
                              {shippingRates.map((rate) => (
                                <button
                                  key={rate.serviceCode}
                                  onClick={() => setSelectedShippingRate(rate)}
                                  className={`w-full text-left rounded-lg border p-3 transition-colors ${
                                    selectedShippingRate?.serviceCode === rate.serviceCode
                                      ? "border-primary bg-primary/5 ring-1 ring-primary"
                                      : "border-border hover:border-primary/50"
                                  }`}
                                  data-testid={`shipping-option-${rate.serviceCode}`}
                                >
                                  <div className="flex justify-between items-start gap-2">
                                    <div>
                                      <span className="text-sm font-medium text-foreground">{rate.service}</span>
                                      <span className="block text-xs text-muted-foreground">{rate.estimatedDays}</span>
                                    </div>
                                    <span className="text-sm font-bold text-foreground whitespace-nowrap">{formatPrice(rate.price)}</span>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}

                          {!shippingLoading && hasSearched && shippingRates.length === 0 && shippingErrors.length === 0 && (
                            <p className="text-xs text-muted-foreground">No shipping rates found. Please verify your ZIP code.</p>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {hasPetTreats && qualifiesForFreeShipping && (
                    <div className="rounded-xl bg-green-50 dark:bg-green-950/30 p-4 border border-green-100 dark:border-green-800">
                      <div className="flex items-center gap-2">
                        <Truck className="h-5 w-5 text-green-600" />
                        <div>
                          <span className="block text-sm font-medium text-foreground">Free Shipping</span>
                          <span className="block text-xs text-muted-foreground">Your order qualifies for free shipping ($50+)</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {shippingFee > 0 && selectedShippingRate && (
                    <div className="flex justify-between text-sm text-blue-600 animate-in slide-in-from-top-2 fade-in">
                      <span className="flex items-center gap-1">
                        Shipping ({selectedShippingRate.carrier})
                      </span>
                      <span>{formatPrice(shippingFee)}</span>
                    </div>
                  )}

                  <div className="space-y-3 border-t pt-4 mt-4">
                    <div className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-foreground">Promo Code</span>
                    </div>
                    {appliedPromo ? (
                      <div className="flex items-center justify-between rounded-lg bg-green-50 dark:bg-green-950/30 px-3 py-2 border border-green-200 dark:border-green-800">
                        <div>
                          <span className="text-sm font-medium text-green-700 dark:text-green-300">{appliedPromo.code}</span>
                          <span className="block text-xs text-green-600 dark:text-green-400">
                            {appliedPromo.title} — {appliedPromo.discountType === 'percentage' ? `${appliedPromo.discountValue}% off` : `$${(appliedPromo.discountValue / 100).toFixed(2)} off`}
                          </span>
                        </div>
                        <button
                          onClick={() => setAppliedPromo(null)}
                          className="p-1 text-green-600 hover:text-red-500 transition-colors"
                          data-testid="btn-remove-promo"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Enter code"
                            value={promoInput}
                            onChange={(e) => { setPromoInput(e.target.value.toUpperCase()); setPromoError(""); }}
                            onKeyDown={(e) => { if (e.key === "Enter") applyPromoCode(); }}
                            className="flex-1 rounded-lg border px-3 py-2 text-sm bg-background uppercase"
                            data-testid="input-promo-code"
                          />
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={applyPromoCode}
                            disabled={!promoInput.trim() || promoLoading}
                            data-testid="btn-apply-promo"
                          >
                            {promoLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Apply"}
                          </Button>
                        </div>
                        {promoError && (
                          <p className="text-xs text-red-500 flex items-center gap-1">
                            <AlertCircle className="h-3 w-3" /> {promoError}
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {discountAmount > 0 && (
                    <div className="flex justify-between text-sm text-green-600 animate-in slide-in-from-top-2 fade-in">
                      <span>Discount</span>
                      <span>-{formatPrice(discountAmount)}</span>
                    </div>
                  )}

                  <div className="border-t pt-4 mt-4">
                    <div className="flex justify-between items-end">
                      <span className="text-lg font-bold">Total</span>
                      <span className="text-2xl font-bold text-primary font-display">{formatPrice(total)}</span>
                    </div>
                  </div>
                </div>

                <Link href="/checkout">
                  <Button 
                    className="w-full rounded-xl py-6 text-lg font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 bg-primary hover:bg-primary/90"
                    disabled={hasPetTreats && !qualifiesForFreeShipping && !petTreatPickup && !selectedShippingRate}
                    data-testid="btn-checkout"
                  >
                    Checkout <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                {hasPetTreats && !qualifiesForFreeShipping && !petTreatPickup && !selectedShippingRate && (
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    Select a shipping option or pick up locally to continue
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t bg-muted/30 py-12 mt-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">&copy; 2026 Franco's Pet Store. All Rights Reserved.</p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Pet Store, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>.
            </p>
            <p>
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/environmental" className="text-primary underline hover:text-primary/80">Environmental Initiative</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
