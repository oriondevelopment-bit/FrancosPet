import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, X, Smartphone } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function InstallAppPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isInStandaloneMode = window.matchMedia("(display-mode: standalone)").matches || 
                               (window.navigator as any).standalone === true;
    
    setIsIOS(isIOSDevice);
    setIsStandalone(isInStandaloneMode);

    const wasDismissed = localStorage.getItem("install-prompt-dismissed");
    if (wasDismissed) {
      setDismissed(true);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowPrompt(true);
    };

    window.addEventListener("beforeinstallprompt", handler);

    if (isIOSDevice && !isInStandaloneMode && !wasDismissed) {
      setShowPrompt(true);
    }

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setShowPrompt(false);
      }
      setDeferredPrompt(null);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setDismissed(true);
    localStorage.setItem("install-prompt-dismissed", "true");
  };

  if (!isAuthenticated || isStandalone || dismissed || !showPrompt) {
    return null;
  }

  return (
    <Card className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80 z-50 shadow-lg border-primary/20" data-testid="card-install-prompt">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-full bg-primary/10">
            <Smartphone className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-sm mb-1">Add to Home Screen</h3>
            {isIOS ? (
              <p className="text-xs text-muted-foreground mb-3">
                Tap the share button <span className="inline-block px-1 bg-muted rounded">↑</span> then "Add to Home Screen" for quick access.
              </p>
            ) : (
              <p className="text-xs text-muted-foreground mb-3">
                Install our app for faster ordering and easy access from your home screen.
              </p>
            )}
            <div className="flex gap-2">
              {!isIOS && deferredPrompt && (
                <Button size="sm" onClick={handleInstall} data-testid="button-install-app">
                  <Download className="h-4 w-4 mr-1" />
                  Install
                </Button>
              )}
              <Button size="sm" variant="ghost" onClick={handleDismiss} data-testid="button-dismiss-install">
                {isIOS ? "Got it" : "Not now"}
              </Button>
            </div>
          </div>
          <Button size="icon" variant="ghost" className="h-6 w-6" onClick={handleDismiss} data-testid="button-close-install">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
