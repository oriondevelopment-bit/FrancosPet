import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, Thermometer, Snowflake } from "lucide-react";

export default function NutritionPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl font-bold text-center mb-2">Ingredients & Nutrition</h1>
        <p className="text-center text-muted-foreground mb-8">12" Take & Bake Pizza</p>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Nutrition Facts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">About 6 servings per container</p>
                <p className="text-sm text-muted-foreground mb-4">Serving size: 1/6 Pizza (139g)</p>
                
                <div className="bg-muted/50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-2xl font-bold">Calories</span>
                    <span className="text-3xl font-bold">330</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Amount per serving</p>
                </div>

                <Separator className="my-4" />

                <div className="space-y-3">
                  <p className="text-sm font-medium text-right">% Daily Value*</p>
                  
                  <div className="flex justify-between">
                    <span><strong>Total Fat</strong> 16g</span>
                    <span className="font-medium">21%</span>
                  </div>
                  <div className="flex justify-between pl-4 text-sm">
                    <span>Saturated Fat 7g</span>
                    <span>36%</span>
                  </div>
                  <div className="flex justify-between pl-4 text-sm">
                    <span>Trans Fat 0g</span>
                    <span></span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between">
                    <span><strong>Cholesterol</strong> 40mg</span>
                    <span className="font-medium">14%</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between">
                    <span><strong>Sodium</strong> 1010mg</span>
                    <span className="font-medium">44%</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between">
                    <span><strong>Total Carbohydrate</strong> 28g</span>
                    <span className="font-medium">10%</span>
                  </div>
                  <div className="flex justify-between pl-4 text-sm">
                    <span>Dietary Fiber 2g</span>
                    <span>8%</span>
                  </div>
                  <div className="flex justify-between pl-4 text-sm">
                    <span>Total Sugars 3g</span>
                    <span></span>
                  </div>
                  <div className="flex justify-between pl-6 text-sm">
                    <span>Includes 1g Added Sugars</span>
                    <span>3%</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between">
                    <span><strong>Protein</strong> 16g</span>
                    <span className="font-medium">36%</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex justify-between">
                      <span>Vitamin D 0.2mcg</span>
                      <span>1%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Calcium 240mg</span>
                      <span>20%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Iron 2.4mg</span>
                      <span>15%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Potassium 270mg</span>
                      <span>6%</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground mt-4">
                  *The % Daily Value (DV) tells you how much a nutrient in a serving of food contributes to a daily diet. 2,000 calories a day is used for general nutrition advice.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Ingredients</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1">Crust</h3>
                <p className="text-sm text-muted-foreground">
                  Enriched wheat flour (flour, niacin, iron), water, olive oil, yeast, sea salt.
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold mb-1">Cheese</h3>
                <p className="text-sm text-muted-foreground">
                  Low moisture part skim mozzarella (cultured pasteurized part skim milk, salt, enzymes), potato starch or corn starch or powdered cellulose (to prevent caking), natamycin (a natural mold inhibitor).
                </p>
                <p className="text-sm font-medium text-orange-600 dark:text-orange-400 mt-1">Contains: Milk</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold mb-1">Sauce</h3>
                <p className="text-sm text-muted-foreground">
                  California non-GMO tomatoes, sea salt, olive oil, granulated garlic, granulated onion, basil, oregano, citric acid (added as preservative).
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold mb-1">Pork Sausage</h3>
                <p className="text-sm text-muted-foreground">
                  Pork, sea salt, paprika, granulated garlic, granulated onion, basil, oregano.
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold mb-1">Beef Topping</h3>
                <p className="text-sm text-muted-foreground">
                  Ground beef, sea salt, paprika, granulated garlic, granulated onion, basil, oregano.
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold mb-1">Pepperoni</h3>
                <p className="text-sm text-muted-foreground">
                  Pork, beef, salt, contains 2% or less of water, paprika, granulated garlic, sodium nitrite, lactic acid, starter culture, citric acid.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                Safe Handling Instructions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                This product was prepared from inspected and passed meat and/or poultry. Some food products may contain bacteria that could cause illness if the product is mishandled or cooked improperly. For your protection, follow these safe handling instructions:
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Snowflake className="h-4 w-4 mt-0.5 text-blue-500 shrink-0" />
                  <span>Keep refrigerated or frozen. Thaw in refrigerator or microwave.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="h-4 w-4 mt-0.5 shrink-0 text-center font-bold text-muted-foreground">•</span>
                  <span>Keep raw meat and poultry separate from other foods. Wash working surfaces (including cutting boards), utensils, and hands after touching raw meat or poultry.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Thermometer className="h-4 w-4 mt-0.5 text-red-500 shrink-0" />
                  <span>Cook thoroughly to an internal temperature of 160°F.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="h-4 w-4 mt-0.5 shrink-0 text-center font-bold text-muted-foreground">•</span>
                  <span>Keep hot foods hot. Refrigerate leftovers immediately or discard.</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Thermometer className="h-5 w-5 text-red-500" />
                Cooking Instructions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3 text-sm list-decimal list-inside">
                <li>Preheat oven to <strong>425°F</strong>.</li>
                <li>Remove pizza from overwrap and cardboard. Place on center oven rack.</li>
                <li>Cook pizza to an internal temperature of <strong>160°F</strong>. Bake pizza for <strong>14-16 minutes</strong> or until cheese is melted and lightly browned.</li>
                <li>Let stand <strong>3-5 minutes</strong> before enjoying.</li>
              </ol>
            </CardContent>
          </Card>

          <div className="text-center text-sm text-muted-foreground space-y-1">
            <p>Net Wt. 29 oz. (1 lb. 13 oz.) | Keep Frozen</p>
            <p>Franco's Pet Store | Glendive, MT</p>
            <p>FrancosKitchens@Gmail.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}
