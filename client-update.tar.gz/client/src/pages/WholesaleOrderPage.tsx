import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Loader2, Minus, Plus, Truck, MapPin, Calendar, Wallet, CheckCircle, AlertCircle } from "lucide-react";
import type { WholesaleCustomer, MenuItem } from "@shared/schema";

interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}

export default function WholesaleOrderPage() {
  const { isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isDelivery, setIsDelivery] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryDistance, setDeliveryDistance] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<"paypal" | "venmo" | "cash_app">("paypal");

  const { data: wholesaleProfile, isLoading: profileLoading } = useQuery<WholesaleCustomer>({
    queryKey: ["/api/wholesale/profile"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: menuItems, isLoading: menuLoading } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu"],
  });

  useEffect(() => {
    if (wholesaleProfile) {
      setDeliveryAddress(`${wholesaleProfile.address}, ${wholesaleProfile.city}, ${wholesaleProfile.state} ${wholesaleProfile.zipCode}`);
    }
  }, [wholesaleProfile]);

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: {
      items: { menuItemId: number; quantity: number }[];
      isDelivery: boolean;
      deliveryAddress: string | null;
      pickupDate: string;
      totalAmount: number;
      paymentMethod: string;
      deliveryDistance: number | null;
    }) => {
      return await apiRequest("/api/wholesale/orders", {
        method: "POST",
        body: JSON.stringify(orderData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wholesale/orders"] });
      toast({ title: "Order Placed", description: "Your wholesale order has been submitted." });
      setLocation("/wholesale");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);

  useEffect(() => {
    if (wholesaleProfile && !wholesaleProfile.isApproved) {
      setLocation("/wholesale");
    }
  }, [wholesaleProfile, setLocation]);

  if (authLoading || profileLoading || menuLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !wholesaleProfile?.isApproved) {
    return null;
  }

  const pizzas = menuItems?.filter(item => item.category === "pizza") || [];
  const sauces = menuItems?.filter(item => item.category === "sauce") || [];

  const updateQuantity = (menuItem: MenuItem, delta: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.menuItem.id === menuItem.id);
      if (existing) {
        const newQuantity = existing.quantity + delta;
        if (newQuantity <= 0) {
          return prev.filter(item => item.menuItem.id !== menuItem.id);
        }
        return prev.map(item => 
          item.menuItem.id === menuItem.id 
            ? { ...item, quantity: newQuantity }
            : item
        );
      } else if (delta > 0) {
        return [...prev, { menuItem, quantity: delta }];
      }
      return prev;
    });
  };

  const getQuantity = (menuItemId: number) => {
    return cart.find(item => item.menuItem.id === menuItemId)?.quantity || 0;
  };

  const totalUnits = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + (item.menuItem.price * item.quantity), 0);
  
  const isFreeDelivery = totalUnits >= 100 && deliveryDistance <= 25;
  const deliveryFee = isDelivery && !isFreeDelivery ? 500 : 0;
  const total = subtotal + deliveryFee;

  // Calculate pickup date: 2 weeks from now
  const pickupDate = new Date();
  pickupDate.setDate(pickupDate.getDate() + 14);
  const formattedPickupDate = pickupDate.toDateString();

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const handleSubmitOrder = () => {
    if (cart.length === 0) {
      toast({ title: "Empty Cart", description: "Please add items to your order.", variant: "destructive" });
      return;
    }

    createOrderMutation.mutate({
      items: cart.map(item => ({ menuItemId: item.menuItem.id, quantity: item.quantity })),
      isDelivery,
      deliveryAddress: isDelivery ? deliveryAddress : null,
      pickupDate: pickupDate.toISOString(),
      totalAmount: subtotal,
      paymentMethod,
      deliveryDistance: isDelivery ? deliveryDistance : null,
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navigation />
      <main className="container px-4 py-8 md:px-6 md:py-12 max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold font-display" data-testid="text-page-title">
            Wholesale Bulk Order
          </h1>
          <p className="text-muted-foreground mt-2">
            Ordering for: {wholesaleProfile.businessName}
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pizzas</CardTitle>
                <CardDescription>Cheese $12 • Specialty $14</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                  {pizzas.map(pizza => (
                    <div key={pizza.id} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`item-${pizza.id}`}>
                      <div>
                        <p className="font-medium">{pizza.name}</p>
                        <p className="text-sm text-muted-foreground">{formatPrice(pizza.price)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(pizza, -1)}
                          disabled={getQuantity(pizza.id) === 0}
                          data-testid={`btn-minus-${pizza.id}`}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-12 text-center font-medium" data-testid={`qty-${pizza.id}`}>
                          {getQuantity(pizza.id)}
                        </span>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(pizza, 1)}
                          data-testid={`btn-plus-${pizza.id}`}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sauces</CardTitle>
                <CardDescription>Marinara $9 • Alfredo $10 • Blue Cheese $14</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                  {sauces.map(sauce => (
                    <div key={sauce.id} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`item-${sauce.id}`}>
                      <div>
                        <p className="font-medium">{sauce.name}</p>
                        <p className="text-sm text-muted-foreground">{formatPrice(sauce.price)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(sauce, -1)}
                          disabled={getQuantity(sauce.id) === 0}
                          data-testid={`btn-minus-${sauce.id}`}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-12 text-center font-medium" data-testid={`qty-${sauce.id}`}>
                          {getQuantity(sauce.id)}
                        </span>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(sauce, 1)}
                          data-testid={`btn-plus-${sauce.id}`}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Truck className="h-5 w-5" /> Delivery Options
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="delivery-toggle" className="font-medium">Request Delivery</Label>
                    <p className="text-sm text-muted-foreground">
                      Free for 100+ units within 25 miles, otherwise +$5
                    </p>
                  </div>
                  <Switch
                    id="delivery-toggle"
                    checked={isDelivery}
                    onCheckedChange={setIsDelivery}
                    data-testid="switch-delivery"
                  />
                </div>

                {isDelivery && (
                  <div className="space-y-4 pt-4 border-t animate-in slide-in-from-top-2">
                    <div className="grid gap-2">
                      <Label htmlFor="deliveryAddress">Delivery Address</Label>
                      <Input
                        id="deliveryAddress"
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="Enter delivery address"
                        data-testid="input-delivery-address"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="deliveryDistance">Distance from Pickup Location (miles)</Label>
                      <Input
                        id="deliveryDistance"
                        type="number"
                        min={0}
                        max={100}
                        value={deliveryDistance}
                        onChange={(e) => setDeliveryDistance(Number(e.target.value))}
                        placeholder="Enter distance in miles"
                        data-testid="input-delivery-distance"
                      />
                      <p className="text-xs text-muted-foreground">
                        Pickup location: 313 S. Merrill Ave, Glendive, MT 59330
                      </p>
                    </div>

                    {totalUnits >= 100 && deliveryDistance <= 25 && (
                      <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <span className="text-green-800 dark:text-green-200 font-medium">
                          Free delivery! (100+ units within 25 miles)
                        </span>
                      </div>
                    )}

                    {isDelivery && (totalUnits < 100 || deliveryDistance > 25) && (
                      <div className="flex items-center gap-2 p-3 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                        <AlertCircle className="h-5 w-5 text-yellow-600" />
                        <span className="text-yellow-800 dark:text-yellow-200 text-sm">
                          {totalUnits < 100 
                            ? `Add ${100 - totalUnits} more units for free delivery within 25 miles`
                            : "Delivery outside 25 miles - $5 delivery fee applies"}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" /> Payment Method
                </CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={(val) => setPaymentMethod(val as any)} className="grid gap-3">
                  <Label className="flex items-center justify-between rounded-lg border p-4 cursor-pointer hover:bg-muted/50 [&:has(:checked)]:border-primary">
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="paypal" id="paypal" />
                      <span className="font-medium">PayPal</span>
                    </div>
                  </Label>
                  <Label className="flex items-center justify-between rounded-lg border p-4 cursor-pointer hover:bg-muted/50 [&:has(:checked)]:border-primary">
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="venmo" id="venmo" />
                      <span className="font-medium">Venmo</span>
                    </div>
                  </Label>
                  <Label className="flex items-center justify-between rounded-lg border p-4 cursor-pointer hover:bg-muted/50 [&:has(:checked)]:border-primary">
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value="cash_app" id="cash_app" />
                      <span className="font-medium">Cash App</span>
                    </div>
                  </Label>
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div className="text-sm">
                    <p className="font-medium">Pickup/Delivery Date</p>
                    <p className="text-muted-foreground">{formattedPickupDate}</p>
                    <p className="text-xs text-muted-foreground">(2 weeks from today)</p>
                  </div>
                </div>

                {cart.length > 0 ? (
                  <div className="space-y-2">
                    {cart.map(item => (
                      <div key={item.menuItem.id} className="flex justify-between text-sm">
                        <span>{item.menuItem.name} x{item.quantity}</span>
                        <span>{formatPrice(item.menuItem.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No items in order
                  </p>
                )}

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Total Units</span>
                    <Badge variant="secondary">{totalUnits}</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  {isDelivery && (
                    <div className="flex justify-between text-sm">
                      <span>Delivery</span>
                      <span className={isFreeDelivery ? "text-green-600 font-medium" : ""}>
                        {isFreeDelivery ? "FREE" : formatPrice(deliveryFee)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold pt-2 border-t">
                    <span>Total</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                </div>

                <Button
                  className="w-full"
                  size="lg"
                  onClick={handleSubmitOrder}
                  disabled={cart.length === 0 || createOrderMutation.isPending}
                  data-testid="button-submit-order"
                >
                  {createOrderMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Placing Order...
                    </>
                  ) : (
                    "Place Wholesale Order"
                  )}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  By placing this order, you agree to pay via your selected payment method
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
