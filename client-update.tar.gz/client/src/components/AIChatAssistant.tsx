import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send, Loader2, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const PET_AVATARS = {
  kitten: {
    idle: "😺",
    talking: "😸",
    happy: "😻",
    waving: "🐱",
    sleeping: "😿",
  },
  puppy: {
    idle: "🐶",
    talking: "🐕",
    happy: "🐾",
    waving: "🐕‍🦺",
    sleeping: "😴",
  },
};

const GREETING_MESSAGES = [
  "Hi there! I'm Frankie! 🐾 Need help finding something yummy?",
  "Woof! Welcome to Franco's Pet Store! Can I help you today?",
  "Hey friend! 😸 Looking for treats for your furry pal? I can help!",
  "Purrfect timing! I'm Frankie, your shopping buddy! 🛒",
];

const NUDGE_MESSAGES = [
  "Psst... still here if you need me! 🐾",
  "Don't forget — our treats are paw-some! 😸",
  "Need help finding something? I'm all ears! 🐶",
  "Our freeze-dried treats are the best! Want to learn more? 🐾",
];

function SpeechBubble({ text, isVisible }: { text: string; isVisible: boolean }) {
  if (!isVisible) return null;
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 10 }}
        className="absolute bottom-full right-0 mb-2 w-56 md:w-64"
        data-testid="speech-bubble"
      >
        <div className="relative bg-card border rounded-2xl rounded-br-sm px-4 py-3 shadow-lg">
          <p className="text-sm text-foreground leading-relaxed">{text}</p>
          <div className="absolute -bottom-2 right-4 w-4 h-4 bg-card border-r border-b transform rotate-45" />
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

export function AIChatAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [petMood, setPetMood] = useState<"idle" | "talking" | "happy" | "waving" | "sleeping">("waving");
  const [petType] = useState<"kitten" | "puppy">(() => Math.random() > 0.5 ? "kitten" : "puppy");
  const [speechBubble, setSpeechBubble] = useState("");
  const [showBubble, setShowBubble] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const nudgeTimerRef = useRef<NodeJS.Timeout | null>(null);
  const greetingShownRef = useRef(false);
  const [, navigate] = useLocation();

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("frankie-dismissed");
    if (dismissed) {
      setIsDismissed(true);
      return;
    }

    const greetTimer = setTimeout(() => {
      if (!greetingShownRef.current && !isOpen) {
        greetingShownRef.current = true;
        const greeting = GREETING_MESSAGES[Math.floor(Math.random() * GREETING_MESSAGES.length)];
        setSpeechBubble(greeting);
        setShowBubble(true);
        setPetMood("waving");

        setTimeout(() => {
          setShowBubble(false);
          setPetMood("idle");
        }, 6000);
      }
    }, 3000);

    return () => clearTimeout(greetTimer);
  }, [isOpen]);

  useEffect(() => {
    if (isDismissed || isOpen) return;

    nudgeTimerRef.current = setInterval(() => {
      const nudge = NUDGE_MESSAGES[Math.floor(Math.random() * NUDGE_MESSAGES.length)];
      setSpeechBubble(nudge);
      setShowBubble(true);
      setPetMood("waving");

      setTimeout(() => {
        setShowBubble(false);
        setPetMood("idle");
      }, 5000);
    }, 45000);

    return () => {
      if (nudgeTimerRef.current) clearInterval(nudgeTimerRef.current);
    };
  }, [isDismissed, isOpen]);

  const sendMessage = async (directMessage?: string) => {
    const userMessage = (directMessage || input).trim();
    if (!userMessage || isStreaming) return;
    setInput("");

    const newMessages: ChatMessage[] = [...messages, { role: "user", content: userMessage }];
    setMessages(newMessages);
    setIsStreaming(true);
    setPetMood("talking");

    try {
      const response = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMessage,
          conversationHistory: newMessages.slice(-10),
        }),
      });

      if (!response.ok) throw new Error("Failed to get response");

      const reader = response.body?.getReader();
      if (!reader) throw new Error("No reader");

      const decoder = new TextDecoder();
      let assistantContent = "";
      let buffer = "";

      setMessages((prev) => [...prev, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.content) {
              assistantContent += data.content;
              setMessages((prev) => {
                const updated = [...prev];
                updated[updated.length - 1] = { role: "assistant", content: assistantContent };
                return updated;
              });
            }
            if (data.done) {
              const linkMatch = assistantContent.match(/\/(menu|pet-store|wholesale|cart|why-freeze-dried|environmental|giving-back|contact|our-story)/);
              if (linkMatch) {
                setPetMood("happy");
              }
            }
          } catch {}
        }
      }

      setPetMood("happy");
      setTimeout(() => setPetMood("idle"), 2000);
    } catch {
      setMessages((prev) => [
        ...prev.slice(0, -1),
        { role: "assistant", content: "Oops! Something went wrong. Could you try again? 🐾" },
      ]);
      setPetMood("idle");
    } finally {
      setIsStreaming(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsOpen(false);
    setShowBubble(false);
    sessionStorage.setItem("frankie-dismissed", "true");
  };

  const handleOpen = () => {
    setIsOpen(true);
    setShowBubble(false);
    setPetMood("happy");
    setTimeout(() => {
      inputRef.current?.focus();
      setPetMood("idle");
    }, 300);
  };

  const handleLinkClick = (url: string) => {
    navigate(url);
    setIsOpen(false);
  };

  const renderMessageContent = (content: string) => {
    const parts = content.split(/(\/(menu|pet-store|wholesale|cart|why-freeze-dried|environmental|giving-back|contact|our-story|profile|my-orders))/g);
    const result: (string | JSX.Element)[] = [];
    let i = 0;

    while (i < parts.length) {
      const part = parts[i];
      if (part && part.startsWith("/") && ["/menu", "/pet-store", "/wholesale", "/cart", "/why-freeze-dried", "/environmental", "/giving-back", "/contact", "/our-story", "/profile", "/my-orders"].includes(part)) {
        result.push(
          <button
            key={i}
            onClick={() => handleLinkClick(part)}
            className="text-primary underline hover:text-primary/80 font-medium"
            data-testid={`link-${part.slice(1)}`}
          >
            {part}
          </button>
        );
        i += 2;
      } else {
        if (part) result.push(part);
        i++;
      }
    }

    return result;
  };

  if (isDismissed) {
    return (
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-4 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors"
        onClick={() => {
          setIsDismissed(false);
          sessionStorage.removeItem("frankie-dismissed");
          handleOpen();
        }}
        data-testid="button-reopen-frankie"
      >
        <MessageCircle className="h-5 w-5" />
      </motion.button>
    );
  }

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-20 right-4 z-50 w-[340px] md:w-[380px] rounded-2xl border bg-background shadow-2xl flex flex-col"
            style={{ maxHeight: "min(500px, 70vh)" }}
            data-testid="ai-chat-window"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b bg-primary/5 rounded-t-2xl">
              <div className="flex items-center gap-2">
                <span className="text-2xl" role="img" aria-label="pet avatar">
                  {PET_AVATARS[petType][petMood]}
                </span>
                <div>
                  <h3 className="font-bold text-sm text-foreground" data-testid="text-frankie-name">Frankie</h3>
                  <p className="text-[10px] text-muted-foreground">Your shopping buddy</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className="px-2 text-muted-foreground"
                  onClick={() => setIsOpen(false)}
                  data-testid="button-minimize-chat"
                >
                  <span className="text-lg">−</span>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="px-2 text-destructive"
                  onClick={handleDismiss}
                  data-testid="button-close-chat"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3 min-h-[200px]">
              {messages.length === 0 && (
                <div className="text-center py-6">
                  <span className="text-4xl mb-2 block" role="img" aria-label="pet wave">
                    {PET_AVATARS[petType].happy}
                  </span>
                  <p className="text-sm text-muted-foreground mb-3">
                    Hi! I'm Frankie, your personal shopping buddy! Ask me anything about our pizzas, sauces, pet treats, or how to order!
                  </p>
                  <div className="flex flex-wrap gap-1.5 justify-center">
                    {[
                      "What's on the menu?",
                      "Tell me about pet treats",
                      "How do I order?",
                      "Do you deliver?",
                    ].map((q) => (
                      <button
                        key={q}
                        onClick={() => sendMessage(q)}
                        className="text-xs px-2.5 py-1.5 rounded-full border bg-muted/50 hover:bg-muted text-foreground transition-colors"
                        data-testid={`quick-q-${q.replace(/\s+/g, "-").replace(/[?']/g, "").toLowerCase()}`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}
                    data-testid={`chat-msg-${msg.role}-${i}`}
                  >
                    {msg.role === "assistant" ? (
                      <span>{renderMessageContent(msg.content)}</span>
                    ) : (
                      msg.content
                    )}
                    {msg.role === "assistant" && msg.content === "" && isStreaming && (
                      <span className="inline-flex gap-1">
                        <span className="animate-bounce text-xs">●</span>
                        <span className="animate-bounce text-xs" style={{ animationDelay: "0.1s" }}>●</span>
                        <span className="animate-bounce text-xs" style={{ animationDelay: "0.2s" }}>●</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="px-3 py-2.5 border-t bg-muted/20">
              <div className="flex items-center gap-2">
                <Input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask Frankie anything..."
                  className="flex-1 h-9 text-sm rounded-full"
                  disabled={isStreaming}
                  data-testid="input-chat-message"
                />
                <Button
                  size="icon"
                  className="h-9 w-9 rounded-full flex-shrink-0"
                  onClick={() => sendMessage()}
                  disabled={!input.trim() || isStreaming}
                  data-testid="button-send-chat"
                >
                  {isStreaming ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!isOpen && (
        <div className="fixed bottom-4 right-4 z-50">
          <SpeechBubble text={speechBubble} isVisible={showBubble} />
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleOpen}
            className="relative flex h-16 w-16 items-center justify-center rounded-full bg-primary shadow-lg hover:shadow-xl transition-shadow"
            data-testid="button-open-frankie"
          >
            <motion.span
              animate={{
                y: [0, -3, 0],
                rotate: [0, -5, 5, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3,
              }}
              className="text-3xl"
              role="img"
              aria-label="pet avatar"
            >
              {PET_AVATARS[petType][petMood]}
            </motion.span>
            {messages.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white ring-2 ring-background">
                {messages.filter((m) => m.role === "assistant").length}
              </span>
            )}
          </motion.button>
        </div>
      )}
    </>
  );
}
