import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Package,
  Truck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Printer,
  ClipboardList,
  Box,
  MapPin,
  RefreshCw,
  BarChart3,
  Layers,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  StickyNote,
} from "lucide-react";

const formatPrice = (cents: number) => `$${(cents / 100).toFixed(2)}`;

const STAGE_CONFIG: Record<string, { label: string; color: string; bgColor: string; icon: any; action: string }> = {
  pending: { label: "New Orders", color: "text-gray-700", bgColor: "bg-gray-50 border-gray-200", icon: Clock, action: "Confirm Order" },
  confirmed: { label: "To Pick", color: "text-blue-700", bgColor: "bg-blue-50 border-blue-200", icon: ClipboardList, action: "Start Picking" },
  picking: { label: "Picking", color: "text-amber-700", bgColor: "bg-amber-50 border-amber-200", icon: Package, action: "Done Picking" },
  packing: { label: "Packing", color: "text-orange-700", bgColor: "bg-orange-50 border-orange-200", icon: Box, action: "Done Packing" },
  label_ready: { label: "Label Ready", color: "text-purple-700", bgColor: "bg-purple-50 border-purple-200", icon: Printer, action: "Ready to Ship" },
  ready_to_ship: { label: "Ready to Ship", color: "text-indigo-700", bgColor: "bg-indigo-50 border-indigo-200", icon: Truck, action: "Mark Shipped" },
  ready_for_pickup: { label: "Ready for Pickup", color: "text-green-700", bgColor: "bg-green-50 border-green-200", icon: MapPin, action: "Mark Picked Up" },
  shipped: { label: "Shipped", color: "text-emerald-700", bgColor: "bg-emerald-50 border-emerald-200", icon: CheckCircle2, action: "" },
  picked_up: { label: "Picked Up", color: "text-emerald-700", bgColor: "bg-emerald-50 border-emerald-200", icon: CheckCircle2, action: "" },
};

function getTimeColor(minutes: number): string {
  if (minutes < 30) return "text-green-600";
  if (minutes < 60) return "text-amber-600";
  return "text-red-600";
}

function formatTimeAgo(minutes: number): string {
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ${minutes % 60}m ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function OrderCard({ order, onAdvance, onCreateLabel, onUpdateNotes }: {
  order: any;
  onAdvance: (orderId: number, notes?: string, employeeName?: string) => void;
  onCreateLabel: (orderId: number) => void;
  onUpdateNotes: (orderId: number, notes: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [noteText, setNoteText] = useState(order.fulfillmentNotes || "");

  const stage = STAGE_CONFIG[order.fulfillmentStatus] || STAGE_CONFIG.confirmed;
  const StageIcon = stage.icon;
  const isDelivery = order.isDelivery;
  const isFinal = order.fulfillmentStatus === "shipped" || order.fulfillmentStatus === "picked_up";

  const itemsSummary = order.items
    ?.map((i: any) => `${i.quantity}x ${i.menuItem?.name || i.customItemName || "Item"}`)
    .join(", ") || "No items";

  return (
    <Card className={`border ${stage.bgColor} transition-all hover:shadow-md`} data-testid={`fulfillment-card-${order.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm" data-testid={`order-ref-${order.id}`}>
                {order.orderRef || `#${order.id}`}
              </span>
              {isDelivery ? (
                <Badge variant="outline" className="bg-blue-100 text-blue-700 text-xs border-blue-300">
                  <Truck className="h-3 w-3 mr-1" /> Delivery
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-green-100 text-green-700 text-xs border-green-300">
                  <MapPin className="h-3 w-3 mr-1" /> Pickup
                </Badge>
              )}
              {order.isSubscriptionOrder && (
                <Badge variant="outline" className="bg-purple-100 text-purple-700 text-xs border-purple-300">
                  <RefreshCw className="h-3 w-3 mr-1" /> Subscription
                </Badge>
              )}
              {order.batchGroup && (
                <Badge variant="outline" className="bg-cyan-100 text-cyan-700 text-xs border-cyan-300">
                  <Layers className="h-3 w-3 mr-1" /> {order.batchGroup}
                </Badge>
              )}
            </div>

            <p className="text-sm text-gray-600 mt-1 truncate">{order.customerName}</p>
            <p className="text-xs text-gray-500 truncate">{itemsSummary}</p>

            <div className="flex items-center gap-3 mt-2 text-xs">
              <span className={`font-medium ${getTimeColor(order.minutesInStage || 0)}`}>
                <Clock className="h-3 w-3 inline mr-1" />
                {formatTimeAgo(order.minutesInStage || 0)}
              </span>
              <span className="text-gray-500 font-medium">{formatPrice(order.totalAmount)}</span>
              {order.estimate && (
                <span className="text-gray-400" title="Estimated time remaining">
                  ~{order.estimate.totalEstimatedMinutes}m left
                </span>
              )}
            </div>

            {order.trackingNumber && (
              <p className="text-xs text-blue-600 mt-1">
                Tracking: {order.trackingNumber}
              </p>
            )}

            {order.fulfillmentNotes && (
              <p className="text-xs text-amber-700 mt-1 italic">
                <StickyNote className="h-3 w-3 inline mr-1" />
                {order.fulfillmentNotes}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1">
            {!isFinal && stage.action && (
              <Button
                size="sm"
                className="text-xs whitespace-nowrap"
                onClick={() => onAdvance(order.id)}
                data-testid={`btn-advance-${order.id}`}
              >
                {stage.action}
                <ArrowRight className="h-3 w-3 ml-1" />
              </Button>
            )}
            {order.fulfillmentStatus === "packing" && isDelivery && (
              <Button
                size="sm"
                variant="outline"
                className="text-xs whitespace-nowrap border-purple-300 text-purple-700 hover:bg-purple-50"
                onClick={() => onCreateLabel(order.id)}
                data-testid={`btn-create-label-${order.id}`}
              >
                <Printer className="h-3 w-3 mr-1" /> Print Label
              </Button>
            )}
            {order.shippingLabelUrl && (
              <Button
                size="sm"
                variant="outline"
                className="text-xs"
                onClick={() => window.open(order.shippingLabelUrl, "_blank")}
                data-testid={`btn-view-label-${order.id}`}
              >
                <ExternalLink className="h-3 w-3 mr-1" /> Label
              </Button>
            )}
          </div>
        </div>

        <div className="flex gap-1 mt-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs h-6 px-2"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            Details
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs h-6 px-2"
            onClick={() => setShowNotes(!showNotes)}
          >
            <StickyNote className="h-3 w-3 mr-1" /> Notes
          </Button>
        </div>

        {expanded && (
          <div className="mt-2 pt-2 border-t border-gray-200 text-xs space-y-1">
            <p><strong>Email:</strong> {order.customerEmail}</p>
            <p><strong>Phone:</strong> {order.customerPhone}</p>
            {isDelivery && order.deliveryAddress && (
              <p><strong>Ship to:</strong> {order.deliveryAddress}</p>
            )}
            <p><strong>Order date:</strong> {new Date(order.createdAt).toLocaleDateString()}</p>
            {order.pickupDate && (
              <p><strong>{isDelivery ? "Ship by" : "Pickup"}:</strong> {new Date(order.pickupDate).toLocaleDateString()}</p>
            )}
            <div className="mt-1">
              <strong>Items:</strong>
              <ul className="ml-4 list-disc">
                {order.items?.map((item: any, idx: number) => (
                  <li key={idx}>
                    {item.quantity}x {item.menuItem?.name || item.customItemName || "Item"} — {formatPrice(item.price * item.quantity)}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {showNotes && (
          <div className="mt-2 pt-2 border-t border-gray-200">
            <Textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Internal fulfillment notes..."
              className="text-xs h-16"
              data-testid={`notes-input-${order.id}`}
            />
            <Button
              size="sm"
              variant="outline"
              className="mt-1 text-xs"
              onClick={() => {
                onUpdateNotes(order.id, noteText);
                setShowNotes(false);
              }}
              data-testid={`btn-save-notes-${order.id}`}
            >
              Save Notes
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StageColumn({ stage, orders, onAdvance, onCreateLabel, onUpdateNotes }: {
  stage: string;
  orders: any[];
  onAdvance: (orderId: number, notes?: string, employeeName?: string) => void;
  onCreateLabel: (orderId: number) => void;
  onUpdateNotes: (orderId: number, notes: string) => void;
}) {
  const config = STAGE_CONFIG[stage];
  if (!config) return null;
  const StageIcon = config.icon;

  return (
    <div className="flex-1 min-w-[280px]" data-testid={`stage-column-${stage}`}>
      <div className={`rounded-t-lg px-3 py-2 border ${config.bgColor} flex items-center justify-between`}>
        <div className="flex items-center gap-2">
          <StageIcon className={`h-4 w-4 ${config.color}`} />
          <span className={`font-semibold text-sm ${config.color}`}>{config.label}</span>
        </div>
        <Badge variant="secondary" className="text-xs">{orders.length}</Badge>
      </div>
      <div className="space-y-2 p-2 bg-gray-50/50 rounded-b-lg border border-t-0 border-gray-200 min-h-[100px] max-h-[600px] overflow-y-auto">
        {orders.length === 0 ? (
          <p className="text-xs text-gray-400 text-center py-8">No orders</p>
        ) : (
          orders.map((order: any) => (
            <OrderCard
              key={order.id}
              order={order}
              onAdvance={onAdvance}
              onCreateLabel={onCreateLabel}
              onUpdateNotes={onUpdateNotes}
            />
          ))
        )}
      </div>
    </div>
  );
}

export function FulfillmentTab() {
  const { toast } = useToast();
  const [filter, setFilter] = useState<"all" | "delivery" | "pickup" | "subscription">("all");
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [labelModal, setLabelModal] = useState<{ orderId: number; open: boolean }>({ orderId: 0, open: false });
  const [selectedService, setSelectedService] = useState("");
  const [confirmModal, setConfirmModal] = useState<{ orderId: number; open: boolean; action: string }>({ orderId: 0, open: false, action: "" });
  const [confirmNotes, setConfirmNotes] = useState("");
  const [confirmEmployee, setConfirmEmployee] = useState("");

  const { data: fulfillmentData, isLoading } = useQuery<{
    stages: Record<string, any[]>;
    counts: Record<string, number>;
  }>({
    queryKey: ["/api/admin/fulfillment"],
    refetchInterval: 30000,
  });

  const { data: analyticsData } = useQuery<any>({
    queryKey: ["/api/admin/fulfillment/analytics"],
    enabled: showAnalytics,
  });

  const { data: batchData } = useQuery<any>({
    queryKey: ["/api/admin/fulfillment/batch-suggestions"],
    refetchInterval: 60000,
  });

  const { data: shippingRec, isLoading: recLoading } = useQuery<any>({
    queryKey: ["/api/admin/fulfillment/shipping-recommendation", labelModal.orderId],
    enabled: labelModal.open && labelModal.orderId > 0,
  });

  const advanceMutation = useMutation({
    mutationFn: async ({ orderId, notes, employeeName }: { orderId: number; notes?: string; employeeName?: string }) => {
      const res = await apiRequest("POST", `/api/admin/orders/${orderId}/advance`, { notes, employeeName });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Order Advanced", description: `Moved to ${STAGE_CONFIG[data.newStatus]?.label || data.newStatus}` });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fulfillment"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const createLabelMutation = useMutation({
    mutationFn: async ({ orderId, serviceCode }: { orderId: number; serviceCode: string }) => {
      const res = await apiRequest("POST", `/api/admin/orders/${orderId}/create-label`, { serviceCode });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Label Created", description: `Tracking: ${data.trackingNumber}` });
      setLabelModal({ orderId: 0, open: false });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fulfillment"] });
    },
    onError: (err: any) => {
      toast({ title: "Label Error", description: err.message, variant: "destructive" });
    },
  });

  const notesMutation = useMutation({
    mutationFn: async ({ orderId, notes }: { orderId: number; notes: string }) => {
      const res = await apiRequest("POST", `/api/admin/orders/${orderId}/fulfillment-notes`, { notes });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Notes saved" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fulfillment"] });
    },
  });

  const handleAdvance = (orderId: number) => {
    setConfirmModal({ orderId, open: true, action: "" });
    setConfirmNotes("");
    setConfirmEmployee("");
  };

  const confirmAdvance = () => {
    advanceMutation.mutate({
      orderId: confirmModal.orderId,
      notes: confirmNotes || undefined,
      employeeName: confirmEmployee || undefined,
    });
    setConfirmModal({ orderId: 0, open: false, action: "" });
  };

  const handleCreateLabel = (orderId: number) => {
    setLabelModal({ orderId, open: true });
    setSelectedService("");
  };

  const handleUpdateNotes = (orderId: number, notes: string) => {
    notesMutation.mutate({ orderId, notes });
  };

  const filterOrders = (orders: any[]) => {
    if (filter === "all") return orders;
    if (filter === "delivery") return orders.filter((o: any) => o.isDelivery);
    if (filter === "pickup") return orders.filter((o: any) => !o.isDelivery);
    if (filter === "subscription") return orders.filter((o: any) => o.isSubscriptionOrder);
    return orders;
  };

  const stages = fulfillmentData?.stages || {};
  const counts = fulfillmentData?.counts || {};

  const activeStages = ["pending", "confirmed", "picking", "packing"];
  const shippingStages = ["label_ready", "ready_to_ship", "ready_for_pickup"];
  const completedStages = ["shipped", "picked_up"];

  const totalActive = activeStages.reduce((sum, s) => sum + (counts[s] || 0), 0);
  const totalShipping = shippingStages.reduce((sum, s) => sum + (counts[s] || 0), 0);
  const totalComplete = completedStages.reduce((sum, s) => sum + (counts[s] || 0), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
        <span className="ml-2 text-gray-500">Loading fulfillment pipeline...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="fulfillment-tab">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-semibold">Fulfillment Pipeline</h2>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={(v) => setFilter(v as any)}>
            <SelectTrigger className="w-[140px] h-8 text-xs" data-testid="filter-fulfillment">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Orders</SelectItem>
              <SelectItem value="delivery">Delivery Only</SelectItem>
              <SelectItem value="pickup">Pickup Only</SelectItem>
              <SelectItem value="subscription">Subscriptions</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="sm"
            className="text-xs"
            onClick={() => setShowAnalytics(!showAnalytics)}
            data-testid="btn-toggle-analytics"
          >
            <BarChart3 className="h-3 w-3 mr-1" />
            {showAnalytics ? "Hide" : "Show"} Analytics
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-xs"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/fulfillment"] })}
            data-testid="btn-refresh-fulfillment"
          >
            <RefreshCw className="h-3 w-3 mr-1" /> Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-blue-700" data-testid="count-active">{totalActive}</p>
            <p className="text-xs text-blue-600">In Progress</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 bg-purple-50/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-purple-700" data-testid="count-shipping">{totalShipping}</p>
            <p className="text-xs text-purple-600">Ready / Shipping</p>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-green-700" data-testid="count-complete">{totalComplete}</p>
            <p className="text-xs text-green-600">Completed (7d)</p>
          </CardContent>
        </Card>
      </div>

      {batchData && batchData.batches?.length > 0 && (
        <Card className="border-cyan-200 bg-cyan-50/50">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <Layers className="h-4 w-4 text-cyan-700" />
              <span className="font-semibold text-sm text-cyan-700">Batch Picking Suggestions</span>
              <Badge variant="secondary" className="text-xs">
                ~{batchData.batches.reduce((sum: number, b: any) => sum + b.estimatedTimeSaved, 0)}min saved
              </Badge>
            </div>
            <div className="space-y-1">
              {batchData.batches.map((batch: any) => (
                <div key={batch.batchId} className="text-xs text-cyan-800 bg-white/60 rounded px-2 py-1">
                  <strong>{batch.batchId}</strong>: {batch.orderIds.length} orders share{" "}
                  {batch.sharedItems.map((s: any) => `${s.name} (${s.totalQuantity})`).join(", ")}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-6">
        <div>
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">Active</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {activeStages.map((stage) => (
              <StageColumn
                key={stage}
                stage={stage}
                orders={filterOrders(stages[stage] || [])}
                onAdvance={handleAdvance}
                onCreateLabel={handleCreateLabel}
                onUpdateNotes={handleUpdateNotes}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">Shipping & Pickup</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {shippingStages.map((stage) => (
              <StageColumn
                key={stage}
                stage={stage}
                orders={filterOrders(stages[stage] || [])}
                onAdvance={handleAdvance}
                onCreateLabel={handleCreateLabel}
                onUpdateNotes={handleUpdateNotes}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">Completed (Last 7 Days)</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {completedStages.map((stage) => (
              <StageColumn
                key={stage}
                stage={stage}
                orders={filterOrders(stages[stage] || [])}
                onAdvance={handleAdvance}
                onCreateLabel={handleCreateLabel}
                onUpdateNotes={handleUpdateNotes}
              />
            ))}
          </div>
        </div>
      </div>

      {showAnalytics && analyticsData && (
        <Card className="border-gray-200" data-testid="analytics-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="h-5 w-5" /> Fulfillment Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold">{analyticsData.totalShipments}</p>
                <p className="text-xs text-gray-500">Total Shipments</p>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold">{formatPrice(analyticsData.avgCostPerShipment)}</p>
                <p className="text-xs text-gray-500">Avg Cost/Shipment</p>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold">{formatPrice(analyticsData.totalCost)}</p>
                <p className="text-xs text-gray-500">Total Shipping Cost</p>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold capitalize">{analyticsData.costTrend}</p>
                <p className="text-xs text-gray-500">Cost Trend</p>
              </div>
            </div>

            {analyticsData.serviceBreakdown?.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-semibold mb-2">Service Breakdown</h4>
                <div className="space-y-1">
                  {analyticsData.serviceBreakdown.map((s: any) => (
                    <div key={s.service} className="flex items-center justify-between text-xs bg-gray-50 rounded px-3 py-2">
                      <span className="font-medium">{s.service}</span>
                      <div className="flex gap-4">
                        <span>{s.count} shipments</span>
                        <span>Avg: {formatPrice(s.avgCost)}</span>
                        <span>Total: {formatPrice(s.totalCost)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {analyticsData.topRegions?.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-semibold mb-2">Top Destination Regions</h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {analyticsData.topRegions.map((r: any) => (
                    <div key={r.zipPrefix} className="text-center text-xs bg-gray-50 rounded p-2">
                      <p className="font-bold">{r.zipPrefix}xx</p>
                      <p>{r.count} orders</p>
                      <p>Avg: {formatPrice(r.avgCost)}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {analyticsData.avgStageMinutes?.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2">Average Stage Times</h4>
                <div className="flex flex-wrap gap-2">
                  {analyticsData.avgStageMinutes.map((s: any) => (
                    <div key={s.stage} className="text-xs bg-gray-50 rounded px-3 py-2">
                      <span className="font-medium capitalize">{s.stage.replace(/_/g, " ")}</span>
                      <span className="ml-2 text-gray-600">{s.avgMinutes}min avg ({s.count} records)</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {analyticsData.totalShipments === 0 && (
              <p className="text-sm text-gray-400 text-center py-4">
                No shipping data yet. Analytics will populate as you process delivery orders.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={confirmModal.open} onOpenChange={(open) => setConfirmModal({ ...confirmModal, open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Stage Advance</DialogTitle>
            <DialogDescription>
              Move order to the next fulfillment stage. Optionally add notes.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium">Your Name (optional)</label>
              <Input
                value={confirmEmployee}
                onChange={(e) => setConfirmEmployee(e.target.value)}
                placeholder="Employee name"
                data-testid="input-employee-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Notes (optional)</label>
              <Textarea
                value={confirmNotes}
                onChange={(e) => setConfirmNotes(e.target.value)}
                placeholder="Any notes about this step..."
                className="h-20"
                data-testid="input-confirm-notes"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmModal({ orderId: 0, open: false, action: "" })}>
              Cancel
            </Button>
            <Button onClick={confirmAdvance} disabled={advanceMutation.isPending} data-testid="btn-confirm-advance">
              {advanceMutation.isPending ? "Advancing..." : "Confirm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={labelModal.open} onOpenChange={(open) => setLabelModal({ ...labelModal, open })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Shipping Label</DialogTitle>
            <DialogDescription>
              Select a USPS service to create a label and get a tracking number.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="bg-gray-50 rounded-lg p-3 text-sm">
              <p className="font-semibold">From: Franco's Pet Store</p>
              <p className="text-gray-600">313 S. Merrill Ave, Glendive, MT 59330</p>
            </div>

            {recLoading ? (
              <div className="flex items-center justify-center py-4">
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                <span className="text-sm text-gray-500">Loading shipping rates...</span>
              </div>
            ) : shippingRec?.allRates?.length > 0 ? (
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Shipping Service</label>
                {shippingRec.allRates.map((rate: any) => {
                  const isRecommended = shippingRec.recommended?.serviceCode === rate.serviceCode;
                  return (
                    <div
                      key={rate.serviceCode}
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        selectedService === rate.serviceCode
                          ? "border-blue-500 bg-blue-50"
                          : isRecommended
                          ? "border-green-300 bg-green-50/50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setSelectedService(rate.serviceCode)}
                      data-testid={`shipping-option-${rate.serviceCode}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-medium text-sm">{rate.serviceName}</span>
                          {isRecommended && (
                            <Badge className="ml-2 bg-green-100 text-green-700 text-xs">
                              Recommended — saves {formatPrice(shippingRec.savingsVsExpensive)}
                            </Badge>
                          )}
                        </div>
                        <span className="font-bold">{formatPrice(rate.price)}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{rate.estimatedDays}</p>
                    </div>
                  );
                })}
                {shippingRec.confidence && shippingRec.confidence !== "none" && (
                  <p className="text-xs text-gray-500">
                    ML confidence: {shippingRec.confidence} (based on {shippingRec.confidence === "high" ? "20+" : "5+"} historical shipments to this region)
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <AlertTriangle className="h-6 w-6 text-amber-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">
                  Could not load shipping rates. Make sure ShipStation is connected in Settings.
                </p>
                <div className="mt-3">
                  <label className="text-sm font-medium">Manual Service Code</label>
                  <Input
                    value={selectedService}
                    onChange={(e) => setSelectedService(e.target.value)}
                    placeholder="e.g., usps_priority_mail"
                    className="mt-1"
                  />
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLabelModal({ orderId: 0, open: false })}>
              Cancel
            </Button>
            <Button
              onClick={() => createLabelMutation.mutate({ orderId: labelModal.orderId, serviceCode: selectedService })}
              disabled={!selectedService || createLabelMutation.isPending}
              data-testid="btn-confirm-create-label"
            >
              {createLabelMutation.isPending ? "Creating Label..." : "Create Label & Get Tracking"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
