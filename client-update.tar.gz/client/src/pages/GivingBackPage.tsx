import { Navigation } from "@/components/Navigation";
import { PetStoreSubNav } from "@/components/PetStoreSubNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  Heart, PawPrint, ChevronRight, Globe, HandHeart,
  ShieldCheck, Sparkles, Users
} from "lucide-react";
import montanaBadge from "@assets/montana-badge_1772867253604.png";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.4 },
});

export default function GivingBackPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      <PetStoreSubNav />

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 via-background to-primary/10 dark:from-green-500/5 dark:via-background dark:to-primary/5" />
          <div className="container relative px-4 py-16 md:py-24 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <motion.div {...fadeUp(0)} className="mb-6">
                <HandHeart className="h-12 w-12 mx-auto text-green-600 dark:text-green-400 mb-4" />
              </motion.div>
              <motion.h1
                {...fadeUp(0.1)}
                className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-5xl font-display"
                data-testid="heading-giving-back"
              >
                Giving Back
              </motion.h1>
              <motion.p
                {...fadeUp(0.15)}
                className="mx-auto max-w-2xl text-xl text-primary font-medium italic font-display"
                data-testid="text-hero-subtitle"
              >
                Every Purchase Makes a Difference
              </motion.p>
              <motion.p
                {...fadeUp(0.2)}
                className="mx-auto max-w-2xl text-lg text-muted-foreground leading-relaxed mt-4"
              >
                At Franco's Pet Store, we believe the world can be a better place through giving back and service to our community and all living things. That's why a portion of every pet product purchase goes directly to charitable organizations making a real difference.
              </motion.p>
            </div>
          </div>
        </section>

        <section className="container px-4 md:px-6 pb-16">
          <div className="mx-auto max-w-4xl">

            <motion.div {...fadeUp(0.3)} className="flex flex-col md:flex-row items-center gap-8 mb-16">
              <img
                src={petStoreLogo}
                alt="Franco's Pet Store Premium Pet Treats"
                className="w-36 h-36 md:w-44 md:h-44 rounded-2xl object-cover shadow-md flex-shrink-0"
                data-testid="img-giving-back-hero"
              />
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-our-mission">
                  Our Mission: Nourish, Protect, Give Back
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  When you buy our premium freeze-dried treats, you're not just giving your pet the healthiest food on the market — you're helping fund local charities, animal welfare programs, and community initiatives. We've built giving into the very foundation of our business because we believe that doing well and doing good should never be separate things.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  Through our wholesale partnership program, a percentage of every sale is donated to the charity of each partner's choice. It's simple, transparent, and designed to create real impact right here in Montana and across the communities we serve.
                </p>
              </div>
            </motion.div>

            <motion.div {...fadeUp(0.35)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3" data-testid="heading-how-it-works">
                How Every Purchase Gives Back
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                Our donation program is woven into every transaction, not tacked on as an afterthought.
              </p>

              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    icon: Heart,
                    title: "Built-In Donations",
                    desc: "A portion of every pet product sale is automatically set aside for charitable giving. No extra cost to you — it's just how we do business.",
                    color: "text-red-500",
                  },
                  {
                    icon: Users,
                    title: "Partner Choice",
                    desc: "Our wholesale partners choose the charity closest to their heart. From food banks to animal shelters, the impact goes where it matters most.",
                    color: "text-blue-500",
                  },
                  {
                    icon: Globe,
                    title: "Community First",
                    desc: "We prioritize local and regional charities because the best way to change the world is to start right where you live.",
                    color: "text-green-500",
                  },
                  {
                    icon: ShieldCheck,
                    title: "Full Transparency",
                    desc: "Every dollar donated is tracked and reported. Our partners can see exactly how much their sales have generated for their chosen cause.",
                    color: "text-purple-500",
                  },
                  {
                    icon: Sparkles,
                    title: "Growing Impact",
                    desc: "As our family of partners grows, so does the total amount we give back. Every new partnership multiplies the good we can do together.",
                    color: "text-amber-500",
                  },
                  {
                    icon: HandHeart,
                    title: "All Living Things",
                    desc: "Our commitment extends to every creature. We support charities that serve people, animals, and the natural world we all share.",
                    color: "text-teal-500",
                  },
                ].map((item, i) => (
                  <Card key={i} className="border bg-card hover:shadow-md transition-shadow" data-testid={`card-giving-${i}`}>
                    <CardContent className="pt-6">
                      <item.icon className={`h-8 w-8 ${item.color} mb-3`} />
                      <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div
              {...fadeUp(0.4)}
              className="bg-gradient-to-br from-primary/5 via-muted/40 to-green-500/5 dark:from-primary/10 dark:via-muted/20 dark:to-green-500/10 rounded-2xl p-8 md:p-10 text-center border"
              data-testid="section-cta"
            >
              <PawPrint className="h-10 w-10 mx-auto text-primary mb-4" />
              <h2 className="text-2xl font-bold text-foreground font-display mb-3">
                Shop With Purpose
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto mb-6 leading-relaxed">
                Every bag of Franco's Pet Store freeze-dried treats is a choice — for your pet's health, for the planet, and for the communities that need our help. Join us in making a difference, one treat at a time.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/pet-store">
                  <Button size="lg" className="gap-2" data-testid="button-shop-treats">
                    <PawPrint className="h-5 w-5" /> Shop Pet Treats
                  </Button>
                </Link>
                <Link href="/environmental">
                  <Button size="lg" variant="outline" className="gap-2" data-testid="button-environmental">
                    Our Environmental Initiative <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-8">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto text-center text-sm text-muted-foreground space-y-4">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">Franco's Pet Store. All Rights Reserved.</p>
            <p>
              <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link>
              {" · "}
              <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>
              {" · "}
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
