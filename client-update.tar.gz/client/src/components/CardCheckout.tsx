import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, Lock, Loader2, CheckCircle, AlertCircle } from "lucide-react";

interface CardCheckoutProps {
  amount: string;
  onPaymentSuccess: (transactionId: string) => void;
  onPaymentError: (error: string) => void;
  disabled?: boolean;
  firstName?: string;
  lastName?: string;
  email?: string;
}

function formatCardNumber(value: string) {
  return value.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
}

function formatExpiry(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2);
  return digits;
}

export default function CardCheckout({
  amount,
  onPaymentSuccess,
  onPaymentError,
  disabled = false,
  firstName,
  lastName,
  email,
}: CardCheckoutProps) {
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (disabled || isProcessing || paymentComplete) return;

    setError(null);
    setIsProcessing(true);

    try {
      const rawCard = cardNumber.replace(/\s/g, "");
      const [expMonth, expYear] = expiry.split("/");
      if (!rawCard || rawCard.length < 13 || !expMonth || !expYear || expYear.length < 2) {
        throw new Error("Please enter valid card details");
      }

      const expirationDate = `20${expYear.slice(-2)}-${expMonth.padStart(2, "0")}`;

      const response = await fetch("/authnet/charge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cardNumber: rawCard,
          expirationDate,
          cardCode: cvv,
          amount,
          firstName,
          lastName,
          email,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Payment declined");
      }

      setPaymentComplete(true);
      onPaymentSuccess(data.transactionId);
    } catch (err: any) {
      const msg = err.message || "Payment failed. Please try again.";
      setError(msg);
      onPaymentError(msg);
    } finally {
      setIsProcessing(false);
    }
  };

  if (paymentComplete) {
    return (
      <div className="flex items-center justify-center gap-2 p-4 bg-green-50 dark:bg-green-950 rounded-xl border border-green-200 dark:border-green-800">
        <CheckCircle className="h-5 w-5 text-green-600" />
        <span className="font-medium text-green-800 dark:text-green-200">Payment Verified</span>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-4 bg-muted/40 rounded-xl border space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <CreditCard className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Credit or Debit Card</span>
          <Lock className="h-3 w-3 text-muted-foreground ml-auto" />
          <span className="text-xs text-muted-foreground">Secure</span>
        </div>

        <div className="space-y-1">
          <Label htmlFor="cardNumber" className="text-sm">Card Number</Label>
          <Input
            id="cardNumber"
            data-testid="input-card-number"
            placeholder="1234 5678 9012 3456"
            value={cardNumber}
            onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
            inputMode="numeric"
            autoComplete="cc-number"
            maxLength={19}
            required
            disabled={isProcessing}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label htmlFor="expiry" className="text-sm">Expiration</Label>
            <Input
              id="expiry"
              data-testid="input-card-expiry"
              placeholder="MM/YY"
              value={expiry}
              onChange={(e) => setExpiry(formatExpiry(e.target.value))}
              inputMode="numeric"
              autoComplete="cc-exp"
              maxLength={5}
              required
              disabled={isProcessing}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="cvv" className="text-sm">CVV</Label>
            <Input
              id="cvv"
              data-testid="input-card-cvv"
              placeholder="123"
              value={cvv}
              onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
              inputMode="numeric"
              autoComplete="cc-csc"
              maxLength={4}
              required
              disabled={isProcessing}
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-950 rounded-lg border border-red-200 dark:border-red-800">
          <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 shrink-0" />
          <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
        </div>
      )}

      <Button
        type="submit"
        disabled={disabled || isProcessing || !cardNumber || !expiry || !cvv}
        className="w-full rounded-xl py-6 text-lg font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
        data-testid="button-card-pay"
      >
        {isProcessing ? (
          <>
            <Loader2 className="h-5 w-5 mr-2 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <CreditCard className="h-5 w-5 mr-2" />
            Pay ${amount} with Card
          </>
        )}
      </Button>
    </form>
  );
}
