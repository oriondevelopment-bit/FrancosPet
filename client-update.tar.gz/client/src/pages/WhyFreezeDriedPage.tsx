import { Navigation } from "@/components/Navigation";
import { PetStoreSubNav } from "@/components/PetStoreSubNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  PawPrint, ChevronRight, Snowflake, Zap, ShieldCheck, Leaf,
  Heart, Apple, Bug, Package, ThumbsUp, FlaskConical, MapPin, X,
  AlertTriangle, Flag, CheckCircle2
} from "lucide-react";
import montanaBadge from "@assets/montana-badge_1772867253604.png";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.4 },
});

export default function WhyFreezeDriedPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      <PetStoreSubNav />

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 via-background to-primary/10 dark:from-green-500/5 dark:via-background dark:to-primary/5" />
          <div className="container relative px-4 py-16 md:py-24 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <motion.div {...fadeUp(0)} className="mb-6">
                <Snowflake className="h-12 w-12 mx-auto text-blue-500 mb-4" />
              </motion.div>
              <motion.h1
                {...fadeUp(0.1)}
                className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-5xl font-display"
                data-testid="heading-why-freeze-dried"
              >
                Why Freeze-Dried?
              </motion.h1>
              <motion.p
                {...fadeUp(0.2)}
                className="mx-auto max-w-2xl text-lg text-muted-foreground leading-relaxed"
                data-testid="text-hero-subtitle"
              >
                Discover why freeze-dried treats are the gold standard in pet nutrition — and why Franco's Pet Store takes it even further with single-ingredient, human-grade beef liver from Montana and regional ranches.
              </motion.p>
            </div>
          </div>
        </section>

        <section className="container px-4 md:px-6 pb-16">
          <div className="mx-auto max-w-4xl">

            <motion.div {...fadeUp(0.3)} className="flex flex-col md:flex-row items-center gap-8 mb-16">
              <img
                src={petStoreLogo}
                alt="Franco's Pet Store Premium Pet Treats"
                className="w-36 h-36 md:w-44 md:h-44 rounded-2xl object-cover shadow-md flex-shrink-0"
                data-testid="img-pet-treats-hero"
              />
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-what-is">
                  What Is Freeze-Drying?
                </h2>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-what-is">
                  Freeze-drying is a gentle, low-temperature process that removes moisture from raw food while preserving its natural nutrients, flavor, and structure. Unlike traditional kibble manufacturing — which uses extreme heat that destroys vitamins, enzymes, and proteins — freeze-drying locks in everything that makes real food beneficial for your dog.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  The result is a lightweight, shelf-stable treat that retains up to <strong className="text-foreground">97% of its original nutritional value</strong> — essentially raw nutrition in a convenient, safe-to-handle form.
                </p>
              </div>
            </motion.div>

            <motion.div {...fadeUp(0.35)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3" data-testid="heading-benefits">
                The Benefits of Freeze-Dried Treats
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                Here's why veterinarians, trainers, and pet parents are making the switch from conventional treats.
              </p>

              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    icon: Zap,
                    color: "text-amber-500",
                    bg: "bg-amber-100 dark:bg-amber-900/30",
                    title: "Superior Nutrient Retention",
                    desc: "The low-temperature process preserves vitamins, minerals, and enzymes that high-heat kibble manufacturing destroys. Your dog gets more nutrition from every bite.",
                    testId: "card-nutrient-retention",
                  },
                  {
                    icon: Heart,
                    color: "text-red-500",
                    bg: "bg-red-100 dark:bg-red-900/30",
                    title: "Excellent Digestibility",
                    desc: "Minimally processed ingredients with intact nutrients mean better absorption and fewer digestive issues — less gas, less upset stomach, more energy.",
                    testId: "card-digestibility",
                  },
                  {
                    icon: Apple,
                    color: "text-green-500",
                    bg: "bg-green-100 dark:bg-green-900/30",
                    title: "Irresistible Taste",
                    desc: "Freeze-drying preserves natural flavors and aromas that dogs go crazy for. Even the pickiest eaters can't resist the rich, meaty taste of real beef liver.",
                    testId: "card-taste",
                  },
                  {
                    icon: Package,
                    color: "text-blue-500",
                    bg: "bg-blue-100 dark:bg-blue-900/30",
                    title: "Convenient & Shelf-Stable",
                    desc: "Lightweight and easy to store with no refrigeration needed. Perfect for training, travel, hiking, or rewarding your pup on the go.",
                    testId: "card-convenience",
                  },
                  {
                    icon: Leaf,
                    color: "text-emerald-500",
                    bg: "bg-emerald-100 dark:bg-emerald-900/30",
                    title: "No Fillers or Junk",
                    desc: "Franco's treats contain one ingredient: beef liver. No corn, wheat, soy, artificial colors, flavors, or preservatives hiding on the label.",
                    testId: "card-no-fillers",
                  },
                  {
                    icon: ShieldCheck,
                    color: "text-purple-500",
                    bg: "bg-purple-100 dark:bg-purple-900/30",
                    title: "Safer Than Raw",
                    desc: "Freeze-drying removes moisture that bacteria need to grow, making it safer than feeding raw while retaining all the raw-nutrition benefits.",
                    testId: "card-safer",
                  },
                ].map((item) => (
                  <Card key={item.testId} data-testid={item.testId}>
                    <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                      <div className={`flex h-12 w-12 items-center justify-center rounded-full ${item.bg}`}>
                        <item.icon className={`h-6 w-6 ${item.color}`} />
                      </div>
                      <h3 className="font-bold text-foreground">{item.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div {...fadeUp(0.4)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-8" data-testid="heading-comparison">
                Freeze-Dried vs. Conventional Treats
              </h2>
              <Card>
                <CardContent className="p-0 overflow-x-auto">
                  <table className="w-full text-sm" data-testid="table-comparison">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="text-left p-4 font-bold text-foreground min-w-[160px]"></th>
                        <th className="p-4 text-center font-bold text-foreground min-w-[160px]">
                          <div className="flex flex-col items-center gap-1">
                            <Snowflake className="h-5 w-5 text-blue-500" />
                            <span>Franco's Freeze-Dried</span>
                          </div>
                        </th>
                        <th className="p-4 text-center font-bold text-muted-foreground min-w-[160px]">
                          <span>Conventional Kibble/Treats</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { label: "Processing Method", good: "Low-temperature freeze-drying", bad: "High-heat extrusion (300°F+)" },
                        { label: "Nutrient Retention", good: "Up to 97% preserved", bad: "Significant vitamin/enzyme loss" },
                        { label: "Ingredients", good: "Single ingredient: beef liver", bad: "Fillers, by-products, additives" },
                        { label: "Preservatives", good: "None needed", bad: "BHA, BHT, ethoxyquin common" },
                        { label: "Protein Quality", good: "Human-grade, whole-food", bad: "Rendered meals, meat by-products" },
                        { label: "Digestibility", good: "Highly digestible, easy on stomach", bad: "Can cause gas, bloating, allergies" },
                        { label: "Artificial Colors/Flavors", good: "Never", bad: "Often added for appeal" },
                        { label: "Sourcing", good: "Montana & regional US ranches, 100% USA", bad: "Often imported from China or unknown origin" },
                        { label: "Heavy Metal Risk", good: "Negligible — clean US pastureland", bad: "High risk with foreign organ meats (Pb, Cd, Hg, As, Cr)" },
                        { label: "Packaging", good: "Eco-friendly, biodegradable — less waste", bad: "Oversized, non-recyclable plastic" },
                      ].map((row, i) => (
                        <tr key={i} className={i % 2 === 0 ? "bg-background" : "bg-muted/20"}>
                          <td className="p-4 font-medium text-foreground">{row.label}</td>
                          <td className="p-4 text-center">
                            <span className="inline-flex items-center gap-1.5 text-green-600 dark:text-green-400">
                              <ThumbsUp className="h-3.5 w-3.5" /> {row.good}
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                              <X className="h-3.5 w-3.5 text-red-400" /> {row.bad}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp(0.45)} className="mb-16">
              <Card className="border-l-4 border-l-primary bg-muted/30 dark:bg-muted/10">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <FlaskConical className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-science">
                        The Science Behind the Quality
                      </h2>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-science-1">
                        Beef liver is one of nature's most nutrient-dense foods — packed with <strong className="text-foreground">Vitamin A, B12, iron, copper, and essential amino acids</strong> that support your dog's immune system, coat health, energy levels, and cognitive function.
                      </p>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-science-2">
                        When we freeze-dry our beef liver, these heat-sensitive nutrients remain intact rather than being cooked away. The result is a treat that functions more like a nutritional supplement than a snack — giving your dog real, bioavailable nutrition with every piece.
                      </p>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-science-3">
                        And because there's only <strong className="text-foreground">one ingredient</strong> — no grains, no fillers, no mystery "meat meals" — it's ideal for dogs with food sensitivities or allergies.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp(0.5)} className="mb-16">
              <Card className="border-l-4 border-l-green-600 dark:border-l-green-500 bg-muted/30 dark:bg-muted/10">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <MapPin className="h-8 w-8 text-green-600 dark:text-green-500 flex-shrink-0 mt-1" />
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-sourcing">
                        Sourced with Integrity
                      </h2>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-sourcing-1">
                        Every batch of Franco's freeze-dried beef liver treats starts at Montana's premier ranches — where cattle are raised on open pastures with responsible, ethical practices. We know exactly where our ingredients come from because transparency isn't a buzzword for us; it's a family value passed down through generations.
                      </p>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-sourcing-2">
                        Our treats are <strong className="text-foreground">human-grade</strong>, meaning they meet the same safety and quality standards as food made for people. We believe your dog deserves nothing less.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Heavy Metals Section */}
            <motion.div {...fadeUp(0.52)} className="mb-16" data-testid="section-heavy-metals">
              <Card className="border-l-4 border-l-red-500 bg-red-50/50 dark:bg-red-950/20">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4 mb-6">
                    <AlertTriangle className="h-8 w-8 text-red-500 flex-shrink-0 mt-1" />
                    <div>
                      <h2 className="text-2xl font-bold text-foreground font-display mb-2" data-testid="heading-heavy-metals">
                        The Hidden Danger in Foreign-Sourced Organ Meats
                      </h2>
                      <p className="text-muted-foreground leading-relaxed">
                        Beef liver and beef heart are among the most nutritionally powerful foods you can give your dog — but that power cuts both ways. Because organ meats are the body's filtration system, they also <strong className="text-foreground">concentrate whatever the animal was exposed to</strong> throughout its life. This is why sourcing matters more for organ meat treats than for any other product.
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-2">
                    <div>
                      <h3 className="font-bold text-foreground mb-3 flex items-center gap-2">
                        <X className="h-5 w-5 text-red-500" />
                        Heavy Metals Found in Foreign-Sourced Organ Meats
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                        Published studies on organ meats sourced from China and other industrially contaminated regions have documented significant accumulation of toxic heavy metals, primarily due to industrial pollution in soil, water, and animal feed:
                      </p>
                      <ul className="space-y-2">
                        {[
                          { metal: "Lead (Pb)", effect: "Neurological damage, kidney failure, behavioral changes" },
                          { metal: "Cadmium (Cd)", effect: "Kidney damage, bone weakening, carcinogenic" },
                          { metal: "Mercury (Hg)", effect: "Nervous system toxicity, tremors, vision loss" },
                          { metal: "Arsenic (As)", effect: "Gastrointestinal damage, immune suppression, cancer risk" },
                          { metal: "Chromium (Cr)", effect: "Liver and kidney damage, DNA disruption" },
                        ].map((item) => (
                          <li key={item.metal} className="flex items-start gap-2 text-sm">
                            <span className="font-bold text-red-600 dark:text-red-400 flex-shrink-0 w-28">{item.metal}</span>
                            <span className="text-muted-foreground">{item.effect}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-bold text-foreground mb-3 flex items-center gap-2">
                        <Flag className="h-5 w-5 text-green-600" />
                        Why Franco's Is Different
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                        Every ounce of beef liver and beef heart in Franco's treats comes from cattle raised on American soil — Montana open pastures and regional ranches where land quality, water sources, and feed are held to strict US agricultural standards.
                      </p>
                      <ul className="space-y-2">
                        {[
                          "Cattle raised on clean Montana pastureland, far from industrial contamination",
                          "Zero imported organ meat — ever. 100% USA origin, start to finish",
                          "USDA-regulated processing facilities with traceability at every step",
                          "No heavy metal risk from industrial pollution or contaminated feed",
                          "The same safety standards as food made for people — because we believe your pet deserves nothing less",
                        ].map((point, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-6 p-4 rounded-xl bg-white dark:bg-background border border-red-100 dark:border-red-900/40">
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      <strong className="text-foreground">Bottom line:</strong> When you see a freeze-dried liver treat on a store shelf with no country-of-origin information, there's a real chance it was sourced overseas. We don't think your dog should be a lab experiment. That's why "Made in the USA" isn't just a badge for us — it's the foundation of every decision we make.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp(0.55)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3" data-testid="heading-who-benefits">
                Who Benefits Most?
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                Freeze-dried treats are perfect for every dog, but especially beneficial for:
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                {[
                  { title: "Picky Eaters", desc: "The rich, natural flavor of real beef liver wins over even the fussiest dogs who turn their nose up at conventional treats." },
                  { title: "Dogs with Allergies", desc: "Single-ingredient means no hidden allergens. No grains, no soy, no dairy — just pure beef liver." },
                  { title: "Senior Dogs", desc: "Easy to break into small pieces and highly digestible, making them gentle on aging digestive systems." },
                  { title: "Active & Working Dogs", desc: "Nutrient-dense fuel packed with protein and B-vitamins to support high energy demands and muscle recovery." },
                  { title: "Puppies in Training", desc: "Small, high-value rewards that puppies go wild for — perfect for positive reinforcement training sessions." },
                  { title: "Dogs with Sensitive Stomachs", desc: "Minimally processed with no artificial additives means less digestive upset, less gas, and better stool quality." },
                ].map((item, i) => (
                  <Card key={i} data-testid={`card-benefit-${i}`}>
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <PawPrint className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <div>
                          <h3 className="font-bold text-foreground mb-1">{item.title}</h3>
                          <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div
              {...fadeUp(0.6)}
              className="bg-gradient-to-br from-primary/5 via-muted/40 to-green-500/5 dark:from-primary/10 dark:via-muted/20 dark:to-green-500/10 rounded-2xl p-8 md:p-10 text-center border"
              data-testid="section-cta"
            >
              <PawPrint className="h-10 w-10 mx-auto text-primary mb-4" />
              <h2 className="text-2xl font-bold text-foreground font-display mb-3">
                Give Your Dog the Best
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto mb-6 leading-relaxed">
                Join thousands of pet parents who have made the switch to freeze-dried. Your dog will taste the difference — and you'll see the difference in their health, energy, and happiness.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/pet-store">
                  <Button size="lg" className="gap-2" data-testid="button-shop-now">
                    <PawPrint className="h-5 w-5" /> Shop Freeze-Dried Treats
                  </Button>
                </Link>
                <Link href="/our-story">
                  <Button size="lg" variant="outline" className="gap-2" data-testid="button-our-story">
                    Read Our Story <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-8">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto text-center text-sm text-muted-foreground space-y-4">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">Franco's Pet Store. All Rights Reserved.</p>
            <p>
              <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link>
              {" · "}
              <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>
              {" · "}
              <Link href="/environmental" className="text-primary underline hover:text-primary/80">Environmental Initiative</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
