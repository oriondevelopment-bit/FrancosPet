import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Loader2, Save, Bell, MessageSquare, ShoppingBag, RotateCcw, Calendar, PawPrint, Pause, Play, X, RefreshCw, CheckCircle2, AlertCircle, Send, HandHeart } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { CustomerProfile, OrderWithItems, PetSubscription, Charity } from "@shared/schema";
import { useCart } from "@/lib/CartContext";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

type ProfileFormData = {
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  smsOptInOrders: boolean;
  smsOptInPromos: boolean;
  charityId: string;
};

type CancelDialogStep = 'confirm' | 'reconsider' | 'pause_offer' | 'done';

export default function ProfilePage() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { addToCart } = useCart();
  const [, setLocation] = useLocation();

  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelDialogStep, setCancelDialogStep] = useState<CancelDialogStep>('confirm');
  const [cancelSubId, setCancelSubId] = useState<number | null>(null);
  const [cancelSubCancelCount, setCancelSubCancelCount] = useState(0);
  const [cancelSubDiscountUsed, setCancelSubDiscountUsed] = useState(false);
  const [pauseDialogOpen, setPauseDialogOpen] = useState(false);
  const [pauseSubId, setPauseSubId] = useState<number | null>(null);
  const [verifyType, setVerifyType] = useState<"phone" | "email" | null>(null);
  const [verifyCode, setVerifyCode] = useState("");
  const [verifySent, setVerifySent] = useState(false);

  const { data: profile, isLoading: profileLoading } = useQuery<CustomerProfile>({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
  });

  const { data: subscriptions, isLoading: subsLoading } = useQuery<PetSubscription[]>({
    queryKey: ["/api/my-pet-subscriptions"],
    enabled: isAuthenticated,
  });

  const handleReorder = (order: OrderWithItems) => {
    let addedCount = 0;
    let skippedCount = 0;
    
    order.items.forEach(item => {
      if (item.menuItem && item.menuItemId > 0) {
        for (let i = 0; i < item.quantity; i++) {
          addToCart(item.menuItem);
          addedCount++;
        }
      } else {
        skippedCount += item.quantity;
      }
    });
    
    if (addedCount > 0) {
      toast({
        title: "Items added to cart",
        description: skippedCount > 0 
          ? `${addedCount} item(s) added. ${skippedCount} custom item(s) must be rebuilt manually.`
          : `${addedCount} item(s) from your previous order have been added.`,
      });
      setLocation("/cart");
    } else {
      toast({
        title: "Cannot reorder",
        description: "This order contains only custom items. Please build them fresh from the menu.",
        variant: "destructive",
      });
      setLocation("/");
    }
  };

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "completed": return "default";
      case "confirmed": return "secondary";
      case "pending": return "outline";
      case "cancelled": return "destructive";
      default: return "outline";
    }
  };

  const { data: charities = [] } = useQuery<Charity[]>({
    queryKey: ["/api/charities"],
  });

  const form = useForm<ProfileFormData>({
    defaultValues: {
      firstName: "",
      lastName: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      smsOptInOrders: false,
      smsOptInPromos: false,
      charityId: "",
    },
  });

  useEffect(() => {
    if (profile || user) {
      form.reset({
        firstName: user?.firstName || "",
        lastName: user?.lastName || "",
        phone: profile?.phone || "",
        address: profile?.address || "",
        city: profile?.city || "",
        state: profile?.state || "",
        zipCode: profile?.zipCode || "",
        smsOptInOrders: profile?.smsOptInOrders || false,
        smsOptInPromos: profile?.smsOptInPromos || false,
        charityId: profile?.charityId ? String(profile.charityId) : "",
      });
    }
  }, [profile, user, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const { firstName, lastName, charityId, ...profileData } = data;
      
      // Update user name
      await apiRequest("/api/user", {
        method: "PATCH",
        body: JSON.stringify({ firstName, lastName }),
      });
      
      // Update profile data
      return await apiRequest("/api/profile", {
        method: "PATCH",
        body: JSON.stringify({
          ...profileData,
          charityId: charityId ? Number(charityId) : null,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const sendVerificationMutation = useMutation({
    mutationFn: async (type: "phone" | "email") => {
      return await apiRequest("/api/verify/send", {
        method: "POST",
        body: JSON.stringify({ type }),
      });
    },
    onSuccess: (_, type) => {
      setVerifySent(true);
      toast({
        title: "Code Sent",
        description: `A verification code has been sent to your ${type === "phone" ? "phone" : "email"}.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send verification code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const confirmVerificationMutation = useMutation({
    mutationFn: async ({ type, code }: { type: string; code: string }) => {
      return await apiRequest("/api/verify/confirm", {
        method: "POST",
        body: JSON.stringify({ type, code }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setVerifyType(null);
      setVerifyCode("");
      setVerifySent(false);
      toast({
        title: "Verified",
        description: "Verification successful!",
      });
    },
    onError: () => {
      toast({
        title: "Invalid Code",
        description: "The code you entered is invalid or has expired. Please try again.",
        variant: "destructive",
      });
    },
  });

  const pauseSubscriptionMutation = useMutation({
    mutationFn: async ({ id, days }: { id: number; days: number }) => {
      return await apiRequest(`/api/my-pet-subscriptions/${id}/pause`, {
        method: "POST",
        body: JSON.stringify({ days }),
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-pet-subscriptions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setPauseDialogOpen(false);
      setPauseSubId(null);
      const discountMsg = data.discountApplied
        ? " You've earned a one-time 10% discount on your next purchase!"
        : "";
      toast({
        title: "Subscription Paused",
        description: `Your subscription has been paused.${discountMsg}`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to pause subscription.", variant: "destructive" });
    },
  });

  const resumeSubscriptionMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/my-pet-subscriptions/${id}/resume`, { method: "POST" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-pet-subscriptions"] });
      toast({ title: "Subscription Resumed", description: "Your subscription is active again." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to resume subscription.", variant: "destructive" });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/my-pet-subscriptions/${id}/cancel`, { method: "POST" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-pet-subscriptions"] });
      setCancelDialogOpen(false);
      setCancelSubId(null);
      toast({
        title: "Subscription Cancelled",
        description: "Your subscription has been cancelled. You will need to pay for shipping on future purchases until you resubscribe.",
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to cancel subscription.", variant: "destructive" });
    },
  });

  const resubscribeMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/my-pet-subscriptions/${id}/resubscribe`, { method: "POST" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-pet-subscriptions"] });
      toast({ title: "Resubscribed!", description: "Your subscription is active again with free shipping." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to resubscribe.", variant: "destructive" });
    },
  });

  const openCancelDialog = (sub: PetSubscription) => {
    setCancelSubId(sub.id);
    setCancelSubCancelCount(sub.cancelCount || 0);
    setCancelSubDiscountUsed(sub.pauseDiscountApplied || false);
    setCancelDialogStep('reconsider');
    setCancelDialogOpen(true);
  };

  const openPauseDialog = (subId: number) => {
    setPauseSubId(subId);
    setPauseDialogOpen(true);
  };

  const handlePause = (days: number) => {
    if (pauseSubId) {
      pauseSubscriptionMutation.mutate({ id: pauseSubId, days });
    }
  };

  const handleAcceptPauseFromCancel = () => {
    setCancelDialogOpen(false);
    if (cancelSubId) {
      openPauseDialog(cancelSubId);
    }
  };

  const handleConfirmCancel = () => {
    if (cancelSubId) {
      cancelSubscriptionMutation.mutate(cancelSubId);
    }
  };

  const getSubStatusBadge = (sub: PetSubscription) => {
    switch (sub.status) {
      case 'active': return <Badge variant="default" data-testid={`badge-sub-status-${sub.id}`}>Active</Badge>;
      case 'paused': return <Badge variant="secondary" data-testid={`badge-sub-status-${sub.id}`}>Paused</Badge>;
      case 'cancelled': return <Badge variant="destructive" data-testid={`badge-sub-status-${sub.id}`}>Cancelled</Badge>;
      default: return <Badge variant="outline" data-testid={`badge-sub-status-${sub.id}`}>{sub.status}</Badge>;
    }
  };

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container px-4 py-8 md:px-6 md:py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-bold font-display" data-testid="text-page-title">My Profile</h1>
            <p className="text-muted-foreground mt-2">Manage your account settings and preferences</p>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>Your name and contact details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      placeholder="First name"
                      {...form.register("firstName")}
                      data-testid="input-first-name"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Last name"
                      {...form.register("lastName")}
                      data-testid="input-last-name"
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <div className="flex items-center gap-2">
                    <Label>Email</Label>
                    {profile?.emailVerified ? (
                      <Badge variant="outline" className="text-green-600 border-green-600 gap-1" data-testid="badge-email-verified">
                        <CheckCircle2 className="h-3 w-3" /> Verified
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-amber-600 border-amber-600 gap-1" data-testid="badge-email-unverified">
                        <AlertCircle className="h-3 w-3" /> Not Verified
                      </Badge>
                    )}
                  </div>
                  <Input value={user?.email || ""} disabled data-testid="input-email" />
                  {!profile?.emailVerified && user?.email && (
                    verifyType === "email" ? (
                      <div className="flex gap-2 items-center">
                        <Input
                          placeholder="Enter 6-digit code"
                          value={verifyCode}
                          onChange={(e) => setVerifyCode(e.target.value)}
                          maxLength={6}
                          className="w-40"
                          data-testid="input-email-verify-code"
                        />
                        <Button
                          size="sm"
                          onClick={() => confirmVerificationMutation.mutate({ type: "email", code: verifyCode })}
                          disabled={verifyCode.length !== 6 || confirmVerificationMutation.isPending}
                          data-testid="button-confirm-email"
                        >
                          {confirmVerificationMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Confirm"}
                        </Button>
                        {!verifySent && (
                          <Button size="sm" variant="outline" onClick={() => sendVerificationMutation.mutate("email")} disabled={sendVerificationMutation.isPending} data-testid="button-send-email-code">
                            {sendVerificationMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="h-3 w-3 mr-1" /> Send Code</>}
                          </Button>
                        )}
                        {verifySent && (
                          <Button size="sm" variant="ghost" onClick={() => sendVerificationMutation.mutate("email")} disabled={sendVerificationMutation.isPending}>
                            Resend
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => { setVerifyType(null); setVerifyCode(""); setVerifySent(false); }}>
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-fit"
                        onClick={() => { setVerifyType("email"); setVerifyCode(""); setVerifySent(false); }}
                        data-testid="button-verify-email"
                      >
                        <Send className="h-3 w-3 mr-1" /> Verify Email
                      </Button>
                    )
                  )}
                </div>
                <div className="grid gap-2">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    {profile?.phone && (
                      profile?.phoneVerified ? (
                        <Badge variant="outline" className="text-green-600 border-green-600 gap-1" data-testid="badge-phone-verified">
                          <CheckCircle2 className="h-3 w-3" /> Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-amber-600 border-amber-600 gap-1" data-testid="badge-phone-unverified">
                          <AlertCircle className="h-3 w-3" /> Not Verified
                        </Badge>
                      )
                    )}
                  </div>
                  <Input
                    id="phone"
                    placeholder="(555) 123-4567"
                    {...form.register("phone")}
                    data-testid="input-phone"
                  />
                  {profile?.phone && !profile?.phoneVerified && (
                    verifyType === "phone" ? (
                      <div className="flex gap-2 items-center">
                        <Input
                          placeholder="Enter 6-digit code"
                          value={verifyCode}
                          onChange={(e) => setVerifyCode(e.target.value)}
                          maxLength={6}
                          className="w-40"
                          data-testid="input-phone-verify-code"
                        />
                        <Button
                          size="sm"
                          onClick={() => confirmVerificationMutation.mutate({ type: "phone", code: verifyCode })}
                          disabled={verifyCode.length !== 6 || confirmVerificationMutation.isPending}
                          data-testid="button-confirm-phone"
                        >
                          {confirmVerificationMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Confirm"}
                        </Button>
                        {!verifySent && (
                          <Button size="sm" variant="outline" onClick={() => sendVerificationMutation.mutate("phone")} disabled={sendVerificationMutation.isPending} data-testid="button-send-phone-code">
                            {sendVerificationMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="h-3 w-3 mr-1" /> Send Code</>}
                          </Button>
                        )}
                        {verifySent && (
                          <Button size="sm" variant="ghost" onClick={() => sendVerificationMutation.mutate("phone")} disabled={sendVerificationMutation.isPending}>
                            Resend
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => { setVerifyType(null); setVerifyCode(""); setVerifySent(false); }}>
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-fit"
                        onClick={() => { setVerifyType("phone"); setVerifyCode(""); setVerifySent(false); }}
                        data-testid="button-verify-phone"
                      >
                        <Send className="h-3 w-3 mr-1" /> Verify Phone
                      </Button>
                    )
                  )}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="address">Street Address</Label>
                  <Input
                    id="address"
                    placeholder="123 Main Street"
                    {...form.register("address")}
                    data-testid="input-address"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      placeholder="Glendive"
                      {...form.register("city")}
                      data-testid="input-city"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="state">State</Label>
                    <Input
                      id="state"
                      placeholder="MT"
                      {...form.register("state")}
                      data-testid="input-state"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="zipCode">ZIP Code</Label>
                    <Input
                      id="zipCode"
                      placeholder="59330"
                      {...form.register("zipCode")}
                      data-testid="input-zipcode"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  SMS Notifications
                </CardTitle>
                <CardDescription>Choose which text message notifications you'd like to receive. A phone number is required to enable SMS.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {(form.watch("smsOptInOrders") || form.watch("smsOptInPromos")) && !form.watch("phone") && (
                  <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive" data-testid="sms-phone-warning">
                    Please add your phone number above to receive SMS notifications.
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="smsOrders" className="font-medium">Order Updates</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified when your order is ready for pickup or delivery
                    </p>
                  </div>
                  <Switch
                    id="smsOrders"
                    checked={form.watch("smsOptInOrders")}
                    onCheckedChange={(checked) => form.setValue("smsOptInOrders", checked)}
                    data-testid="switch-sms-orders"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="smsPromos" className="font-medium flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      Specials & Promotions
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Receive exclusive deals, discounts, and special offers
                    </p>
                  </div>
                  <Switch
                    id="smsPromos"
                    checked={form.watch("smsOptInPromos")}
                    onCheckedChange={(checked) => form.setValue("smsOptInPromos", checked)}
                    data-testid="switch-sms-promos"
                  />
                </div>
                {(form.watch("smsOptInOrders") || form.watch("smsOptInPromos")) && (
                  <p className="text-xs text-muted-foreground" data-testid="text-sms-stop-notice">
                    By enabling SMS, you agree to receive text messages from Franco's Pet Store. 
                    Msg & data rates may apply. Reply STOP to any message to unsubscribe at any time.
                  </p>
                )}
              </CardContent>
            </Card>

            <div className="mt-6 flex justify-end">
              <Button type="submit" disabled={updateProfileMutation.isPending} data-testid="button-save-profile">
                {updateProfileMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Changes
              </Button>
            </div>
          </form>

          {subscriptions && subscriptions.length > 0 && (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PawPrint className="h-5 w-5" />
                  Pet Treat Subscriptions
                </CardTitle>
                <CardDescription>Manage your monthly auto-renewal subscriptions</CardDescription>
              </CardHeader>
              <CardContent>
                {subsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {subscriptions.map((sub) => {
                      const items = sub.items as Array<{ menuItemId: number; quantity: number }>;
                      return (
                        <div
                          key={sub.id}
                          className="border rounded-lg p-4 space-y-3"
                          data-testid={`subscription-${sub.id}`}
                        >
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">Subscription #{sub.id}</span>
                              {getSubStatusBadge(sub)}
                            </div>
                            <span className="font-bold text-primary">{formatPrice(sub.totalAmount)}/mo</span>
                          </div>

                          <div className="text-sm text-muted-foreground space-y-1">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              <span>
                                {sub.status === 'active' && sub.nextRenewalDate && (
                                  <>Next renewal: {new Date(sub.nextRenewalDate).toLocaleDateString()}</>
                                )}
                                {sub.status === 'paused' && sub.pausedUntil && (
                                  <>Paused until: {new Date(sub.pausedUntil).toLocaleDateString()}</>
                                )}
                                {sub.status === 'cancelled' && (
                                  <>Cancelled</>
                                )}
                              </span>
                            </div>
                            <div>
                              {items.map((item, idx) => (
                                <span key={idx}>
                                  {item.quantity}x Pet Treat
                                  {idx < items.length - 1 && ', '}
                                </span>
                              ))}
                            </div>
                            <div className="text-xs">Ships to: {sub.shippingAddress}</div>
                            {sub.paypalVaultId && (
                              <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400" data-testid={`text-vault-status-${sub.id}`}>
                                <CheckCircle2 className="h-3 w-3" />
                                Payment method saved — auto-renews monthly
                              </div>
                            )}
                            {!sub.paypalVaultId && sub.status === 'active' && (
                              <div className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400" data-testid={`text-no-vault-${sub.id}`}>
                                <AlertCircle className="h-3 w-3" />
                                No saved payment method — manual renewal required
                              </div>
                            )}
                            {sub.lastRenewalError && (
                              <div className="flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
                                <AlertCircle className="h-3 w-3" />
                                Last renewal error: {sub.lastRenewalError}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {sub.status === 'active' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openPauseDialog(sub.id)}
                                  data-testid={`button-pause-sub-${sub.id}`}
                                >
                                  <Pause className="h-4 w-4 mr-1" />
                                  Pause
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openCancelDialog(sub)}
                                  className="text-destructive"
                                  data-testid={`button-cancel-sub-${sub.id}`}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Cancel
                                </Button>
                              </>
                            )}
                            {sub.status === 'paused' && (
                              <>
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => resumeSubscriptionMutation.mutate(sub.id)}
                                  disabled={resumeSubscriptionMutation.isPending}
                                  data-testid={`button-resume-sub-${sub.id}`}
                                >
                                  {resumeSubscriptionMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                                  ) : (
                                    <Play className="h-4 w-4 mr-1" />
                                  )}
                                  Resume
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openCancelDialog(sub)}
                                  className="text-destructive"
                                  data-testid={`button-cancel-sub-${sub.id}`}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Cancel
                                </Button>
                              </>
                            )}
                            {sub.status === 'cancelled' && (
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => resubscribeMutation.mutate(sub.id)}
                                disabled={resubscribeMutation.isPending}
                                data-testid={`button-resubscribe-${sub.id}`}
                              >
                                {resubscribeMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                                ) : (
                                  <RefreshCw className="h-4 w-4 mr-1" />
                                )}
                                Resubscribe
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
            <DialogContent>
              {cancelDialogStep === 'reconsider' && (
                <>
                  <DialogHeader>
                    <DialogTitle>Are you sure you want to cancel?</DialogTitle>
                    <DialogDescription>
                      {cancelSubCancelCount === 0 && !cancelSubDiscountUsed ? (
                        <>
                          We'd hate to see you go! Instead of cancelling, would you consider pausing your subscription? You'll get <strong>10% off your next purchase</strong> as a thank you for staying with us.
                        </>
                      ) : (
                        <>
                          We'd hate to see you go! Would you consider pausing your subscription instead? You can pause for 30 or 60 days and resume anytime.
                        </>
                      )}
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter className="flex flex-col sm:flex-row gap-2">
                    <Button
                      variant="default"
                      onClick={handleAcceptPauseFromCancel}
                      data-testid="button-accept-pause-offer"
                    >
                      <Pause className="h-4 w-4 mr-1" />
                      {cancelSubCancelCount === 0 && !cancelSubDiscountUsed ? "Pause & Get 10% Off" : "Pause Instead"}
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={handleConfirmCancel}
                      disabled={cancelSubscriptionMutation.isPending}
                      data-testid="button-confirm-cancel"
                    >
                      {cancelSubscriptionMutation.isPending ? (
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      ) : (
                        <X className="h-4 w-4 mr-1" />
                      )}
                      Cancel Subscription
                    </Button>
                  </DialogFooter>
                </>
              )}
            </DialogContent>
          </Dialog>

          <Dialog open={pauseDialogOpen} onOpenChange={setPauseDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Pause Your Subscription</DialogTitle>
                <DialogDescription>
                  Choose how long you'd like to pause. Your subscription will automatically resume after the pause period ends.
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-3 py-4">
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => handlePause(30)}
                  disabled={pauseSubscriptionMutation.isPending}
                  data-testid="button-pause-30"
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Pause for 30 days
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => handlePause(60)}
                  disabled={pauseSubscriptionMutation.isPending}
                  data-testid="button-pause-60"
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Pause for 60 days
                </Button>
              </div>
              {pauseSubscriptionMutation.isPending && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Pausing subscription...
                </div>
              )}
            </DialogContent>
          </Dialog>

          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5" />
                Order History
              </CardTitle>
              <CardDescription>View your past orders and quickly reorder favorites</CardDescription>
            </CardHeader>
            <CardContent>
              {ordersLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : orders && orders.length > 0 ? (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div 
                      key={order.id} 
                      className="border rounded-lg p-4 space-y-3"
                      data-testid={`order-history-${order.id}`}
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{order.orderRef || `Order #${order.id}`}</span>
                          <Badge variant={getStatusBadgeVariant(order.status)}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </Badge>
                        </div>
                        <span className="font-bold text-primary">{formatPrice(order.totalAmount)}</span>
                      </div>
                      
                      <div className="text-sm text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'N/A'}
                        {order.isDelivery && <span className="ml-2">• Delivery</span>}
                      </div>
                      
                      <div className="text-sm">
                        {order.items.map((item, idx) => (
                          <span key={item.id}>
                            {item.quantity}x {item.menuItem?.name || 'Unknown Item'}
                            {idx < order.items.length - 1 && ', '}
                          </span>
                        ))}
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleReorder(order)}
                        className="w-full sm:w-auto"
                        data-testid={`reorder-${order.id}`}
                      >
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Reorder
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <ShoppingBag className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No orders yet</p>
                  <p className="text-sm mt-1">Your order history will appear here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
