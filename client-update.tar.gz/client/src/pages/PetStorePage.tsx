import { useMenu } from "@/hooks/use-menu";
import { MenuItemCard } from "@/components/MenuItemCard";
import { Navigation } from "@/components/Navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { PawPrint, Leaf, ShieldCheck, MapPin, Snowflake, ChevronRight, Package, AlertTriangle, Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PetStoreSubNav } from "@/components/PetStoreSubNav";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function PetStorePage() {
  const { data: menuItems, isLoading, error } = useMenu();

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-destructive">Error loading products</h2>
          <p className="text-muted-foreground">Please try again later.</p>
        </div>
      </div>
    );
  }

  const petTreats = menuItems?.filter((item) => item.category === "pet_treats") || [];

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />
      <PetStoreSubNav />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12">

        {/* Hero + Tagline */}
        <div className="mb-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center gap-3 mb-4"
          >
            <PawPrint className="h-8 w-8 md:h-10 md:w-10 text-primary" />
            <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl font-display">
              Franco's Pet Store
            </h1>
          </motion.div>

          {/* PRIMARY TAGLINE */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="mx-auto max-w-2xl text-2xl font-bold text-primary font-display tracking-tight mb-2"
            data-testid="text-tagline"
          >
            Pure American. Zero Compromise.
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mx-auto max-w-2xl text-lg text-muted-foreground"
            data-testid="text-hero-subtitle"
          >
            Montana-raised beef treats — single ingredient, human-grade, heavy metal free, and wrapped in eco-friendly packaging. No imports. No shortcuts. No excuses.
          </motion.p>

          {/* Keyword badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-2 mt-4"
            data-testid="section-keyword-badges"
          >
            {[
              "USA Raised & Made",
              "Heavy Metal Free",
              "Single Ingredient",
              "Human-Grade",
              "No Preservatives",
              "Eco-Friendly Packaging",
              "No Foreign Sourcing",
            ].map((kw) => (
              <span
                key={kw}
                className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary border border-primary/20"
              >
                {kw}
              </span>
            ))}
          </motion.div>
        </div>

        {/* Brand story panel */}
        <section className="mb-12">
          <div className="flex flex-col md:flex-row items-center gap-6 rounded-2xl bg-muted/50 dark:bg-muted/30 p-6 md:p-8 border border-border">
            <img
              src={petStoreLogo}
              alt="Franco's Pet Store"
              className="w-36 h-36 md:w-44 md:h-44 rounded-2xl object-cover flex-shrink-0 shadow-sm"
              data-testid="img-pet-store-logo"
            />
            <div className="text-center md:text-left space-y-3">
              <h2 className="text-xl font-bold text-foreground font-display">From Montana Ranches to Your Pet's Bowl</h2>
              <p className="text-muted-foreground leading-relaxed">
                Franco's Pet Store offers premium raw freeze-dried beef liver and beef heart — two of the most nutrient-dense organ meats on earth — sourced exclusively from Montana and regional American ranches. We know exactly where every batch starts, because transparency is a family value, not a marketing line.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We believe your pets deserve the same quality food you eat. Our treats are made from real, wholesome, people-grade ingredients with <strong className="text-foreground">zero preservatives, zero fillers, zero foreign sourcing</strong> — and packaged in environmentally responsible materials that are better for the planet too.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                <Link href="/why-freeze-dried">
                  <Button variant="outline" size="sm" className="gap-1" data-testid="button-why-freeze-dried">
                    <Snowflake className="h-4 w-4" /> Why Freeze-Dried? <ChevronRight className="h-3 w-3" />
                  </Button>
                </Link>
                <Link href="/environmental">
                  <Button variant="outline" size="sm" className="gap-1" data-testid="button-eco-packaging">
                    <Leaf className="h-4 w-4" /> Eco Packaging <ChevronRight className="h-3 w-3" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* 5-card feature grid */}
        <section className="mb-12">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
              <Card className="h-full" data-testid="card-all-natural">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                    <Leaf className="h-6 w-6 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="font-bold text-foreground">All Natural</h3>
                  <p className="text-sm text-muted-foreground">
                    Made from human-grade food with zero preservatives, fillers, or artificial ingredients. One ingredient. That's it.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
              <Card className="h-full" data-testid="card-usa-made">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/30">
                    <Flag className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Grown & Made in the USA</h3>
                  <p className="text-sm text-muted-foreground">
                    100% American cattle — raised, processed, and packaged in the USA. We never source organ meats from overseas where contamination standards differ.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
              <Card className="h-full border-red-100 dark:border-red-900/40" data-testid="card-heavy-metal-free">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                    <ShieldCheck className="h-6 w-6 text-red-600 dark:text-red-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Heavy Metal Free</h3>
                  <p className="text-sm text-muted-foreground">
                    Liver and heart sourced from China can carry Lead, Cadmium, Mercury, Arsenic, and Chromium from industrial contamination. Ours is Montana-raised — clean by design.
                  </p>
                  <Link href="/why-freeze-dried">
                    <span className="text-xs text-primary underline cursor-pointer">Learn more →</span>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
              <Card className="h-full" data-testid="card-local-sourced">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                    <MapPin className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Regionally Sourced</h3>
                  <p className="text-sm text-muted-foreground">
                    Meats from Montana and regional ranches, ensuring freshness, traceability, and the highest quality for your pet.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
              <Card className="h-full" data-testid="card-eco-packaging">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                    <Package className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Less Packaging. More Treats.</h3>
                  <p className="text-sm text-muted-foreground">
                    Our eco-friendly packaging uses less material than the competition — but you get the same generous amount of treats. Better for the planet, better for your wallet.
                  </p>
                  <Link href="/environmental">
                    <span className="text-xs text-primary underline cursor-pointer">See our initiative →</span>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}>
              <Card className="h-full" data-testid="card-freeze-dried">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-sky-100 dark:bg-sky-900/30">
                    <Snowflake className="h-6 w-6 text-sky-600 dark:text-sky-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Freeze-Dried Nutrition</h3>
                  <p className="text-sm text-muted-foreground">
                    Retains up to 97% of natural nutrients — vitamins, enzymes, and amino acids intact. Raw nutrition without the raw food handling risk.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* Safety callout banner */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-12"
          data-testid="section-safety-callout"
        >
          <div className="rounded-2xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 p-6 md:p-8">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40 flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-amber-600 dark:text-amber-400" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-bold text-amber-900 dark:text-amber-100">
                  Know Where Your Pet's Treats Come From
                </h3>
                <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                  Many popular pet treats — including freeze-dried liver and heart — are sourced from China and other countries with less stringent food safety standards. Studies have documented elevated levels of <strong>Lead (Pb), Cadmium (Cd), Mercury (Hg), Arsenic (As), and Chromium (Cr)</strong> in organ meats from industrially contaminated regions. These heavy metals accumulate in organ tissue and can cause serious long-term harm to your pet.
                </p>
                <p className="text-sm font-semibold text-amber-900 dark:text-amber-100 mt-2">
                  Franco's uses only Montana and USA-raised cattle. Clean land. Clean feed. Clean treats.
                </p>
                <Link href="/why-freeze-dried">
                  <Button size="sm" variant="outline" className="mt-2 border-amber-300 text-amber-800 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/40" data-testid="button-learn-safety">
                    Read About Our Sourcing Standards <ChevronRight className="h-3 w-3 ml-1" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Products */}
        <section className="mb-16">
          <div className="mb-8 flex items-center gap-4">
            <PawPrint className="h-6 w-6 text-primary" />
            <h2 className="text-3xl font-bold text-foreground font-display">Our Treats</h2>
            <div className="h-px flex-1 bg-border" />
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {isLoading
              ? Array(1).fill(0).map((_, i) => (
                  <div key={i} className="space-y-4 rounded-3xl bg-white p-6 shadow-sm">
                    <Skeleton className="aspect-[4/3] w-full rounded-xl" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                ))
              : petTreats.map((item) => <MenuItemCard key={item.id} item={item} isPetTreat />)
            }
          </div>
        </section>

        <p className="text-center text-sm text-muted-foreground mt-8 italic" data-testid="text-image-disclaimer">
          All product images have been created using AI and may not be the exact same as the actual product.
        </p>
      </main>

      <footer className="border-t bg-muted/30 py-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground text-center">Franco's Pet Store. All Rights Reserved.</p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Pet Store, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80" data-testid="link-terms">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80" data-testid="link-privacy">Privacy Policy</Link>.
            </p>
            <p className="text-center">
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80" data-testid="link-why-freeze-dried">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/environmental" className="text-primary underline hover:text-primary/80" data-testid="link-environmental">Environmental Initiative</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80" data-testid="link-our-story">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
