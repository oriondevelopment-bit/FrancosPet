import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Cookie, ShieldCheck, X } from "lucide-react";
import { acceptCookies, declineCookies, hasRespondedToCookies } from "@/lib/cookies";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!hasRespondedToCookies()) {
        setVisible(true);
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const isCheckoutPage = location === "/checkout";

  const handleAccept = () => {
    acceptCookies();
    setVisible(false);
    window.dispatchEvent(new Event("cookie-consent-changed"));
  };

  const handleDecline = () => {
    declineCookies();
    setVisible(false);
  };

  if (isCheckoutPage) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="fixed bottom-0 left-0 right-0 z-[100] p-4 md:p-6"
          data-testid="cookie-consent-banner"
        >
          <div className="mx-auto max-w-3xl rounded-2xl border bg-card shadow-2xl shadow-black/20 dark:shadow-black/50 overflow-hidden">
            <div className="p-5 md:p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 flex-shrink-0 mt-0.5">
                  <Cookie className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-lg font-bold text-foreground font-display" data-testid="text-cookie-title">
                      We Value Your Privacy
                    </h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 -mt-1 -mr-1 rounded-full"
                      onClick={handleDecline}
                      data-testid="button-cookie-close"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-cookie-message">
                    We use cookies to remember your preferences, keep your cart items saved between visits, and provide you with a better shopping experience. These are first-party cookies only — used solely to improve your time on our site.
                  </p>
                  <div className="flex items-center gap-2 text-sm bg-green-50 dark:bg-green-950/30 rounded-lg p-3 border border-green-200 dark:border-green-800" data-testid="text-cookie-privacy">
                    <ShieldCheck className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0" />
                    <span className="text-green-800 dark:text-green-300 font-medium">
                      Franco's Pet Store never sells, shares, or disseminates any of your personal information to third parties. Ever.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                    <Button
                      onClick={handleAccept}
                      className="gap-2"
                      data-testid="button-cookie-accept"
                    >
                      <Cookie className="h-4 w-4" />
                      Accept Cookies
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleDecline}
                      data-testid="button-cookie-decline"
                    >
                      No Thanks
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
