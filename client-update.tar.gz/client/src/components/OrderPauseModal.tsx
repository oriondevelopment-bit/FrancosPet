import { useQuery } from "@tanstack/react-query";
import { AlertCircle, Clock, Calendar } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface OrderStatusResponse {
  paused: boolean;
  isSunday?: boolean;
  message: string | null;
  resumeTime: string | null;
  startTime?: string | null;
  closedDay?: string | null;
}

export function OrderPauseBanner() {
  const { data: orderStatus } = useQuery<OrderStatusResponse>({
    queryKey: ["/api/order-status"],
    refetchInterval: 60000,
  });

  if (!orderStatus?.paused && !orderStatus?.isSunday) {
    return null;
  }

  const formatDateTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  };

  if (orderStatus.isSunday) {
    return (
      <Alert className="mb-6 border-blue-500 bg-blue-50 dark:bg-blue-950/30" data-testid="banner-sunday-notice">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800 dark:text-blue-200">
          Sunday Hours
        </AlertTitle>
        <AlertDescription className="text-blue-700 dark:text-blue-300">
          <p data-testid="text-sunday-message">We are closed on Sundays, but you can still place orders! Orders placed today will be processed on Monday and you'll be notified when your order is ready.</p>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert variant="destructive" className="mb-6 border-yellow-500 bg-yellow-50 dark:bg-yellow-950/30" data-testid="banner-order-paused">
      <AlertCircle className="h-4 w-4 text-yellow-600" />
      <AlertTitle className="text-yellow-800 dark:text-yellow-200">
        Orders Temporarily Paused
      </AlertTitle>
      <AlertDescription className="text-yellow-700 dark:text-yellow-300">
        <p className="mb-2" data-testid="text-pause-message">{orderStatus.message}</p>
        <div className="flex flex-wrap gap-4 text-sm">
          {orderStatus.startTime && (
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>Started: {formatDateTime(orderStatus.startTime)}</span>
            </div>
          )}
          {orderStatus.resumeTime && (
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>Resumes: {formatDateTime(orderStatus.resumeTime)}</span>
            </div>
          )}
        </div>
        <p className="mt-2 text-xs">You can still browse the menu and manage your account.</p>
      </AlertDescription>
    </Alert>
  );
}

export function useOrderPauseStatus() {
  const { data: orderStatus, isLoading } = useQuery<OrderStatusResponse>({
    queryKey: ["/api/order-status"],
    refetchInterval: 60000,
  });

  return {
    isPaused: orderStatus?.paused ?? false,
    isSunday: orderStatus?.isSunday ?? false,
    message: orderStatus?.message ?? null,
    resumeTime: orderStatus?.resumeTime ?? null,
    startTime: (orderStatus as any)?.startTime ?? null,
    closedDay: orderStatus?.closedDay ?? null,
    isLoading,
  };
}

export function OrderPauseModal() {
  return null;
}
