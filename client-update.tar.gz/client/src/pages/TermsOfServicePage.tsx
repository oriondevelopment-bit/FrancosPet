import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12 max-w-4xl mx-auto">
        <div className="rounded-3xl bg-white p-8 md:p-12 shadow-lg border border-border">
          <h1 className="text-4xl font-bold font-display mb-2 text-foreground">Terms of Service</h1>
          <p className="text-muted-foreground mb-8">Last Updated: March 6, 2026</p>

          <div className="prose prose-orange max-w-none space-y-6 text-foreground/80 leading-relaxed">
            <p>
              These Terms of Service ("Terms") govern your access to and use of the Replit mobile application (the "App") and any related services (collectively, the "Service") provided by Franco's Kitchen LLC, a limited liability company organized under the laws of the State of Wyoming, with its principal place of business in Montana ("Company," "we," "us," or "our").
            </p>
            <p>
              By downloading, installing, accessing, or using the Service, you agree to be bound by these Terms. If you do not agree, do not use the Service.
            </p>

            <div className="space-y-4">
              <section>
                <h2 className="text-xl font-bold text-foreground">1. Eligibility</h2>
                <p>You must be at least 18 years of age or the age of majority in your jurisdiction to use the Service.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">2. Use of the Service</h2>
                <p>The Service enables you to browse menus, place orders for baked pizzas, Italian meals, sauces, and related items prepared by Franco's Kitchen LLC or participating vendors, and arrange payment and delivery or pickup (as applicable). Orders are subject to availability and acceptance.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">3. Accounts</h2>
                <p>Certain features require account creation. You are responsible for maintaining the confidentiality of your account credentials and for all activities occurring under your account.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">4. Payments</h2>
                <p>Payments are processed via third-party providers. Prices include applicable taxes and fees unless otherwise indicated. You authorize charges to your selected payment method for orders, tips, delivery fees, service charges, and any additional amounts.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">5. Order Cancellations and Refunds</h2>
                <p>Cancellations are permitted only within a limited period (e.g., 5 minutes after placement) or as allowed by operational policies. Refunds are issued at our discretion or as mandated by law.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">6. SMS/Text Messaging Terms</h2>
                <p>By providing your mobile phone number and checking the SMS opt-in box during checkout or in your account settings, you expressly consent to receive automated text messages from Franco's Kitchen LLC at the number provided. You understand that:</p>
                <ul className="list-disc pl-6 space-y-2 mt-3">
                  <li><strong>Consent is not required</strong> to make a purchase. You may place orders without opting in to SMS notifications.</li>
                  <li><strong>Message types:</strong> You may receive order confirmations, order status updates (confirmed, ready, completed, shipped), pickup/delivery notifications, subscription renewal alerts, and (if separately opted in) promotional offers and deals.</li>
                  <li><strong>Message frequency:</strong> Message frequency varies. Transactional messages are sent based on your order activity (typically 2-5 messages per order). Promotional messages, if opted in, may be sent up to 4 times per month.</li>
                  <li><strong>Message and data rates may apply.</strong> Your mobile carrier's standard messaging and data rates apply to all SMS communications. Franco's Kitchen LLC is not responsible for carrier fees.</li>
                  <li><strong>Opt-out:</strong> You may opt out at any time by texting <strong>STOP</strong> to any message received from us, or by updating your SMS preferences in your account settings. You will receive a single confirmation message after opting out. No further messages will be sent unless you re-subscribe.</li>
                  <li><strong>Opt-in:</strong> You may re-subscribe at any time by enabling SMS notifications in your account settings or by opting in during checkout.</li>
                  <li><strong>Help:</strong> For assistance, text <strong>HELP</strong> to any message received from us, or email francoskitchenllc@gmail.com.</li>
                  <li><strong>Supported carriers:</strong> SMS services are supported on most major US wireless carriers including AT&T, Verizon, T-Mobile, Sprint, and others. Carriers are not liable for delayed or undelivered messages.</li>
                  <li><strong>Privacy:</strong> Your mobile number will not be sold, rented, or shared with third parties for their marketing purposes. Your number is shared only with our SMS service provider (Twilio) solely for message delivery. See our <Link href="/privacy" className="text-primary underline">Privacy Policy</Link> for details.</li>
                </ul>
                <p className="mt-3">By opting in, you acknowledge and agree to these SMS terms. If you do not agree, do not opt in to SMS notifications. Your consent to receive SMS is governed by these Terms, our Privacy Policy, and applicable law including the Telephone Consumer Protection Act (TCPA).</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">7. Food and Allergen Disclaimer</h2>
                <p>Food items may contain or come into contact with major allergens (e.g., milk, eggs, fish, crustacean shellfish, tree nuts, peanuts, wheat, soybeans, sesame). We provide allergen information based on available data, but we cannot guarantee accuracy or cross-contact prevention. Consult directly with us or review ingredients for specific concerns. Consumption of food involves inherent risks, including allergic reactions.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">8. Limitation of Liability</h2>
                <p>The Service is provided "as is" and "as available" without warranties of any kind, express or implied. To the maximum extent permitted by law, Franco's Kitchen LLC shall not be liable for indirect, incidental, special, consequential, or punitive damages arising from or related to the Service, including issues with food quality, delivery, accuracy of information, or health effects.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">9. Indemnification</h2>
                <p>You agree to indemnify and hold harmless Franco's Kitchen LLC, its officers, directors, employees, and agents from claims, losses, or damages arising from your use of the Service or violation of these Terms.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">10. Termination</h2>
                <p>We reserve the right to suspend or terminate access to the Service at any time, for any reason, without notice.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">11. Governing Law and Dispute Resolution</h2>
                <p>These Terms are governed by the laws of the State of Wyoming, without regard to conflict of laws principles. Any disputes shall be resolved exclusively in the state or federal courts located in Wyoming.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">12. Changes to Terms</h2>
                <p>We may revise these Terms periodically. Continued use of the Service after changes constitutes acceptance.</p>
              </section>
            </div>

            <p className="pt-4 border-t italic">
              By using the Service, you confirm that you have read, understood, and agree to these Terms.
            </p>

            <div className="pt-8 text-center">
              <Link href="/">
                <Button className="rounded-full px-8">Return to Home</Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t bg-muted/30 py-12 mt-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed text-center">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">&copy; 2026 Franco's Pet Store. All Rights Reserved.</p>
            <p>
              <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
