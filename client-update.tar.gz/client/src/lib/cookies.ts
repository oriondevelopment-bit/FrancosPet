export function setCookie(name: string, value: string, days: number = 365): void {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`;
}

export function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export function removeCookie(name: string): void {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`;
}

export function hasCookieConsent(): boolean {
  return getCookie("cookie_consent") === "accepted";
}

export function hasDeclinedCookies(): boolean {
  return getCookie("cookie_consent") === "declined";
}

export function hasRespondedToCookies(): boolean {
  const val = getCookie("cookie_consent");
  return val === "accepted" || val === "declined";
}

export function acceptCookies(): void {
  setCookie("cookie_consent", "accepted", 365);
}

export function declineCookies(): void {
  setCookie("cookie_consent", "declined", 30);
}
