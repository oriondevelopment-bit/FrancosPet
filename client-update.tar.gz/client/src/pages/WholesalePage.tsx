import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Loader2, Building2, ShoppingBag, User, Clock, Truck, CheckCircle, QrCode, Heart, Download, BarChart3, MousePointerClick } from "lucide-react";
import type { WholesaleCustomer, OrderWithItems, MenuItem, Charity } from "@shared/schema";
import { Link } from "wouter";
import { PdfDownloadCard } from "@/components/PdfDownloadCard";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

type RegistrationForm = {
  businessName: string;
  contactName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  taxId: string;
  charityId: string;
  donationPercentage: string;
};

type QrCodeData = {
  qrCode: string;
  url: string;
  refCode: string;
};

type DonationData = {
  charity: { id: number; name: string; description: string | null } | null;
  donationPercentage: number;
  totalDonated: number;
  donationOrders: {
    id: number;
    orderRef: string;
    totalAmount: number;
    charityDonationAmount: number;
    createdAt: string;
  }[];
};

type QrStatsData = {
  totalScans: number;
  convertedScans: number;
  conversionRate: number;
};

const formatPrice = (cents: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(cents / 100);
};

const formatDate = (date: string | Date) => {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};

export default function WholesalePage() {
  const { isLoading: authLoading, isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: wholesaleProfile, isLoading: profileLoading, error: profileError } = useQuery<WholesaleCustomer>({
    queryKey: ["/api/wholesale/profile"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: wholesaleOrders, isLoading: ordersLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/wholesale/orders"],
    enabled: isAuthenticated && wholesaleProfile?.isApproved,
  });

  const { data: menuItems } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu"],
  });

  const { data: charities } = useQuery<Charity[]>({
    queryKey: ["/api/charities"],
  });

  const { data: qrCodeData, isLoading: qrLoading } = useQuery<QrCodeData>({
    queryKey: ["/api/wholesale/qr-code"],
    enabled: isAuthenticated && wholesaleProfile?.isApproved === true,
  });

  const { data: donationData, isLoading: donationsLoading } = useQuery<DonationData>({
    queryKey: ["/api/wholesale/donations"],
    enabled: isAuthenticated && wholesaleProfile?.isApproved === true,
  });

  const { data: qrStats, isLoading: qrStatsLoading } = useQuery<QrStatsData>({
    queryKey: ["/api/wholesale/qr-stats"],
    enabled: isAuthenticated && wholesaleProfile?.isApproved === true,
  });

  const activeCharities = charities?.filter((c) => c.isActive) || [];

  const registrationForm = useForm<RegistrationForm>({
    defaultValues: {
      businessName: "",
      contactName: user ? `${user.firstName || ""} ${user.lastName || ""}`.trim() : "",
      phone: "",
      email: user?.email || "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      taxId: "",
      charityId: "",
      donationPercentage: "0",
    },
  });

  const profileForm = useForm<RegistrationForm>();

  useEffect(() => {
    if (user) {
      registrationForm.setValue("contactName", `${user.firstName || ""} ${user.lastName || ""}`.trim());
      registrationForm.setValue("email", user.email || "");
    }
  }, [user, registrationForm]);

  useEffect(() => {
    if (wholesaleProfile) {
      profileForm.reset({
        businessName: wholesaleProfile.businessName,
        contactName: wholesaleProfile.contactName,
        phone: wholesaleProfile.phone,
        email: wholesaleProfile.email,
        address: wholesaleProfile.address,
        city: wholesaleProfile.city,
        state: wholesaleProfile.state,
        zipCode: wholesaleProfile.zipCode,
        taxId: wholesaleProfile.taxId || "",
        charityId: wholesaleProfile.charityId ? String(wholesaleProfile.charityId) : "",
        donationPercentage: String(wholesaleProfile.donationPercentage || 0),
      });
    }
  }, [wholesaleProfile, profileForm]);

  const prepareSubmitData = (data: RegistrationForm) => {
    return {
      ...data,
      charityId: data.charityId ? Number(data.charityId) : null,
      donationPercentage: Number(data.donationPercentage) || 0,
    };
  };

  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationForm) => {
      return await apiRequest("/api/wholesale/register", {
        method: "POST",
        body: JSON.stringify(prepareSubmitData(data)),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wholesale/profile"] });
      toast({ title: "Registration Submitted", description: "Your wholesale application is pending approval." });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: RegistrationForm) => {
      return await apiRequest("/api/wholesale/profile", {
        method: "PATCH",
        body: JSON.stringify(prepareSubmitData(data)),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wholesale/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wholesale/donations"] });
      toast({ title: "Updated", description: "Your profile has been updated." });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const isRegistered = !!wholesaleProfile;
  const isPending = wholesaleProfile && !wholesaleProfile.isApproved;
  const isApproved = wholesaleProfile?.isApproved;

  const charitySelectField = (form: ReturnType<typeof useForm<RegistrationForm>>, idPrefix: string) => {
    const selectedCharityId = form.watch("charityId");
    const selectedCharity = selectedCharityId ? activeCharities.find(c => c.id === Number(selectedCharityId)) : null;
    return (
      <>
        <div className="grid gap-2">
          <Label htmlFor={`${idPrefix}CharityId`}>Support a Charity (Optional)</Label>
          <Select
            value={form.watch("charityId") || ""}
            onValueChange={(val) => form.setValue("charityId", val === "none" ? "" : val)}
          >
            <SelectTrigger data-testid={`select-${idPrefix}-charity`}>
              <SelectValue placeholder="Select a charity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No charity selected</SelectItem>
              {activeCharities.map((charity) => (
                <SelectItem key={charity.id} value={String(charity.id)}>
                  {charity.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {selectedCharity && (
          <div className="rounded-lg border bg-muted/50 p-4 space-y-1" data-testid={`${idPrefix}-charity-details`}>
            <p className="font-medium text-sm">{(selectedCharity as any).name}</p>
            {(selectedCharity as any).ein && (
              <p className="text-xs text-muted-foreground">Tax ID (EIN): {(selectedCharity as any).ein}</p>
            )}
            {((selectedCharity as any).address || (selectedCharity as any).city) && (
              <p className="text-xs text-muted-foreground">
                {(selectedCharity as any).address}{(selectedCharity as any).address && (selectedCharity as any).city ? ", " : ""}
                {(selectedCharity as any).city}{(selectedCharity as any).state ? `, ${(selectedCharity as any).state}` : ""}{(selectedCharity as any).zipCode ? ` ${(selectedCharity as any).zipCode}` : ""}
              </p>
            )}
            {((selectedCharity as any).contactName || (selectedCharity as any).contactPhone || (selectedCharity as any).contactEmail) && (
              <p className="text-xs text-muted-foreground">
                {(selectedCharity as any).contactName}{(selectedCharity as any).contactPhone ? ` · ${(selectedCharity as any).contactPhone}` : ""}{(selectedCharity as any).contactEmail ? ` · ${(selectedCharity as any).contactEmail}` : ""}
              </p>
            )}
            {(selectedCharity as any).website && (
              <a href={(selectedCharity as any).website} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline">
                {(selectedCharity as any).website}
              </a>
            )}
          </div>
        )}
        <div className="grid gap-2">
          <Label htmlFor={`${idPrefix}DonationPercentage`}>Donation Percentage</Label>
          <Input
            id={`${idPrefix}DonationPercentage`}
            type="number"
            min="0"
            max="100"
            {...form.register("donationPercentage")}
            placeholder="0"
            data-testid={`input-${idPrefix}-donation-percentage`}
          />
          <p className="text-xs text-muted-foreground">Percentage of each order to donate (0-100)</p>
        </div>
      </>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container px-4 py-8 md:px-6 md:py-12">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display flex items-center gap-3" data-testid="text-page-title">
              <Building2 className="h-8 w-8 text-primary" />
              Wholesale Portal
            </h1>
            <p className="text-muted-foreground mt-2">
              Bulk ordering for businesses with special pricing and delivery options
            </p>
          </div>

          {!isRegistered && (
            <Card className="max-w-2xl">
              <CardHeader>
                <CardTitle>Register as Wholesale Customer</CardTitle>
                <CardDescription>
                  Fill out this form to apply for a wholesale account. Once approved, you'll have access to bulk ordering with special pricing.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={registrationForm.handleSubmit((data) => registerMutation.mutate(data))} className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="businessName">Business Name *</Label>
                    <Input id="businessName" {...registrationForm.register("businessName", { required: true })} placeholder="Your Business LLC" data-testid="input-business-name" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="contactName">Contact Name *</Label>
                      <Input id="contactName" {...registrationForm.register("contactName", { required: true })} placeholder="John Doe" data-testid="input-contact-name" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="phone">Phone *</Label>
                      <Input id="phone" type="tel" {...registrationForm.register("phone", { required: true })} placeholder="(555) 123-4567" data-testid="input-phone" />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" type="email" {...registrationForm.register("email", { required: true })} placeholder="wholesale@business.com" data-testid="input-email" />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="address">Business Address *</Label>
                    <Input id="address" {...registrationForm.register("address", { required: true })} placeholder="123 Business St" data-testid="input-address" />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="city">City *</Label>
                      <Input id="city" {...registrationForm.register("city", { required: true })} placeholder="Glendive" data-testid="input-city" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="state">State *</Label>
                      <Input id="state" {...registrationForm.register("state", { required: true })} placeholder="MT" maxLength={2} data-testid="input-state" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="zipCode">ZIP Code *</Label>
                      <Input id="zipCode" {...registrationForm.register("zipCode", { required: true })} placeholder="59330" data-testid="input-zip" />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="taxId">Tax ID / EIN (Optional)</Label>
                    <Input id="taxId" {...registrationForm.register("taxId")} placeholder="XX-XXXXXXX" data-testid="input-tax-id" />
                  </div>

                  {charitySelectField(registrationForm, "reg")}

                  <div className="bg-muted/50 p-4 rounded-lg text-sm space-y-2">
                    <p className="font-medium">Wholesale Benefits:</p>
                    <ul className="list-disc list-inside text-muted-foreground space-y-1">
                      <li>2-week advance ordering for better planning</li>
                      <li>Free delivery on orders of 100+ units within 25 miles</li>
                      <li>Bulk order tracking and history</li>
                      <li>Dedicated wholesale support</li>
                    </ul>
                  </div>

                  <Button type="submit" className="w-full" disabled={registerMutation.isPending} data-testid="button-register">
                    {registerMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      "Submit Application"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          {isPending && (
            <Card className="max-w-2xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-yellow-500" />
                  Application Pending
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Your wholesale application is being reviewed. We'll notify you once it's approved.
                </p>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="font-medium">{wholesaleProfile.businessName}</p>
                  <p className="text-sm text-muted-foreground">{wholesaleProfile.email}</p>
                  <p className="text-sm text-muted-foreground">
                    {wholesaleProfile.address}, {wholesaleProfile.city}, {wholesaleProfile.state} {wholesaleProfile.zipCode}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {isApproved && (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="dashboard" className="flex items-center gap-2" data-testid="tab-dashboard">
                  <Building2 className="h-4 w-4" /> Dashboard
                </TabsTrigger>
                <TabsTrigger value="orders" className="flex items-center gap-2" data-testid="tab-orders">
                  <ShoppingBag className="h-4 w-4" /> Order History
                </TabsTrigger>
                <TabsTrigger value="donations" className="flex items-center gap-2" data-testid="tab-donations">
                  <Heart className="h-4 w-4" /> Donations
                </TabsTrigger>
                <TabsTrigger value="profile" className="flex items-center gap-2" data-testid="tab-profile">
                  <User className="h-4 w-4" /> Profile
                </TabsTrigger>
              </TabsList>

              <TabsContent value="dashboard" className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Total Orders</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-2xl font-bold">{wholesaleOrders?.length || 0}</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                        <CheckCircle className="h-3 w-3 mr-1" /> Approved
                      </Badge>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Business</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-lg font-semibold truncate">{wholesaleProfile?.businessName}</p>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Order</CardTitle>
                    <CardDescription>Start a new bulk order with 2-week advance scheduling</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col gap-4">
                      <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Truck className="h-4 w-4 text-primary" />
                          <span className="font-medium">Free Delivery:</span>
                          <span className="text-muted-foreground">Orders of 100+ units within 25 miles</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-primary" />
                          <span className="font-medium">Lead Time:</span>
                          <span className="text-muted-foreground">2 weeks advance ordering</span>
                        </div>
                      </div>
                      <Link href="/wholesale/order">
                        <Button className="w-full" data-testid="button-new-order">
                          <ShoppingBag className="h-4 w-4 mr-2" />
                          Start New Bulk Order
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <QrCode className="h-5 w-5" />
                      My QR Code
                    </CardTitle>
                    <CardDescription>Share this QR code with your customers to track referrals</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {qrLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    ) : qrCodeData ? (
                      <div className="flex flex-col items-center gap-4">
                        <div className="border rounded-lg p-4 bg-white">
                          <img
                            src={qrCodeData.qrCode}
                            alt="Wholesale QR Code"
                            className="w-48 h-48"
                            data-testid="img-qr-code"
                          />
                        </div>
                        <p className="text-sm text-muted-foreground text-center break-all" data-testid="text-qr-url">
                          {qrCodeData.url}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Ref Code: <span className="font-mono font-medium" data-testid="text-ref-code">{qrCodeData.refCode}</span>
                        </p>
                        <a
                          href={qrCodeData.qrCode}
                          download={`qr-code-${qrCodeData.refCode}.png`}
                        >
                          <Button variant="outline" data-testid="button-download-qr">
                            <Download className="h-4 w-4 mr-2" />
                            Download QR Code
                          </Button>
                        </a>
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-4">QR code not available</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="orders" className="space-y-4">
                <PdfDownloadCard 
                  apiEndpoint="/api/wholesale/orders/pdf"
                  title="Download Wholesale Purchase History"
                  description="Generate a PDF report of your wholesale orders for a specific date range"
                />
                
                <Card>
                  <CardHeader>
                    <CardTitle>Order History</CardTitle>
                    <CardDescription>View all your previous wholesale orders</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {ordersLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    ) : wholesaleOrders && wholesaleOrders.length > 0 ? (
                      <div className="space-y-4">
                        {wholesaleOrders.map((order) => {
                          const totalUnits = order.items.reduce((sum, item) => sum + item.quantity, 0);
                          return (
                            <div key={order.id} className="border rounded-lg p-4" data-testid={`order-${order.id}`}>
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <p className="font-medium">{order.orderRef || `Order #${order.id}`}</p>
                                  <p className="text-sm text-muted-foreground">{formatDate(order.createdAt!)}</p>
                                </div>
                                <div className="text-right">
                                  <Badge variant={order.status === "completed" ? "default" : "secondary"}>
                                    {order.status}
                                  </Badge>
                                  <p className="text-lg font-bold mt-1">{formatPrice(order.totalAmount)}</p>
                                </div>
                              </div>
                              <div className="text-sm space-y-1">
                                <p className="text-muted-foreground">
                                  {totalUnits} units total
                                  {order.isDelivery && " \u2022 Delivery"}
                                </p>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  {order.items.map((item, idx) => (
                                    <Badge key={idx} variant="outline">
                                      {item.menuItem?.name} x{item.quantity}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">No orders yet</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="donations" className="space-y-6">
                {donationsLoading || qrStatsLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <>
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-muted-foreground">Charity</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-lg font-semibold" data-testid="text-charity-name">
                            {donationData?.charity?.name || "None selected"}
                          </p>
                          <p className="text-sm text-muted-foreground" data-testid="text-donation-percentage">
                            {donationData?.donationPercentage || 0}% of orders
                          </p>
                          {donationData?.charity && (
                            <div className="mt-2 space-y-0.5 text-xs text-muted-foreground" data-testid="text-charity-details">
                              {(donationData.charity as any).ein && <p>EIN: {(donationData.charity as any).ein}</p>}
                              {((donationData.charity as any).address || (donationData.charity as any).city) && (
                                <p>
                                  {(donationData.charity as any).address}{(donationData.charity as any).address && (donationData.charity as any).city ? ", " : ""}
                                  {(donationData.charity as any).city}{(donationData.charity as any).state ? `, ${(donationData.charity as any).state}` : ""}{(donationData.charity as any).zipCode ? ` ${(donationData.charity as any).zipCode}` : ""}
                                </p>
                              )}
                              {(donationData.charity as any).contactName && <p>{(donationData.charity as any).contactName}</p>}
                              {(donationData.charity as any).contactPhone && <p>{(donationData.charity as any).contactPhone}</p>}
                              {(donationData.charity as any).contactEmail && <p>{(donationData.charity as any).contactEmail}</p>}
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-muted-foreground">Total Donated</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold text-green-600 dark:text-green-400" data-testid="text-total-donated">
                            {formatPrice(donationData?.totalDonated || 0)}
                          </p>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-muted-foreground">Orders with Donations</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold" data-testid="text-donation-order-count">
                            {donationData?.donationOrders?.length || 0}
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <MousePointerClick className="h-5 w-5" />
                          QR Code Scan Stats
                        </CardTitle>
                        <CardDescription>Track how your QR code is performing</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="bg-muted/50 p-4 rounded-lg text-center">
                            <p className="text-2xl font-bold" data-testid="text-total-scans">{qrStats?.totalScans || 0}</p>
                            <p className="text-sm text-muted-foreground">Total Scans</p>
                          </div>
                          <div className="bg-muted/50 p-4 rounded-lg text-center">
                            <p className="text-2xl font-bold" data-testid="text-converted-scans">{qrStats?.convertedScans || 0}</p>
                            <p className="text-sm text-muted-foreground">Converted to Orders</p>
                          </div>
                          <div className="bg-muted/50 p-4 rounded-lg text-center">
                            <p className="text-2xl font-bold" data-testid="text-conversion-rate">{(qrStats?.conversionRate || 0).toFixed(1)}%</p>
                            <p className="text-sm text-muted-foreground">Conversion Rate</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {donationData?.donationOrders && donationData.donationOrders.length > 0 && (
                      <>
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <BarChart3 className="h-5 w-5" />
                              Donation History
                            </CardTitle>
                            <CardDescription>Donations per order</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="h-64" data-testid="chart-donation-history">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={donationData.donationOrders.map((o) => ({
                                  name: o.orderRef || "Order",
                                  donation: o.charityDonationAmount / 100,
                                }))}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="name" fontSize={12} />
                                  <YAxis fontSize={12} tickFormatter={(v) => `$${v}`} />
                                  <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, "Donation"]} />
                                  <Bar dataKey="donation" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle>Per-Order Breakdown</CardTitle>
                            <CardDescription>Donation details for each order</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {donationData.donationOrders.map((order, idx) => (
                                <div key={idx} className="flex items-center justify-between border rounded-lg p-3" data-testid={`donation-order-${idx}`}>
                                  <div>
                                    <p className="font-medium">{order.orderRef || "Order"}</p>
                                    <p className="text-sm text-muted-foreground">{formatDate(order.createdAt)}</p>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm text-muted-foreground">Order: {formatPrice(order.totalAmount)}</p>
                                    <p className="font-semibold text-green-600 dark:text-green-400">
                                      Donated: {formatPrice(order.charityDonationAmount)}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </>
                    )}

                    {(!donationData?.donationOrders || donationData.donationOrders.length === 0) && (
                      <Card>
                        <CardContent className="py-8">
                          <p className="text-center text-muted-foreground">No donation history yet. Set a charity and donation percentage in your profile to get started.</p>
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </TabsContent>

              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle>Business Profile</CardTitle>
                    <CardDescription>Update your wholesale account information</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={profileForm.handleSubmit((data) => updateProfileMutation.mutate(data))} className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="profileBusinessName">Business Name</Label>
                        <Input id="profileBusinessName" {...profileForm.register("businessName")} data-testid="input-profile-business" />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="profileContactName">Contact Name</Label>
                          <Input id="profileContactName" {...profileForm.register("contactName")} data-testid="input-profile-contact" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="profilePhone">Phone</Label>
                          <Input id="profilePhone" type="tel" {...profileForm.register("phone")} data-testid="input-profile-phone" />
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="profileEmail">Email</Label>
                        <Input id="profileEmail" type="email" {...profileForm.register("email")} data-testid="input-profile-email" />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="profileAddress">Address</Label>
                        <Input id="profileAddress" {...profileForm.register("address")} data-testid="input-profile-address" />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="profileCity">City</Label>
                          <Input id="profileCity" {...profileForm.register("city")} data-testid="input-profile-city" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="profileState">State</Label>
                          <Input id="profileState" {...profileForm.register("state")} maxLength={2} data-testid="input-profile-state" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="profileZipCode">ZIP Code</Label>
                          <Input id="profileZipCode" {...profileForm.register("zipCode")} data-testid="input-profile-zip" />
                        </div>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="profileTaxId">Tax ID / EIN</Label>
                        <Input id="profileTaxId" {...profileForm.register("taxId")} data-testid="input-profile-taxid" />
                      </div>

                      {charitySelectField(profileForm, "profile")}

                      <Button type="submit" disabled={updateProfileMutation.isPending} data-testid="button-update-profile">
                        {updateProfileMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          "Save Changes"
                        )}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
    </div>
  );
}
