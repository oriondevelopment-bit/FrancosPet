import { useEffect, useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, CreditCard, CheckCircle } from "lucide-react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "paypal-button": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

interface PayPalCheckoutProps {
  amount: string;
  currency: string;
  onPaymentSuccess: (paypalOrderId: string) => void;
  onPaymentError: (error: string) => void;
  disabled?: boolean;
}

export default function PayPalCheckout({
  amount,
  currency,
  onPaymentSuccess,
  onPaymentError,
  disabled = false,
}: PayPalCheckoutProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [venmoAvailable, setVenmoAvailable] = useState(false);
  const buttonRef = useRef<HTMLElement | null>(null);
  const paypalCheckoutRef = useRef<any>(null);
  const venmoCheckoutRef = useRef<any>(null);
  const isInitializedRef = useRef(false);

  const createOrder = async () => {
    const orderPayload = {
      amount: amount,
      currency: currency,
      intent: "CAPTURE",
    };
    const response = await fetch("/paypal/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload),
    });
    const output = await response.json();
    if (!response.ok) {
      throw new Error(output.error || "Failed to create PayPal order");
    }
    return { orderId: output.id };
  };

  const captureOrder = async (orderId: string) => {
    const response = await fetch(`/paypal/order/${orderId}/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Failed to capture payment");
    }
    return data;
  };

  const onApprove = async (data: any) => {
    setIsProcessing(true);
    setError(null);
    try {
      const orderData = await captureOrder(data.orderId);
      if (orderData.status === "COMPLETED") {
        setPaymentComplete(true);
        onPaymentSuccess(data.orderId);
      } else {
        throw new Error("Payment was not completed");
      }
    } catch (err: any) {
      setError(err.message || "Payment failed");
      onPaymentError(err.message || "Payment failed");
    } finally {
      setIsProcessing(false);
    }
  };

  const onCancel = async () => {
    setError("Payment was cancelled");
  };

  const onError = async (data: any) => {
    console.error("PayPal Error:", data);
    setError("Payment failed. Please try again.");
    onPaymentError("Payment failed. Please try again.");
  };

  useEffect(() => {
    if (isInitializedRef.current) return;
    
    const loadPayPalSDK = async () => {
      try {
        const sdkUrl = "https://www.paypal.com/web-sdk/v6/core";
        
        if (!(window as any).paypal) {
          const script = document.createElement("script");
          script.src = sdkUrl;
          script.async = true;
          script.onload = () => initPayPal();
          document.body.appendChild(script);
        } else {
          await initPayPal();
        }
      } catch (e) {
        console.error("Failed to load PayPal SDK", e);
        setError("Failed to load PayPal");
        setIsLoading(false);
      }
    };

    loadPayPalSDK();
  }, []);

  const initPayPal = async () => {
    if (isInitializedRef.current) return;
    isInitializedRef.current = true;
    
    try {
      const clientToken: string = await fetch("/paypal/setup")
        .then((res) => res.json())
        .then((data) => {
          return data.clientToken;
        });
        
      const sdkInstance = await (window as any).paypal.createInstance({
        clientToken,
        components: ["paypal-payments", "venmo-payments"],
      });

      paypalCheckoutRef.current = sdkInstance.createPayPalOneTimePaymentSession({
        onApprove,
        onCancel,
        onError,
      });

      try {
        venmoCheckoutRef.current = sdkInstance.createVenmoOneTimePaymentSession({
          onApprove,
          onCancel,
          onError,
        });
        setVenmoAvailable(true);
      } catch (venmoErr) {
        console.warn("Venmo not available:", venmoErr);
        setVenmoAvailable(false);
      }

      setIsLoading(false);
    } catch (e) {
      console.error("Failed to initialize PayPal:", e);
      setError("Failed to initialize PayPal");
      setIsLoading(false);
    }
  };

  const handlePayPalClick = async () => {
    if (disabled || isProcessing || paymentComplete || !paypalCheckoutRef.current) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const checkoutOptionsPromise = createOrder();
      await paypalCheckoutRef.current.start(
        { paymentFlow: "auto" },
        checkoutOptionsPromise,
      );
    } catch (e: any) {
      console.error("PayPal checkout error:", e);
      if (e.message !== "Detected popup close") {
        setError(e.message || "Checkout failed");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVenmoClick = async () => {
    if (disabled || isProcessing || paymentComplete || !venmoCheckoutRef.current) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const checkoutOptionsPromise = createOrder();
      await venmoCheckoutRef.current.start(
        { paymentFlow: "auto" },
        checkoutOptionsPromise,
      );
    } catch (e: any) {
      console.error("Venmo checkout error:", e);
      if (e.message !== "Detected popup close") {
        setError(e.message || "Checkout failed");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  if (paymentComplete) {
    return (
      <div className="flex items-center justify-center gap-2 p-4 bg-green-50 dark:bg-green-950 rounded-xl border border-green-200 dark:border-green-800">
        <CheckCircle className="h-5 w-5 text-green-600" />
        <span className="font-medium text-green-800 dark:text-green-200">
          Payment Verified
        </span>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
        <span className="ml-2 text-muted-foreground">Loading payment options...</span>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Button
        type="button"
        onClick={handlePayPalClick}
        disabled={disabled || isProcessing}
        className="w-full rounded-xl py-6 text-lg font-bold bg-[#0070ba] hover:bg-[#005ea6] text-white shadow-lg"
        data-testid="button-paypal-pay"
      >
        {isProcessing ? (
          <>
            <Loader2 className="h-5 w-5 mr-2 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <CreditCard className="h-5 w-5 mr-2" />
            Pay with PayPal
          </>
        )}
      </Button>

      {venmoAvailable && (
        <Button
          type="button"
          onClick={handleVenmoClick}
          disabled={disabled || isProcessing}
          className="w-full rounded-xl py-6 text-lg font-bold bg-[#008CFF] hover:bg-[#0074D4] text-white shadow-lg"
          data-testid="button-venmo-pay"
        >
          {isProcessing ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.849 2c.94 1.55 1.364 3.15 1.364 5.17 0 6.44-5.498 14.81-9.964 20.67H4.42L1.003 3.39l6.14-.58 1.94 15.56C11.147 14.57 13.7 8.83 13.7 5.37c0-1.33-.232-2.36-.585-3.21L19.849 2z"/>
              </svg>
              Pay with Venmo
            </>
          )}
        </Button>
      )}
      
      {error && (
        <div className="p-3 bg-red-50 dark:bg-red-950 rounded-lg border border-red-200 dark:border-red-800">
          <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
        </div>
      )}
    </div>
  );
}
