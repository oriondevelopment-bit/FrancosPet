import { Navigation } from "@/components/Navigation";
import { PetStoreSubNav } from "@/components/PetStoreSubNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  Recycle, Leaf, TreePine, Package, PawPrint, ChevronRight,
  Globe, Droplets, Wind, ShieldAlert, CheckCircle2, X, Scale
} from "lucide-react";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.4 },
});

export default function EnvironmentalPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      <PetStoreSubNav />

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 via-background to-emerald-500/10 dark:from-green-500/5 dark:via-background dark:to-emerald-500/5" />
          <div className="container relative px-4 py-16 md:py-24 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <motion.div {...fadeUp(0)} className="mb-6">
                <Recycle className="h-12 w-12 mx-auto text-green-600 dark:text-green-400 mb-4" />
              </motion.div>
              <motion.h1
                {...fadeUp(0.1)}
                className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-5xl font-display"
                data-testid="heading-environmental"
              >
                Environmental Initiative
              </motion.h1>
              <motion.p
                {...fadeUp(0.15)}
                className="mx-auto max-w-2xl text-xl text-primary font-medium italic font-display"
                data-testid="text-hero-subtitle"
              >
                Biodegradable Packaging: Better for Pets, Better for the Planet
              </motion.p>
              <motion.p
                {...fadeUp(0.2)}
                className="mx-auto max-w-2xl text-lg text-muted-foreground leading-relaxed mt-4"
              >
                Giving back isn't just about writing checks — it's about the choices we make every single day. That's why Franco's Pet Store uses biodegradable packaging whenever possible, because we believe protecting the environment is part of protecting the animals we love.
              </motion.p>
            </div>
          </div>
        </section>

        <section className="container px-4 md:px-6 pb-16">
          <div className="mx-auto max-w-4xl">

            <motion.div {...fadeUp(0.3)} className="mb-16">
              <div className="bg-gradient-to-br from-green-500/5 via-muted/30 to-primary/5 dark:from-green-500/10 dark:via-muted/20 dark:to-primary/10 rounded-2xl p-8 md:p-10 border">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-foreground flex items-center gap-2 text-lg">
                      <Leaf className="h-5 w-5 text-green-600 dark:text-green-400" />
                      Our Approach
                    </h3>
                    <ul className="space-y-3">
                      {[
                        "Biodegradable and compostable packaging materials that break down naturally",
                        "Plant-based inks and adhesives free of harmful chemicals",
                        "Minimal packaging philosophy — we use only what's needed to keep treats fresh and safe",
                        "Recyclable outer shipping materials sourced from post-consumer content",
                      ].map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <TreePine className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-foreground flex items-center gap-2 text-lg">
                      <Package className="h-5 w-5 text-red-500" />
                      The Problem with Conventional Packaging
                    </h3>
                    <ul className="space-y-3">
                      {[
                        "Most pet treat packaging is made from non-recyclable plastics that sit in landfills for hundreds of years",
                        "Conventional plastic packaging can leach unhealthy off-gases and microplastics into the treats your animals eat",
                        "Those same microplastics break down into the soil and waterways, harming wildlife and ecosystems",
                        "Many competitors use the cheapest materials available with no regard for the environmental or health consequences",
                      ].map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <span className="text-red-500 flex-shrink-0 mt-0.5 font-bold">!</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Less Packaging, More Treats comparison */}
            <motion.div {...fadeUp(0.32)} className="mb-16" data-testid="section-packaging-comparison">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3">
                Less Packaging. Same Great Treats.
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                Most pet treat brands pad their packaging to look bigger on the shelf. We went the other direction — minimize the packaging, maximize what's inside.
              </p>

              <Card>
                <CardContent className="p-0 overflow-x-auto">
                  <table className="w-full text-sm" data-testid="table-packaging-comparison">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="text-left p-4 font-bold text-foreground min-w-[180px]"></th>
                        <th className="p-4 text-center font-bold text-foreground min-w-[180px]">
                          <div className="flex flex-col items-center gap-1">
                            <Leaf className="h-5 w-5 text-green-600" />
                            <span>Franco's Pet Store</span>
                          </div>
                        </th>
                        <th className="p-4 text-center font-bold text-muted-foreground min-w-[180px]">
                          <span>Typical Competitors</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { label: "Packaging Material", good: "Biodegradable, plant-based", bad: "Non-recyclable plastic bags" },
                        { label: "Package Size vs. Treat Amount", good: "Sized to fit the treats — no air padding", bad: "Oversized bags with extra air to look bigger" },
                        { label: "Treat Content (per oz)", good: "Same or more treats per ounce", bad: "Less product hidden in bulky packaging" },
                        { label: "Inks & Adhesives", good: "Plant-based, chemical-free", bad: "Petroleum-based inks and solvent adhesives" },
                        { label: "End-of-Life", good: "Breaks down in 6–12 months", bad: "Sits in a landfill for 400+ years" },
                        { label: "Microplastic Risk", good: "None — materials are naturally inert", bad: "Plastic degrades into microplastics over time" },
                      ].map((row, i) => (
                        <tr key={i} className={i % 2 === 0 ? "bg-background" : "bg-muted/20"}>
                          <td className="p-4 font-medium text-foreground">{row.label}</td>
                          <td className="p-4 text-center">
                            <span className="inline-flex items-center gap-1.5 text-green-600 dark:text-green-400">
                              <CheckCircle2 className="h-3.5 w-3.5" /> {row.good}
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                              <X className="h-3.5 w-3.5 text-red-400" /> {row.bad}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>

              <div className="mt-6 rounded-2xl bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 p-6 flex items-start gap-4">
                <Scale className="h-8 w-8 text-green-600 dark:text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-green-900 dark:text-green-100 mb-1">The Bottom Line</h3>
                  <p className="text-sm text-green-800 dark:text-green-200 leading-relaxed">
                    You pay for treats, not packaging. When competitors use oversized plastic bags filled with extra air, you're literally buying less product for the same price — and generating more landfill waste. Franco's treats come in right-sized, biodegradable packaging that uses less material and delivers every ounce you paid for. Better for your pet, your wallet, and the planet.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div {...fadeUp(0.35)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3" data-testid="heading-why-it-matters">
                Why It Matters
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                The choices we make as a company ripple outward into the world around us.
              </p>

              <div className="grid gap-5 sm:grid-cols-2">
                {[
                  {
                    icon: Droplets,
                    color: "text-blue-500",
                    bg: "bg-blue-100 dark:bg-blue-900/30",
                    title: "Microplastics Are a Real Threat",
                    content: "Studies have found microplastics in nearly every environment on Earth — from the deepest ocean trenches to remote mountain peaks. When pet food and treats are packaged in cheap, conventional plastics, those materials begin to degrade over time, releasing microscopic particles that can end up in your pet's food. By choosing biodegradable packaging, we eliminate this risk at the source.",
                  },
                  {
                    icon: Wind,
                    color: "text-amber-500",
                    bg: "bg-amber-100 dark:bg-amber-900/30",
                    title: "Off-Gassing Puts Animals at Risk",
                    content: "Many plastic packaging materials release volatile organic compounds (VOCs) as they age, especially in warm environments like storage areas, truck beds during shipping, or even your pantry shelf. These off-gases can contaminate the treats inside, potentially causing digestive issues, allergic reactions, or long-term health concerns. Our biodegradable materials are naturally inert and don't produce these harmful emissions.",
                  },
                  {
                    icon: Globe,
                    color: "text-green-500",
                    bg: "bg-green-100 dark:bg-green-900/30",
                    title: "The Environment Deserves Better",
                    content: "Every piece of conventional plastic packaging that enters a landfill will outlive the pet it was made for — by centuries. We refuse to accept that as the cost of doing business. Our biodegradable packaging breaks down naturally, returning to the earth without leaving toxic residues behind. It's a small change that makes a big difference when multiplied across thousands of orders.",
                  },
                  {
                    icon: ShieldAlert,
                    color: "text-purple-500",
                    bg: "bg-purple-100 dark:bg-purple-900/30",
                    title: "Service to All Living Things",
                    content: "Our commitment to giving back extends beyond charitable donations. By choosing sustainable packaging, supporting local ranchers, sourcing from Montana and regional suppliers, and treating every animal — from the cattle on the ranch to the dog on your couch — with dignity and respect, we practice our values in everything we do. We believe that service to our community and all living things isn't just a nice idea — it's a responsibility.",
                  },
                ].map((item, i) => (
                  <Card key={i} className="border bg-card" data-testid={`card-env-${i}`}>
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-3 mb-3">
                        <div className={`flex h-10 w-10 items-center justify-center rounded-full ${item.bg} flex-shrink-0`}>
                          <item.icon className={`h-5 w-5 ${item.color}`} />
                        </div>
                        <h3 className="font-semibold text-foreground text-lg mt-1">{item.title}</h3>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{item.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div {...fadeUp(0.4)} className="mb-16">
              <h2 className="text-3xl font-bold text-foreground font-display text-center mb-3" data-testid="heading-our-commitment">
                Our Environmental Commitment
              </h2>
              <p className="text-center text-muted-foreground mb-8 max-w-xl mx-auto">
                Every step of our process is designed with the planet in mind.
              </p>

              <div className="grid gap-5 sm:grid-cols-3">
                {[
                  {
                    icon: Recycle,
                    title: "100% Biodegradable",
                    desc: "Our treat packaging breaks down naturally within 6-12 months, compared to the 400+ years for conventional plastic.",
                    color: "text-green-600 dark:text-green-400",
                  },
                  {
                    icon: Leaf,
                    title: "Plant-Based Materials",
                    desc: "From inks to adhesives, every component of our packaging comes from renewable, plant-based sources.",
                    color: "text-emerald-600 dark:text-emerald-400",
                  },
                  {
                    icon: TreePine,
                    title: "Carbon-Conscious",
                    desc: "We source materials locally whenever possible, reducing shipping emissions and supporting Montana's economy.",
                    color: "text-teal-600 dark:text-teal-400",
                  },
                ].map((item, i) => (
                  <Card key={i} className="border bg-card hover:shadow-md transition-shadow" data-testid={`card-commit-${i}`}>
                    <CardContent className="pt-6 text-center">
                      <item.icon className={`h-10 w-10 mx-auto mb-3 ${item.color}`} />
                      <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div
              {...fadeUp(0.45)}
              className="bg-gradient-to-br from-green-500/5 via-muted/40 to-primary/5 dark:from-green-500/10 dark:via-muted/20 dark:to-primary/10 rounded-2xl p-8 md:p-10 text-center border"
              data-testid="section-cta"
            >
              <Recycle className="h-10 w-10 mx-auto text-green-600 dark:text-green-400 mb-4" />
              <h2 className="text-2xl font-bold text-foreground font-display mb-3">
                Choose Better for Your Pet and the Planet
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto mb-6 leading-relaxed">
                Every bag of Franco's Pet Store freeze-dried treats is packaged with care — for your pet's health and for the world they live in. Make the switch to treats that taste amazing and tread lightly on the earth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/pet-store">
                  <Button size="lg" className="gap-2" data-testid="button-shop-treats">
                    <PawPrint className="h-5 w-5" /> Shop Pet Treats
                  </Button>
                </Link>
                <Link href="/giving-back">
                  <Button size="lg" variant="outline" className="gap-2" data-testid="button-giving-back">
                    Our Giving Back Program <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-8">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto text-center text-sm text-muted-foreground space-y-4">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">Franco's Pet Store. All Rights Reserved.</p>
            <p>
              <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link>
              {" · "}
              <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>
              {" · "}
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
