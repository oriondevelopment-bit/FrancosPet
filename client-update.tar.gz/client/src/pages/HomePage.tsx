import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { PawPrint, ChevronRight, Leaf, ShieldCheck, MapPin } from "lucide-react";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";
import montanaBadge from "@assets/IMG_0398_1772679731962.png";

export default function HomePage() {
  const { isAuthenticated, user } = useAuth();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-secondary/10 dark:from-primary/5 dark:via-background dark:to-secondary/5" />
          <div className="container relative px-4 py-16 md:py-24 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <motion.h1
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-6xl font-display"
              >
                Franco's Pet Store
              </motion.h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="mx-auto max-w-2xl text-lg text-muted-foreground leading-relaxed"
              >
                Premium raw freeze-dried pet treats, made with love in Glendive, Montana. All-natural, single-ingredient, human-grade nutrition for your beloved companions.
              </motion.p>
              {isAuthenticated && user && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="text-sm text-primary mt-3"
                >
                  Welcome back, {user.firstName || "friend"}!
                </motion.p>
              )}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                className="mt-6 flex justify-center"
              >
                <img
                  src={montanaBadge}
                  alt="Made in Montana, USA"
                  className="h-24 w-24 object-contain drop-shadow-md"
                  data-testid="img-montana-badge-hero"
                />
              </motion.div>
            </div>
          </div>
        </section>

        <section className="container px-4 md:px-6 -mt-4 pb-16">
          <div className="mx-auto max-w-4xl grid gap-6 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="md:col-span-2"
            >
              <Link href="/">
                <Card className="group cursor-pointer overflow-visible hover-elevate h-full" data-testid="card-pet-store">
                  <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
                    <img
                      src={petStoreLogo}
                      alt="Franco's Pet Store"
                      className="w-28 h-28 rounded-2xl object-cover shadow-sm"
                      data-testid="img-pet-logo"
                    />
                    <h2 className="text-2xl font-bold text-foreground font-display">Shop Pet Treats</h2>
                    <p className="text-muted-foreground leading-relaxed max-w-lg">
                      Premium raw freeze-dried treats your pets will love. Made from all-natural, people-grade food with no preservatives — sourced from Montana and regional ranches.
                    </p>
                    <Button variant="default" className="mt-2 gap-1" data-testid="button-view-pets">
                      Shop Now
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          </div>
        </section>

        <section className="bg-muted/40 dark:bg-muted/20 border-y border-border">
          <div className="container px-4 md:px-6 py-16">
            <div className="mx-auto max-w-4xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-center mb-10"
              >
                <h2 className="text-3xl font-bold text-foreground font-display mb-3">Our Pet Promise</h2>
                <p className="text-muted-foreground max-w-xl mx-auto">
                  We believe your pets deserve the same quality food you eat. That's why our treats are made from real, wholesome ingredients — nothing artificial, ever.
                </p>
              </motion.div>

              <div className="flex flex-col md:flex-row items-center gap-8 mb-10">
                <img
                  src={petStoreLogo}
                  alt="Franco's Pet Store Treats"
                  className="w-40 h-40 md:w-48 md:h-48 rounded-2xl object-cover flex-shrink-0 shadow-sm"
                  data-testid="img-pet-store-landing"
                />
                <p className="text-muted-foreground leading-relaxed text-center md:text-left">
                  Franco's Pet Store is proud to offer our own line of premium raw freeze-dried animal treats. Every product is meticulously crafted fresh using meats sourced from Montana and regional ranches, ensuring the highest standards of quality, nutrition, and sustainability for your four-legged family members.
                </p>
              </div>

              <div className="grid gap-6 sm:grid-cols-3">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <Card data-testid="card-all-natural">
                    <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                        <Leaf className="h-6 w-6 text-green-600 dark:text-green-400" />
                      </div>
                      <h3 className="font-bold text-foreground">All Natural</h3>
                      <p className="text-sm text-muted-foreground">
                        Made from people-grade food with zero preservatives, fillers, or artificial ingredients.
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                >
                  <Card data-testid="card-usa-made">
                    <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/30">
                        <ShieldCheck className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <h3 className="font-bold text-foreground">Made in the USA</h3>
                      <p className="text-sm text-muted-foreground">
                        Grown, raised, and made entirely in the United States — supporting American ranchers and farmers.
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  <Card data-testid="card-local-sourced">
                    <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                        <MapPin className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                      </div>
                      <h3 className="font-bold text-foreground">Regionally Sourced</h3>
                      <p className="text-sm text-muted-foreground">
                        Meats from Montana and regional ranches, ensuring freshness and the highest quality for your pets.
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground text-center">Franco's Pet Store. All Rights Reserved.</p>
            <p>
              This application, including but not limited to its design, text, graphics, logos, images, audio, video, software, and any associated content (collectively, the "Content"), is owned by Franco's Pet Store or its licensors and is protected by United States and international copyright, trademark, and other intellectual property laws.
            </p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Pet Store, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80" data-testid="link-terms">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80" data-testid="link-privacy">Privacy Policy</Link>. Learn about <Link href="/our-story" className="text-primary underline hover:text-primary/80" data-testid="link-our-story">Our Story</Link> and <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80" data-testid="link-why-freeze-dried">Why Freeze-Dried</Link>.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
