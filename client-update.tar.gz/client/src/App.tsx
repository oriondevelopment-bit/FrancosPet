import { Switch, Route } from "wouter";
import { lazy, Suspense } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider } from "@/lib/CartContext";
import { ThemeProvider } from "@/lib/ThemeContext";
import { Loader2 } from "lucide-react";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import CartPage from "@/pages/CartPage";
import CheckoutPage from "@/pages/CheckoutPage";
import { InstallAppPrompt } from "@/components/InstallAppPrompt";
import { CookieConsent } from "@/components/CookieConsent";
import { AIChatAssistant } from "@/components/AIChatAssistant";

const MenuPage = lazy(() => import("@/pages/MenuPage"));
const PetStorePage = lazy(() => import("@/pages/PetStorePage"));
const OrderConfirmationPage = lazy(() => import("@/pages/OrderConfirmationPage"));
const TermsOfServicePage = lazy(() => import("@/pages/TermsOfServicePage"));
const PrivacyPolicyPage = lazy(() => import("@/pages/PrivacyPolicyPage"));
const ProfilePage = lazy(() => import("@/pages/ProfilePage"));
const MyOrdersPage = lazy(() => import("@/pages/MyOrdersPage"));
const ContactPage = lazy(() => import("@/pages/ContactPage"));
const AdminPage = lazy(() => import("@/pages/AdminPage"));
const WholesalePage = lazy(() => import("@/pages/WholesalePage"));
const WholesaleOrderPage = lazy(() => import("@/pages/WholesaleOrderPage"));
const NutritionPage = lazy(() => import("@/pages/NutritionPage"));
const LoginPage = lazy(() => import("@/pages/LoginPage"));
const OurStoryPage = lazy(() => import("@/pages/OurStoryPage"));
const WhyFreezeDriedPage = lazy(() => import("@/pages/WhyFreezeDriedPage"));
const GivingBackPage = lazy(() => import("@/pages/GivingBackPage"));
const EnvironmentalPage = lazy(() => import("@/pages/EnvironmentalPage"));

function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path="/" component={PetStorePage} />
        <Route path="/pet-store" component={PetStorePage} />
        {/* Food routes preserved for future pizza app - not routed */}
        {/* <Route path="/menu" component={MenuPage} /> */}
        <Route path="/cart" component={CartPage} />
        <Route path="/checkout" component={CheckoutPage} />
        <Route path="/order-confirmation/:id" component={OrderConfirmationPage} />
        <Route path="/terms" component={TermsOfServicePage} />
        <Route path="/privacy" component={PrivacyPolicyPage} />
        <Route path="/profile" component={ProfilePage} />
        <Route path="/my-orders" component={MyOrdersPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/admin" component={AdminPage} />
        <Route path="/wholesale" component={WholesalePage} />
        <Route path="/wholesale/order" component={WholesaleOrderPage} />
        {/* <Route path="/nutrition" component={NutritionPage} /> */}
        <Route path="/login" component={LoginPage} />
        <Route path="/our-story" component={OurStoryPage} />
        <Route path="/why-freeze-dried" component={WhyFreezeDriedPage} />
        <Route path="/giving-back" component={GivingBackPage} />
        <Route path="/environmental" component={EnvironmentalPage} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <CartProvider>
            <Toaster />
            <Router />
            <InstallAppPrompt />
            <CookieConsent />
            <AIChatAssistant />
          </CartProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
