import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12 max-w-4xl mx-auto">
        <div className="rounded-3xl bg-white p-8 md:p-12 shadow-lg border border-border">
          <h1 className="text-4xl font-bold font-display mb-2 text-foreground">Privacy Policy</h1>
          <p className="text-muted-foreground mb-8">Last Updated: March 6, 2026</p>

          <div className="prose prose-orange max-w-none space-y-6 text-foreground/80 leading-relaxed">
            <p>
              Franco's Kitchen LLC ("we," "us," or "our") is committed to protecting your privacy. This Privacy Policy describes how we collect, use, disclose, and safeguard personal information when you use the Replit mobile application and related services (the "Service").
            </p>

            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-bold text-foreground">1. Information We Collect</h2>
                <p>We collect personal information including name, email address, phone number (including mobile number), delivery address, payment details (processed securely by third parties), approximate location data (for delivery routing), device identifiers, order history, and usage analytics.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">2. How We Use Your Information</h2>
                <p>We use collected information to process and fulfill orders, send transactional communications (including SMS/text messages for order confirmations and status updates), provide customer support, personalize your experience, communicate promotions (with opt-out options), analyze usage to improve the Service, comply with legal requirements, and prevent fraud or abuse.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">3. SMS/Text Messaging</h2>
                <p>By providing your mobile phone number and opting in to SMS notifications during checkout or in your account settings, you consent to receive text messages from Franco's Kitchen LLC related to your orders and account. These messages may include:</p>
                <ul className="list-disc pl-6 space-y-1 mt-2">
                  <li>Order confirmations and status updates</li>
                  <li>Pickup and delivery notifications</li>
                  <li>Subscription renewal reminders</li>
                  <li>Promotional offers and discounts (if you opt in to marketing messages)</li>
                </ul>
                <p className="mt-3"><strong>Message Frequency:</strong> Message frequency varies based on your order activity. Transactional messages are sent per order event (confirmation, status change, completion). Promotional messages, if opted in, are sent periodically.</p>
                <p className="mt-2"><strong>Message & Data Rates:</strong> Message and data rates may apply. Your carrier's standard messaging rates apply to all SMS communications.</p>
                <p className="mt-2"><strong>Opt-Out:</strong> You may opt out of SMS notifications at any time by updating your preferences in your account settings, or by replying STOP to any text message. After opting out, you will receive a confirmation message and no further texts will be sent unless you re-subscribe. Opting out of SMS does not affect order-related email communications.</p>
                <p className="mt-2"><strong>Opt-In:</strong> You may re-subscribe to SMS notifications at any time by updating your preferences in your account settings or by opting in during checkout.</p>
                <p className="mt-2"><strong>Help:</strong> For help with SMS notifications, reply HELP to any message or contact us at francoskitchenllc@gmail.com.</p>
                <p className="mt-2"><strong>Supported Carriers:</strong> SMS service is available on most major US carriers. Carriers are not liable for delayed or undelivered messages.</p>
                <p className="mt-2">We will not share your mobile phone number with third parties for their marketing purposes. Your phone number is used solely for order-related communications and, if opted in, promotional messages from Franco's Kitchen LLC.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">4. Sharing of Information</h2>
                <p>We share information with necessary third parties, including payment processors (PayPal), SMS service providers (Twilio), email service providers, delivery partners (if applicable), service providers for hosting or analytics, and as required by law or to protect rights and safety. We do not sell personal information. If applicable under state law (e.g., California), we provide mechanisms to opt out of any sale or sharing.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">5. Data Security</h2>
                <p>We employ reasonable administrative, technical, and physical safeguards to protect information, though no transmission or storage method is entirely secure. Phone numbers used for SMS are stored securely and transmitted only to our authorized SMS service provider for the purpose of delivering messages.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">6. Your Rights</h2>
                <p>Depending on your location, you may have rights to access, correct, delete, or opt out of certain processing of your personal information (e.g., under CCPA/CPRA or similar laws). This includes the right to opt out of SMS communications at any time. To exercise these rights, contact us at francoskitchenllc@gmail.com. We will respond within required timeframes. For mobile app users, this policy is accessible via the app's settings menu.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">7. Children's Privacy</h2>
                <p>The Service is not intended for individuals under 13 years of age (or 16 in certain jurisdictions). We do not knowingly collect data from children. SMS notifications are not sent to individuals under 13.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">8. Changes to This Policy</h2>
                <p>We may update this Privacy Policy. Significant changes will be notified through the app, email, SMS (if opted in), or other means. Continued use constitutes acceptance.</p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-foreground">9. Contact Information</h2>
                <p>For inquiries regarding this Privacy Policy, your data, or SMS communications, contact Franco's Kitchen LLC at francoskitchenllc@gmail.com.</p>
              </section>
            </div>

            <p className="pt-4 border-t italic">
              By using the Service, you consent to the data practices outlined in this Privacy Policy, including receiving SMS/text messages if you provide your mobile number and opt in.
            </p>

            <div className="pt-8 text-center">
              <Link href="/">
                <Button className="rounded-full px-8">Return to Home</Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t bg-muted/30 py-12 mt-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed text-center">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">&copy; 2026 Franco's Pet Store. All Rights Reserved.</p>
            <p>
              <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
