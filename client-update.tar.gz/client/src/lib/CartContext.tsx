import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { MenuItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { getCookie, setCookie, hasCookieConsent } from "@/lib/cookies";

export interface CartItem extends MenuItem {
  quantity: number;
  isCustomPizza?: boolean;
  customPizzaDetails?: {
    toppings: string[];
    extraCheese: boolean;
  };
  isAutoRenewal?: boolean;
}

export interface CustomPizzaOptions {
  toppings: string[];
  extraCheese: boolean;
  price: number;
}

export interface ShippingRate {
  carrier: string;
  service: string;
  serviceCode: string;
  price: number;
  estimatedDays: string;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (item: MenuItem) => void;
  addCustomPizza: (options: CustomPizzaOptions) => void;
  addPetTreatToCart: (item: MenuItem, autoRenewal?: boolean) => void;
  removeFromCart: (itemId: number) => void;
  updateQuantity: (itemId: number, delta: number) => void;
  toggleAutoRenewal: (itemId: number) => void;
  clearCart: () => void;
  isDelivery: boolean;
  toggleDelivery: () => void;
  deliveryFee: number;
  shippingFee: number;
  selectedShippingRate: ShippingRate | null;
  setSelectedShippingRate: (rate: ShippingRate | null) => void;
  petTreatPickup: boolean;
  setPetTreatPickup: (pickup: boolean) => void;
  subtotal: number;
  total: number;
  hasPetTreats: boolean;
  hasFoodItems: boolean;
  petTreatsSubtotal: number;
  foodSubtotal: number;
  hasAutoRenewal: boolean;
  petTreatQuantity: number;
  qualifiesForFreeShipping: boolean;
  appliedPromo: AppliedPromo | null;
  setAppliedPromo: (promo: AppliedPromo | null) => void;
  discountAmount: number;
}

export interface AppliedPromo {
  code: string;
  title: string;
  discountType: string;
  discountValue: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

let customPizzaCounter = -1;

function loadCartFromCookie(): CartItem[] {
  try {
    if (!hasCookieConsent()) return [];
    const saved = getCookie("cart_items");
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => loadCartFromCookie());
  const [isDelivery, setIsDelivery] = useState(false);
  const [selectedShippingRate, setSelectedShippingRate] = useState<ShippingRate | null>(null);
  const [petTreatPickup, setPetTreatPickup] = useState(false);
  const [appliedPromo, setAppliedPromo] = useState<AppliedPromo | null>(null);
  const { toast } = useToast();

  const saveCartToCookie = useCallback((cartItems: CartItem[]) => {
    if (hasCookieConsent()) {
      if (cartItems.length > 0) {
        setCookie("cart_items", JSON.stringify(cartItems), 7);
      } else {
        setCookie("cart_items", "[]", 7);
      }
    }
  }, []);

  useEffect(() => {
    saveCartToCookie(items);
  }, [items, saveCartToCookie]);

  useEffect(() => {
    const handleConsentChange = () => {
      if (hasCookieConsent()) {
        saveCartToCookie(items);
      }
    };
    window.addEventListener("cookie-consent-changed", handleConsentChange);
    return () => window.removeEventListener("cookie-consent-changed", handleConsentChange);
  }, [items, saveCartToCookie]);

  const hasPetTreats = items.some(i => i.category === "pet_treats");
  const hasFoodItems = items.some(i => i.category === "pizza" || i.category === "sauce");

  const effectiveDelivery = isDelivery && hasFoodItems;
  const deliveryFee = effectiveDelivery ? 500 : 0;

  const hasAutoRenewal = items.some(i => i.category === "pet_treats" && i.isAutoRenewal);

  const petTreatsSubtotal = items
    .filter(i => i.category === "pet_treats")
    .reduce((sum, item) => sum + item.price * item.quantity, 0);

  const petTreatQuantity = items
    .filter(i => i.category === "pet_treats")
    .reduce((sum, item) => sum + item.quantity, 0);

  const foodSubtotal = items
    .filter(i => i.category !== "pet_treats")
    .reduce((sum, item) => sum + item.price * item.quantity, 0);

  const rawSubtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const qualifiesForFreeShipping = rawSubtotal >= 5000;

  const shippingFee = hasPetTreats
    ? (petTreatPickup || qualifiesForFreeShipping ? 0 : (selectedShippingRate?.price || 0))
    : 0;

  const addToCart = (item: MenuItem) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === item.id && !i.isCustomPizza);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id && !i.isCustomPizza ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    toast({
      title: "Added to cart",
      description: `${item.name} added to your order.`,
    });
  };

  const addPetTreatToCart = (item: MenuItem, autoRenewal = false) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1, isAutoRenewal: autoRenewal }];
    });
    toast({
      title: "Added to cart",
      description: `${item.name} added to your order.${autoRenewal ? " Monthly auto-renewal enabled!" : ""}`,
    });
  };

  const toggleAutoRenewal = (itemId: number) => {
    setItems((prev) =>
      prev.map((i) =>
        i.id === itemId && i.category === "pet_treats"
          ? { ...i, isAutoRenewal: !i.isAutoRenewal }
          : i
      )
    );
  };

  const addCustomPizza = (options: CustomPizzaOptions) => {
    const toppingsList = options.toppings.length > 0 
      ? options.toppings.join(", ")
      : "Plain";
    
    const description = options.extraCheese 
      ? `${toppingsList} + Extra Cheese`
      : toppingsList;

    const customPizza: CartItem = {
      id: customPizzaCounter--,
      category: "pizza",
      name: "Build Your Own Pizza",
      description,
      price: options.price,
      imageUrl: null,
      quantity: 1,
      isCustomPizza: true,
      customPizzaDetails: {
        toppings: options.toppings,
        extraCheese: options.extraCheese,
      },
    };

    setItems((prev) => [...prev, customPizza]);
    toast({
      title: "Custom Pizza Added",
      description: `Build Your Own Pizza with ${description} added to your order.`,
    });
  };

  const removeFromCart = (itemId: number) => {
    setItems((prev) => {
      const newItems = prev.filter((i) => i.id !== itemId);
      const stillHasFood = newItems.some(i => i.category === "pizza" || i.category === "sauce");
      if (!stillHasFood && isDelivery) {
        setIsDelivery(false);
      }
      const stillHasPetTreats = newItems.some(i => i.category === "pet_treats");
      if (!stillHasPetTreats) {
        setSelectedShippingRate(null);
        setPetTreatPickup(false);
      }
      return newItems;
    });
  };

  const updateQuantity = (itemId: number, delta: number) => {
    setItems((prev) => {
      const newItems = prev.map((i) => {
        if (i.id === itemId) {
          const newQty = Math.max(0, i.quantity + delta);
          return { ...i, quantity: newQty };
        }
        return i;
      }).filter((i) => i.quantity > 0);
      
      const stillHasFood = newItems.some(i => i.category === "pizza" || i.category === "sauce");
      if (!stillHasFood && isDelivery) {
        setIsDelivery(false);
      }
      const stillHasPetTreats = newItems.some(i => i.category === "pet_treats");
      if (!stillHasPetTreats) {
        setSelectedShippingRate(null);
        setPetTreatPickup(false);
      }
      return newItems;
    });
  };

  const clearCart = () => {
    setItems([]);
    setIsDelivery(false);
    setSelectedShippingRate(null);
    setPetTreatPickup(false);
    setAppliedPromo(null);
  };

  const toggleDelivery = () => {
    if (hasFoodItems) {
      setIsDelivery(!isDelivery);
    }
  };

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmount = appliedPromo
    ? appliedPromo.discountType === 'percentage'
      ? Math.round(subtotal * (appliedPromo.discountValue / 100))
      : appliedPromo.discountValue
    : 0;
  const total = Math.max(0, subtotal - discountAmount) + deliveryFee + shippingFee;

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        addCustomPizza,
        addPetTreatToCart,
        removeFromCart,
        updateQuantity,
        toggleAutoRenewal,
        clearCart,
        isDelivery: effectiveDelivery,
        toggleDelivery,
        deliveryFee,
        shippingFee,
        selectedShippingRate,
        setSelectedShippingRate,
        petTreatPickup,
        setPetTreatPickup,
        subtotal,
        total,
        hasPetTreats,
        hasFoodItems,
        petTreatsSubtotal,
        foodSubtotal,
        hasAutoRenewal,
        petTreatQuantity,
        qualifiesForFreeShipping,
        appliedPromo,
        setAppliedPromo,
        discountAmount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
