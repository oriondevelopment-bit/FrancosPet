import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LogIn, ShieldCheck, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  if (isLoading) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <Card className="w-full max-w-md border-border/50 shadow-lg">
          <CardContent className="pt-8 pb-8 px-8">
            <div className="text-center mb-8">
              <img
                src={petStoreLogo}
                alt="Franco's Pet Store"
                className="h-20 w-20 rounded-full object-cover shadow-md mx-auto mb-4"
                data-testid="img-login-logo"
              />
              <h1 className="text-2xl font-bold font-display" data-testid="text-login-title">
                Franco's Pet Store
              </h1>
              <p className="text-muted-foreground text-sm mt-2">
                Sign in to track orders, save preferences, and more
              </p>
            </div>

            <div className="space-y-4">
              <a href="/api/login" className="block">
                <Button className="w-full h-12 text-base" size="lg" data-testid="button-sign-in">
                  <LogIn className="mr-2 h-5 w-5" />
                  Sign In to Your Account
                </Button>
              </a>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-3 text-muted-foreground">or</span>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full h-12 text-base"
                size="lg"
                onClick={() => setLocation("/")}
                data-testid="button-continue-guest"
              >
                <ArrowLeft className="mr-2 h-5 w-5" />
                Continue as Guest
              </Button>
            </div>

            <div className="mt-6 rounded-xl bg-blue-50 dark:bg-blue-950/30 p-4 border border-blue-200 dark:border-blue-800">
              <p className="text-xs text-blue-800 dark:text-blue-300 leading-relaxed" data-testid="text-account-tip">
                <span className="font-semibold">Signing in with the wrong account?</span> If your browser automatically uses a different Google or email account, try opening this page in a private/incognito window, or log out of that account in your browser first.
              </p>
            </div>

            <div className="mt-4 flex items-start gap-3 rounded-xl bg-muted/50 p-4 border border-border/50">
              <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed" data-testid="text-privacy-notice">
                Your information is private and never shared with any third party. 
                We only use your details to process orders and keep you updated.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
