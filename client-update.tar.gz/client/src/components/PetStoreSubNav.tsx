import { Link, useLocation } from "wouter";
import { PawPrint, Snowflake, Recycle, HandHeart } from "lucide-react";
import { Button } from "@/components/ui/button";

const tabs = [
  { href: "/pet-store", label: "Pet Store", icon: PawPrint },
  { href: "/why-freeze-dried", label: "Why Freeze-Dried?", icon: Snowflake },
  { href: "/environmental", label: "Environmental Initiative", icon: Recycle },
  { href: "/giving-back", label: "Giving Back", icon: HandHeart },
];

export function PetStoreSubNav() {
  const [location] = useLocation();

  return (
    <div className="w-full border-b bg-muted/30 dark:bg-muted/10" data-testid="pet-store-subnav">
      <div className="container px-4 md:px-6">
        <div className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-hide">
          {tabs.map((tab) => {
            const isActive = location === tab.href;
            return (
              <Link key={tab.href} href={tab.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className={`gap-1.5 whitespace-nowrap text-xs md:text-sm ${
                    isActive
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  data-testid={`subnav-${tab.href.slice(1)}`}
                >
                  <tab.icon className="h-3.5 w-3.5" />
                  {tab.label}
                </Button>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
