import { Link, useLocation } from "wouter";
import { ShoppingBag, User, LogIn, LogOut, Settings, Mail, Building2, PawPrint, BookOpen, RefreshCw, HandHeart } from "lucide-react";
import { useCart } from "@/lib/CartContext";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";

export function Navigation() {
  const { items, total } = useCart();
  const [location] = useLocation();
  const { user, isLoading, isAuthenticated } = useAuth();

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
          <img 
            src={petStoreLogo} 
            alt="Franco's Pet Store Logo" 
            className="h-10 w-10 rounded-full object-cover shadow-md"
            data-testid="nav-logo"
          />
          <span className="hidden text-xl font-bold font-display md:inline-block text-foreground" data-testid="nav-brand-name">
            Franco's Pet Store
          </span>
        </Link>

        <div className="flex items-center gap-2 md:gap-4">
          <ThemeToggle />
          <Link href="/">
            <Button variant="ghost" size="sm" className={location === "/" || location === "/pet-store" ? "text-primary font-bold" : "text-muted-foreground"} data-testid="nav-shop">
              <PawPrint className="h-4 w-4 md:mr-1" />
              <span className="hidden md:inline">Shop</span>
            </Button>
          </Link>
          <Link href="/our-story">
            <Button variant="ghost" size="sm" className={location === "/our-story" ? "text-primary font-bold" : "text-muted-foreground"} data-testid="nav-our-story">
              <BookOpen className="h-4 w-4 md:mr-1" />
              <span className="hidden md:inline">Our Story</span>
            </Button>
          </Link>
          <Link href="/giving-back">
            <Button variant="ghost" size="sm" className={location === "/giving-back" ? "text-primary font-bold" : "text-muted-foreground"} data-testid="nav-giving-back">
              <HandHeart className="h-4 w-4 md:mr-1" />
              <span className="hidden md:inline">Giving Back</span>
            </Button>
          </Link>
          
          {isAuthenticated && (
            <Link href="/contact">
              <Button variant="ghost" size="sm" className={location === "/contact" ? "text-primary font-bold" : "text-muted-foreground"} data-testid="nav-contact">
                <Mail className="h-4 w-4 md:mr-1" />
                <span className="hidden md:inline">Contact</span>
              </Button>
            </Link>
          )}
          
          <Link href="/cart">
            <Button 
              size="sm"
              className={`relative rounded-full px-3 md:px-4 ${location === "/cart" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-secondary/90"}`}
              data-testid="nav-cart"
            >
              <ShoppingBag className="mr-1 md:mr-2 h-4 w-4" />
              <span className="font-bold">
                {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(total / 100)}
              </span>
              {itemCount > 0 && (
                <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white shadow-sm ring-2 ring-background">
                  {itemCount}
                </span>
              )}
            </Button>
          </Link>

          {isLoading ? (
            <div className="h-9 w-9 animate-pulse rounded-full bg-muted" />
          ) : isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full" data-testid="nav-user-menu">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                      {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-2 py-1.5 text-sm font-medium">
                  {user?.firstName} {user?.lastName}
                </div>
                <div className="px-2 pb-2 text-xs text-muted-foreground truncate">
                  {user?.email}
                </div>
                <DropdownMenuSeparator />
                <Link href="/profile">
                  <DropdownMenuItem className="cursor-pointer" data-testid="menu-profile">
                    <User className="mr-2 h-4 w-4" />
                    My Profile
                  </DropdownMenuItem>
                </Link>
                <Link href="/my-orders">
                  <DropdownMenuItem className="cursor-pointer" data-testid="menu-orders">
                    <ShoppingBag className="mr-2 h-4 w-4" />
                    Order History
                  </DropdownMenuItem>
                </Link>
                <Link href="/wholesale">
                  <DropdownMenuItem className="cursor-pointer" data-testid="menu-wholesale">
                    <Building2 className="mr-2 h-4 w-4" />
                    Wholesale Portal
                  </DropdownMenuItem>
                </Link>
                <Link href="/admin">
                  <DropdownMenuItem className="cursor-pointer" data-testid="menu-admin">
                    <Settings className="mr-2 h-4 w-4" />
                    Admin Panel
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <a href="/api/logout?switch=1">
                  <DropdownMenuItem className="cursor-pointer" data-testid="menu-switch-account">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Switch Account
                  </DropdownMenuItem>
                </a>
                <a href="/api/logout">
                  <DropdownMenuItem className="cursor-pointer text-destructive" data-testid="menu-logout">
                    <LogOut className="mr-2 h-4 w-4" />
                    Log Out
                  </DropdownMenuItem>
                </a>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/login">
              <Button variant="outline" size="sm" data-testid="nav-login">
                <LogIn className="mr-1 md:mr-2 h-4 w-4" />
                <span className="hidden md:inline">Log In</span>
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
