import { useRoute, Link } from "wouter";
import { useOrder } from "@/hooks/use-orders";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Calendar, MapPin, Printer } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function OrderConfirmationPage() {
  const [, params] = useRoute("/order-confirmation/:id");
  const id = parseInt(params?.id || "0");
  const { data: order, isLoading } = useOrder(id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <Navigation />
        <div className="container max-w-2xl mx-auto py-12 px-4 space-y-8">
           <Skeleton className="h-12 w-3/4 mx-auto" />
           <Skeleton className="h-64 w-full rounded-3xl" />
        </div>
      </div>
    );
  }

  if (!order) return <div>Order not found</div>;

  const pickupDate = new Date(order.pickupDate).toDateString();
  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 max-w-3xl mx-auto py-12 px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center h-24 w-24 rounded-full bg-green-100 text-green-600 mb-6 shadow-sm">
            <CheckCircle2 className="h-12 w-12" />
          </div>
          <h1 className="text-4xl font-bold font-display text-foreground mb-4">Order Confirmed!</h1>
          <p className="text-foreground/80 text-lg">
            Thank you, {order.customerName}. Your order has been received.
          </p>
          <p className="text-primary font-bold text-xl mt-2 font-display" data-testid="text-order-ref">
            {order.orderRef || `#${order.id}`}
          </p>
        </div>

        <div className="bg-card rounded-3xl shadow-lg border border-border overflow-hidden">
          <div className="bg-primary/5 p-6 border-b border-border flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
               <p className="text-sm text-foreground/70 uppercase tracking-wider font-bold">Total Amount</p>
               <p className="text-3xl font-bold text-primary font-display">{formatPrice(order.totalAmount)}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => window.print()}>
                <Printer className="mr-2 h-4 w-4" /> Print
              </Button>
            </div>
          </div>

          <div className="p-8 space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Calendar className="h-5 w-5 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold text-foreground">Scheduled Date</h3>
                    <p className="text-foreground/80">{pickupDate}</p>
                    <p className="text-xs text-orange-600 mt-1 font-medium">Please allow 3 days for prep.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold text-foreground">{order.isDelivery ? "Delivery Address" : "Pickup Location"}</h3>
                    {order.isDelivery ? (
                      <p className="text-foreground/80">{order.deliveryAddress}</p>
                    ) : (
                      <p className="text-foreground/80">Franco's Pet Store<br/>313 S. Merrill Ave<br/>Glendive MT 59330</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-muted/30 rounded-2xl p-6">
                <h3 className="font-bold mb-4 font-display text-lg text-foreground">Instructions</h3>
                <ul className="space-y-2 text-sm text-foreground/80 list-disc list-inside">
                  <li>Your items will be prepared fresh.</li>
                  <li>Keep refrigerated until ready to bake.</li>
                  <li>Baking instructions included with pickup.</li>
                  {order.paymentMethod === 'cash' && (
                    <li className="font-medium text-amber-700 dark:text-amber-400">Please bring cash payment of {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format((order.totalAmount || 0) / 100)} when you pick up.</li>
                  )}
                  {order.paymentMethod !== 'paypal' && order.paymentMethod !== 'cash' && (
                    <li className="font-medium text-foreground">Please show payment proof upon arrival.</li>
                  )}
                </ul>
              </div>
            </div>
          </div>
          
          <div className="bg-muted/10 p-4 text-center">
             <Link href="/">
               <Button variant="ghost" className="text-primary underline">Place another order</Button>
             </Link>
          </div>
        </div>
      </main>

      <footer className="border-t bg-muted/30 py-12 mt-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">&copy; 2026 Franco's Pet Store. All Rights Reserved.</p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Pet Store, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>.
            </p>
            <p>
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/environmental" className="text-primary underline hover:text-primary/80">Environmental Initiative</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
