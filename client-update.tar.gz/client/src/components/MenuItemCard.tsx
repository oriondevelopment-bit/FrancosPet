import { MenuItem } from "@shared/schema";
import { useCart } from "@/lib/CartContext";
import { Button } from "@/components/ui/button";
import { Plus, Info, RefreshCw, Package, Store } from "lucide-react";
import { useState } from "react";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";

interface Props {
  item: MenuItem;
  isPetTreat?: boolean;
}

const pizzaIngredients: Record<string, { ingredients: string; nutrition: string }> = {
  "Cheese": {
    ingredients: "Crust (enriched wheat flour, water, olive oil, yeast, sea salt), Low moisture part skim mozzarella cheese, Marinara sauce (California non-GMO tomatoes, sea salt, olive oil, garlic, onion, basil, oregano)",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Pepperoni": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Pepperoni (pork, beef, salt, paprika, garlic, sodium nitrite, lactic acid, starter culture)",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Italian Sausage": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Italian sausage (pork, sea salt, paprika, garlic, onion, basil, oregano)",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Beef": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Ground beef topping (ground beef, sea salt, paprika, garlic, onion, basil, oregano)",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Meat Lovers": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Pepperoni, Italian sausage, Ground beef, Bacon",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Veggie": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Bell peppers, Onions, Garlic, Mushrooms",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
  "Supreme": {
    ingredients: "Crust, Mozzarella cheese, Marinara sauce, Pepperoni, Italian sausage, Ground beef, Bell peppers, Onions, Mushrooms",
    nutrition: "330 cal | 16g fat | 28g carbs | 16g protein | 1010mg sodium per serving (1/6 pizza)"
  },
};

const sauceIngredients: Record<string, { ingredients: string; nutrition: string }> = {
  "Marinara Sauce": {
    ingredients: "California non-GMO tomatoes, sea salt, olive oil, granulated garlic, granulated onion, basil, oregano, citric acid",
    nutrition: "Per 1/4 cup: 35 cal | 1.5g fat | 5g carbs | 1g protein"
  },
  "Alfredo Sauce": {
    ingredients: "Heavy cream, butter, parmesan cheese, garlic, salt, white pepper",
    nutrition: "Per 1/4 cup: 120 cal | 11g fat | 2g carbs | 3g protein"
  },
  "Blue Cheese Dressing": {
    ingredients: "Sour cream, mayonnaise, blue cheese crumbles, buttermilk, garlic, white vinegar, salt, pepper",
    nutrition: "Per 2 tbsp: 140 cal | 14g fat | 1g carbs | 2g protein"
  },
};

export function MenuItemCard({ item, isPetTreat }: Props) {
  const { addToCart, addPetTreatToCart } = useCart();
  const [autoRenewal, setAutoRenewal] = useState(false);

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const getItemInfo = () => {
    if (item.category === 'pizza') {
      return pizzaIngredients[item.name] || null;
    } else if (item.category === 'sauce') {
      return sauceIngredients[item.name] || null;
    }
    return null;
  };

  const itemInfo = getItemInfo();

  const handleAddToCart = () => {
    if (isPetTreat) {
      addPetTreatToCart(item, autoRenewal);
    } else {
      addToCart(item);
    }
  };

  return (
    <div
      className="group relative overflow-hidden rounded-3xl bg-white dark:bg-gray-800 border border-border shadow-sm transition-shadow hover:shadow-xl hover:shadow-primary/5"
    >
      <div className="aspect-[4/3] w-full overflow-hidden bg-orange-50 relative">
        {item.imageUrl ? (
          <img 
            src={item.imageUrl} 
            alt={item.name} 
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" 
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-4xl">
            {item.category === 'pizza' ? '' : item.category === 'pet_treats' ? '' : ''}
          </div>
        )}
        
        {itemInfo && (
          <HoverCard openDelay={100} closeDelay={100}>
            <HoverCardTrigger asChild>
              <button
                className="absolute top-3 right-3 p-2 bg-white/90 dark:bg-gray-800/90 rounded-full shadow-md hover:bg-white dark:hover:bg-gray-700 transition-colors"
                data-testid={`info-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Info className="h-4 w-4 text-gray-600 dark:text-gray-300" />
              </button>
            </HoverCardTrigger>
            <HoverCardContent className="w-80 p-4" side="left" align="start">
              <div className="space-y-3">
                <h4 className="font-bold text-sm">{item.name}</h4>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Ingredients:</p>
                  <p className="text-xs leading-relaxed">{itemInfo.ingredients}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Nutrition:</p>
                  <p className="text-xs leading-relaxed">{itemInfo.nutrition}</p>
                </div>
                {item.category === 'pizza' && (
                  <p className="text-xs text-orange-600 dark:text-orange-400 font-medium">Contains: Milk, Wheat</p>
                )}
              </div>
            </HoverCardContent>
          </HoverCard>
        )}
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white font-display mb-1">{item.name}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2 min-h-[40px]">
              {item.description || `Delicious homemade ${item.category} prepared fresh.`}
            </p>
          </div>
          <span className="flex-shrink-0 text-lg font-bold text-gray-900 dark:text-white">
            {formatPrice(item.price)}
          </span>
        </div>

        {isPetTreat && (
          <div className="mt-4 space-y-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Store className="h-3.5 w-3.5" />
                <span>Free local pickup available</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Package className="h-3.5 w-3.5" />
                <span>Shipping available (Free on orders $50+)</span>
              </div>
            </div>
            <button
              onClick={() => setAutoRenewal(!autoRenewal)}
              className={`w-full flex items-center gap-2 p-3 rounded-xl border text-sm transition-colors ${
                autoRenewal 
                  ? "border-primary bg-primary/10 text-primary" 
                  : "border-border text-muted-foreground hover:border-primary/50"
              }`}
              data-testid={`toggle-auto-renewal-${item.id}`}
            >
              <RefreshCw className={`h-4 w-4 ${autoRenewal ? "text-primary" : ""}`} />
              <div className="text-left">
                <span className="font-medium block">Monthly Auto-Renewal</span>
                <span className="text-xs">Never run out — auto-ships monthly</span>
              </div>
            </button>
          </div>
        )}

        <div className="mt-4">
          <Button
            onClick={handleAddToCart}
            className="w-full rounded-xl font-semibold bg-primary hover:bg-primary/90 text-white"
            data-testid={`add-to-cart-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <Plus className="mr-2 h-4 w-4" /> Add to Order
          </Button>
        </div>
      </div>
    </div>
  );
}
