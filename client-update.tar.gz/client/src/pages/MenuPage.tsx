import { useMenu } from "@/hooks/use-menu";
import { MenuItemCard } from "@/components/MenuItemCard";
import { Navigation } from "@/components/Navigation";
import { CustomPizzaBuilder } from "@/components/CustomPizzaBuilder";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Sparkles } from "lucide-react";
import montanaBadge from "@assets/IMG_0398_1772679731962.png";
import type { MenuItem } from "@shared/schema";
import { OrderPauseBanner } from "@/components/OrderPauseModal";

export default function MenuPage() {
  const { data: menuItems, isLoading, error } = useMenu();
  const { isAuthenticated, user } = useAuth();

  const { data: recommendations } = useQuery<MenuItem[]>({
    queryKey: ["/api/recommendations"],
    enabled: isAuthenticated,
  });

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-destructive">Error loading menu</h2>
          <p className="text-muted-foreground">Please try again later.</p>
        </div>
      </div>
    );
  }

  const menuOrder = [
    "Cheese", "Beef", "Italian Sausage", "Pepperoni", "Meat Lovers",
    "Veggie", "Supreme", "Marinara Sauce", "Alfredo Sauce", "Blue Cheese Dressing"
  ];

  const recommendedIds = new Set(recommendations?.map(r => r.id) || []);

  const sortByMenuOrder = (items: MenuItem[]) => {
    return [...items].sort((a, b) => {
      const indexA = menuOrder.indexOf(a.name);
      const indexB = menuOrder.indexOf(b.name);
      return (indexA === -1 ? 999 : indexA) - (indexB === -1 ? 999 : indexB);
    });
  };

  const pizzas = sortByMenuOrder(
    menuItems?.filter((item) => item.category === "pizza" && !recommendedIds.has(item.id)) || []
  );
  const sauces = sortByMenuOrder(
    menuItems?.filter((item) => item.category === "sauce" && !recommendedIds.has(item.id)) || []
  );

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12">
        <OrderPauseBanner />
        <div className="mb-12 text-center">
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-6xl font-display"
          >
            Food Menu
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mx-auto max-w-2xl text-lg text-muted-foreground"
          >
            Order your favorite homemade pizzas and sauces. We prep, you bake to perfection at home.
          </motion.p>
        </div>

        {isAuthenticated && recommendations && recommendations.length > 0 && (
          <section className="mb-16">
            <div className="mb-8 flex items-center gap-4">
              <Sparkles className="h-6 w-6 text-yellow-500" />
              <h2 className="text-2xl font-bold text-foreground font-display">Recommended for You</h2>
              <div className="h-px flex-1 bg-border" />
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {recommendations.map((item) => (
                <MenuItemCard key={item.id} item={item} />
              ))}
            </div>
          </section>
        )}

        <section className="mb-16">
          <div className="mb-8 flex items-center gap-4">
            <h2 className="text-3xl font-bold text-foreground font-display">Build Your Own</h2>
            <div className="h-px flex-1 bg-border" />
          </div>
          <p className="text-muted-foreground mb-6 -mt-4">
            12 Inch Pizza made with wholesome ingredients. See <Link href="/nutrition" className="text-primary underline hover:text-primary/80">Ingredients and Nutritional information</Link> for more information.
          </p>

          <CustomPizzaBuilder />
        </section>

        <section className="mb-16">
          <div className="mb-8 flex items-center gap-4">
            <h2 className="text-3xl font-bold text-foreground font-display">Our Pizzas</h2>
            <div className="h-px flex-1 bg-border" />
          </div>
          <p className="text-muted-foreground mb-6 -mt-4">
            12 Inch Pizza made with wholesome ingredients. See <Link href="/nutrition" className="text-primary underline hover:text-primary/80">Ingredients and Nutritional information</Link> for more information.
          </p>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {isLoading
              ? Array(6).fill(0).map((_, i) => (
                  <div key={i} className="space-y-4 rounded-3xl bg-white p-6 shadow-sm">
                    <Skeleton className="aspect-[4/3] w-full rounded-xl" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                ))
              : pizzas.map((item) => <MenuItemCard key={item.id} item={item} />)
            }
          </div>
        </section>

        <section>
          <div className="mb-8 flex items-center gap-4">
            <h2 className="text-3xl font-bold text-foreground font-display">Signature Sauces</h2>
            <div className="h-px flex-1 bg-border" />
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {isLoading
              ? Array(3).fill(0).map((_, i) => (
                  <div key={i} className="space-y-4 rounded-3xl bg-white p-6 shadow-sm">
                    <Skeleton className="aspect-[4/3] w-full rounded-xl" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                ))
              : sauces.map((item) => <MenuItemCard key={item.id} item={item} />)
            }
          </div>
        </section>

        <p className="text-center text-sm text-muted-foreground mt-8 italic" data-testid="text-image-disclaimer">
          All product images have been created using AI and may not be the exact same as the actual product.
        </p>
      </main>

      <footer className="border-t bg-muted/30 py-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground text-center">Franco's Kitchen LLC. All Rights Reserved.</p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Kitchen LLC, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80" data-testid="link-terms">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80" data-testid="link-privacy">Privacy Policy</Link>. View our <Link href="/nutrition" className="text-primary underline hover:text-primary/80" data-testid="link-nutrition">Ingredients & Nutrition</Link> information.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
