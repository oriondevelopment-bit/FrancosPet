import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((error) => {
      console.log("Service Worker registration failed:", error);
    });
  });
}

(window as any).__isAdmin = false;
(window as any).__checkAdmin = () => {
  fetch("/api/admin/me", { credentials: "include" })
    .then((r) => { if (r.ok) return r.json(); throw new Error(); })
    .then(() => {
      (window as any).__isAdmin = true;
      document.body.classList.add("admin-select");
    })
    .catch(() => {
      (window as any).__isAdmin = false;
      document.body.classList.remove("admin-select");
    });
};
(window as any).__checkAdmin();

document.addEventListener("contextmenu", (e) => {
  if (!(window as any).__isAdmin) e.preventDefault();
});
document.addEventListener("copy", (e) => {
  if (!(window as any).__isAdmin) e.preventDefault();
});
document.addEventListener("cut", (e) => {
  if (!(window as any).__isAdmin) e.preventDefault();
});
document.addEventListener("keydown", (e) => {
  if (!(window as any).__isAdmin && (e.ctrlKey || e.metaKey) && (e.key === "c" || e.key === "x" || e.key === "a" || e.key === "u")) {
    e.preventDefault();
  }
});

createRoot(document.getElementById("root")!).render(<App />);
