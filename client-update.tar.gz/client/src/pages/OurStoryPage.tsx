import { Navigation } from "@/components/Navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Heart, Users, Leaf, ShieldCheck, PawPrint, ChevronRight, MapPin } from "lucide-react";
import petStoreLogo from "@assets/ee7e7fc5-db22-4719-8b23-9145daf007d8_1773275811375.jpg";
import montanaBadge from "@assets/montana-badge_1772867253604.png";

export default function OurStoryPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <main className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-secondary/10 dark:from-primary/5 dark:via-background dark:to-secondary/5" />
          <div className="container relative px-4 py-16 md:py-24 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="mb-6"
              >
                <Heart className="h-12 w-12 mx-auto text-primary mb-4" />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-5xl font-display"
                data-testid="heading-our-story"
              >
                Our Story
              </motion.h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="mx-auto max-w-2xl text-xl text-primary font-medium italic font-display"
                data-testid="text-subtitle"
              >
                A Legacy of Family, Integrity, and Compassion
              </motion.p>
            </div>
          </div>
        </section>

        <section className="container px-4 md:px-6 pb-16">
          <div className="mx-auto max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-col md:flex-row items-center gap-8 mb-12"
            >
              <div className="flex-shrink-0">
                <img
                  src={petStoreLogo}
                  alt="Franco's Pet Store"
                  className="w-24 h-24 md:w-28 md:h-28 rounded-2xl object-cover shadow-md"
                  data-testid="img-pet-logo-story"
                />
              </div>
              <div>
                <p className="text-lg text-foreground leading-relaxed" data-testid="text-intro">
                  At Franco's Pet Store, each product we create embodies a profound commitment to quality and care, rooted in the enduring legacy of my family. This dedication draws inspiration from my grandparents, <strong>Gwen Franco</strong> and <strong>Albert Franco</strong>, esteemed owners of Strawberry Place restaurants in the United States.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mb-12"
            >
              <Card className="border-l-4 border-l-primary bg-muted/30 dark:bg-muted/10">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <Users className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-heritage">
                        The Franco Heritage
                      </h2>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-heritage-1">
                        Though they are no longer with us, their influence remains central to our mission, as they instilled in me the principles of honesty, diligence, and a deep appreciation for wholesome food and the welfare of animals.
                      </p>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-heritage-2">
                        Gwen and Albert were not merely restaurateurs; they were community leaders who cultivated inviting environments where families could enjoy nourishing meals prepared with integrity. They emphasized the use of fresh, high-quality ingredients and extended hospitality to all, including the animals that often accompanied their patrons.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mb-12"
            >
              <Card className="border-l-4 border-l-secondary bg-muted/30 dark:bg-muted/10">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <Heart className="h-8 w-8 text-secondary flex-shrink-0 mt-1" />
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-family-values">
                        Raised with Love
                      </h2>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-family-values">
                        I was raised under their guidance, alongside my mother, <strong>Mary Ann</strong>, and my Nana, <strong>Anita</strong>, in an atmosphere of mutual support and shared values. Together, they nurtured my passion for culinary excellence and compassion for all living beings, teaching me that true success lies in creating products that benefit both people and pets with sincerity and respect.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mb-12"
            >
              <Card className="border-l-4 border-l-green-600 dark:border-l-green-500 bg-muted/30 dark:bg-muted/10">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <PawPrint className="h-8 w-8 text-green-600 dark:text-green-500 flex-shrink-0 mt-1" />
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold text-foreground font-display" data-testid="heading-today">
                        Honoring the Legacy Today
                      </h2>
                      <p className="text-muted-foreground leading-relaxed" data-testid="text-today">
                        Today, Franco's Pet Store honors this heritage through our freeze-dried beef liver treats for dogs, sourced from Montana and regional ranches and crafted without additives for pure, human-grade nutrition. By choosing our treats, you participate in a tradition of family values that prioritizes ethical sourcing, animal well-being, and communal bonds.
                      </p>
                      <p className="text-foreground font-medium italic leading-relaxed" data-testid="text-invitation">
                        We invite you to join us in extending this legacy of love and quality to your own cherished companions.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="grid gap-4 sm:grid-cols-3 mb-12"
            >
              <Card data-testid="card-value-integrity">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 dark:bg-primary/20">
                    <ShieldCheck className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-bold text-foreground">Integrity</h3>
                  <p className="text-sm text-muted-foreground">
                    Honest, transparent practices in everything we source, craft, and sell.
                  </p>
                </CardContent>
              </Card>
              <Card data-testid="card-value-quality">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                    <Leaf className="h-6 w-6 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="font-bold text-foreground">Quality</h3>
                  <p className="text-sm text-muted-foreground">
                    Premium, all-natural ingredients with no additives or preservatives.
                  </p>
                </CardContent>
              </Card>
              <Card data-testid="card-value-compassion">
                <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary/10 dark:bg-secondary/20">
                    <Heart className="h-6 w-6 text-secondary" />
                  </div>
                  <h3 className="font-bold text-foreground">Compassion</h3>
                  <p className="text-sm text-muted-foreground">
                    A deep love for people, pets, and community guides every decision.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="bg-muted/40 dark:bg-muted/20 rounded-2xl p-8 text-center border"
            >
              <MapPin className="h-8 w-8 mx-auto text-primary mb-3" />
              <p className="text-sm font-medium text-muted-foreground mb-1">Made with love in</p>
              <p className="text-lg font-bold text-foreground font-display mb-4">Glendive, Montana</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/">
                  <Button className="gap-1" data-testid="button-shop-treats">
                    <PawPrint className="h-4 w-4" /> Shop Pet Treats <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-8">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto text-center text-sm text-muted-foreground space-y-4">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">Franco's Pet Store. All Rights Reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
