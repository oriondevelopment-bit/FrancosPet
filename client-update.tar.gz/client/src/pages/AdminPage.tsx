import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Loader2, Plus, Trash2, Users, ShoppingBag, Tag, MessageSquare, Building2, CheckCircle, CheckCircle2, XCircle, Settings, PauseCircle, Package, Clock, Search, Shield, UserPlus, Share2, Snowflake, Ban, UserCheck, AlertCircle, Download, FileSpreadsheet, Heart, BarChart3, Pencil, Send, ClipboardList } from "lucide-react";
import { FulfillmentTab } from "@/components/FulfillmentTab";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { SiFacebook, SiInstagram } from "react-icons/si";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Promotion, OrderWithItems, ContactInquiry, WholesaleCustomer, AdminUser, Charity, MenuItem, ProductLot } from "@shared/schema";
import type { User, CustomerProfile } from "@shared/models/auth";

type PromotionFormData = {
  title: string;
  description: string;
  discountType: string;
  discountValue: number;
  code: string;
  isActive: boolean;
  startDate: string;
  endDate: string;
};

type CustomerWithProfile = User & { profile?: CustomerProfile; orderCount: number };

const orderStatusOptions = ["pending", "confirmed", "completed", "cancelled"];

export default function AdminPage() {
  const { isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showPromoForm, setShowPromoForm] = useState(false);
  const [isAdmin, setIsAdmin] = useState(true);
  const [completeOrderModal, setCompleteOrderModal] = useState<OrderWithItems | null>(null);
  const [trackingNumber, setTrackingNumber] = useState("");
  const [scheduledPickupDate, setScheduledPickupDate] = useState("");
  const [scheduledPickupTime, setScheduledPickupTime] = useState("");
  const [orderSearch, setOrderSearch] = useState("");
  const [showExportPanel, setShowExportPanel] = useState(false);
  const [exportStartDate, setExportStartDate] = useState("");
  const [exportEndDate, setExportEndDate] = useState("");
  const [exportType, setExportType] = useState("all");
  const [showTeamForm, setShowTeamForm] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [teamEmail, setTeamEmail] = useState("");
  const [teamPermMarketing, setTeamPermMarketing] = useState(false);
  const [teamPermCS, setTeamPermCS] = useState(false);
  const [teamPermFinance, setTeamPermFinance] = useState(false);
  const [facebookUrl, setFacebookUrl] = useState("");
  const [instagramUrl, setInstagramUrl] = useState("");
  const [facebookPageId, setFacebookPageId] = useState("");
  const [instagramHandle, setInstagramHandle] = useState("");
  const [metaBusinessId, setMetaBusinessId] = useState("");
  const [metaAssetId, setMetaAssetId] = useState("");

  const [editOrderModal, setEditOrderModal] = useState<OrderWithItems | null>(null);
  const [deleteOrderModal, setDeleteOrderModal] = useState<OrderWithItems | null>(null);
  const [showAllCompleted, setShowAllCompleted] = useState(false);
  const [editForm, setEditForm] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    isDelivery: false,
    deliveryAddress: "",
    totalAmount: "",
    paymentStatus: "pending",
    status: "pending",
    trackingNumber: "",
    scheduledPickupDate: "",
    scheduledPickupTime: "",
    fulfillmentNotes: "",
  });

  const [showCharityForm, setShowCharityForm] = useState(false);
  const [editingCharity, setEditingCharity] = useState<Charity | null>(null);
  const [charityName, setCharityName] = useState("");
  const [charityDescription, setCharityDescription] = useState("");
  const [charityWebsite, setCharityWebsite] = useState("");
  const [charityEin, setCharityEin] = useState("");
  const [charityAddress, setCharityAddress] = useState("");
  const [charityCity, setCharityCity] = useState("");
  const [charityState, setCharityState] = useState("");
  const [charityZipCode, setCharityZipCode] = useState("");
  const [charityContactName, setCharityContactName] = useState("");
  const [charityContactPhone, setCharityContactPhone] = useState("");
  const [charityContactEmail, setCharityContactEmail] = useState("");
  const [charityActive, setCharityActive] = useState(true);

  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<MenuItem | null>(null);
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productCategory, setProductCategory] = useState("pet_treats");
  const [productPrice, setProductPrice] = useState("");
  const [productSku, setProductSku] = useState("");
  const [productImageFile, setProductImageFile] = useState<File | null>(null);
  const [productImagePreview, setProductImagePreview] = useState("");
  const [productFilter, setProductFilter] = useState("all");
  const [deleteProductDialog, setDeleteProductDialog] = useState<MenuItem | null>(null);
  const [skuSearch, setSkuSearch] = useState("");
  const [skuSearchResult, setSkuSearchResult] = useState<(MenuItem & { lots: ProductLot[] }) | null>(null);
  const [skuSearchError, setSkuSearchError] = useState("");
  const [showLotForm, setShowLotForm] = useState(false);
  const [editingLot, setEditingLot] = useState<ProductLot | null>(null);
  const [lotProductId, setLotProductId] = useState("");
  const [lotNumber, setLotNumber] = useState("");
  const [lotBatchDate, setLotBatchDate] = useState("");
  const [lotExpirationDate, setLotExpirationDate] = useState("");
  const [lotQuantityProduced, setLotQuantityProduced] = useState("");
  const [lotQuantityRemaining, setLotQuantityRemaining] = useState("");
  const [lotCostPerUnit, setLotCostPerUnit] = useState("");
  const [lotNotes, setLotNotes] = useState("");
  const [lotStatus, setLotStatus] = useState("active");
  const [lotFilterProduct, setLotFilterProduct] = useState("all");
  const [deleteLotDialog, setDeleteLotDialog] = useState<ProductLot | null>(null);

  const { data: adminRole } = useQuery<{ isSuperAdmin: boolean; marketing: boolean; customerService: boolean; finance: boolean }>({
    queryKey: ["/api/admin/me"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: teamMembers } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/team"],
    enabled: isAuthenticated && !!adminRole?.isSuperAdmin,
    retry: false,
  });

  const { data: searchResults } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/admin/orders/search", orderSearch],
    queryFn: async () => {
      const res = await fetch(`/api/admin/orders/search?q=${encodeURIComponent(orderSearch)}`, { credentials: "include" });
      if (!res.ok) throw new Error("Search failed");
      return res.json();
    },
    enabled: isAuthenticated && orderSearch.length >= 2,
    retry: false,
  });

  const { data: promotions, isLoading: promosLoading, error: promosError } = useQuery<Promotion[]>({
    queryKey: ["/api/admin/promotions"],
    enabled: isAuthenticated,
    retry: false,
  });

  useEffect(() => {
    if (promosError && promosError.message.includes("403")) {
      setIsAdmin(false);
    }
  }, [promosError]);

  const { data: customers, isLoading: customersLoading } = useQuery<CustomerWithProfile[]>({
    queryKey: ["/api/admin/customers"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/admin/orders"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const { data: inquiries, isLoading: inquiriesLoading } = useQuery<ContactInquiry[]>({
    queryKey: ["/api/admin/inquiries"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const { data: wholesaleCustomers, isLoading: wholesaleLoading } = useQuery<WholesaleCustomer[]>({
    queryKey: ["/api/admin/wholesale"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const { data: charitiesList, isLoading: charitiesLoading } = useQuery<Charity[]>({
    queryKey: ["/api/admin/charities"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  type DonationSummary = {
    totalDonations: number;
    totalOrders: number;
    byCharity: { name: string; total: number; orderCount: number }[];
    byLocation: { city: string; state: string; total: number; orderCount: number }[];
    byProduct: { name: string; total: number; quantity: number }[];
    byMonth: { month: string; total: number }[];
  };

  const { data: donationSummary, isLoading: donationsLoading } = useQuery<DonationSummary>({
    queryKey: ["/api/admin/donations/summary"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  type QrScanSummary = {
    businessName: string;
    totalScans: number;
    convertedScans: number;
    conversionRate: number;
  };

  const { data: products, isLoading: productsLoading } = useQuery<MenuItem[]>({
    queryKey: ["/api/admin/products"],
    enabled: isAuthenticated && isAdmin && !!(adminRole?.isSuperAdmin || adminRole?.marketing),
    retry: false,
  });

  const { data: lots, isLoading: lotsLoading } = useQuery<ProductLot[]>({
    queryKey: ["/api/admin/lots"],
    enabled: isAuthenticated && isAdmin && !!(adminRole?.isSuperAdmin || adminRole?.marketing),
    retry: false,
  });

  const { data: qrScansSummary, isLoading: qrScansLoading } = useQuery<QrScanSummary[]>({
    queryKey: ["/api/admin/qr-scans/summary"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const resetProductForm = () => {
    setProductName("");
    setProductDescription("");
    setProductCategory("pet_treats");
    setProductPrice("");
    setProductSku("");
    setProductImageFile(null);
    setProductImagePreview("");
    setEditingProduct(null);
    setShowProductForm(false);
  };

  const startEditProduct = (product: MenuItem) => {
    setEditingProduct(product);
    setProductName(product.name);
    setProductDescription(product.description || "");
    setProductCategory(product.category);
    setProductPrice(String(product.price));
    setProductSku(product.sku || "");
    setProductImagePreview(product.imageUrl || "");
    setProductImageFile(null);
    setShowProductForm(true);
  };

  const resetLotForm = () => {
    setLotProductId("");
    setLotNumber("");
    setLotBatchDate("");
    setLotExpirationDate("");
    setLotQuantityProduced("");
    setLotQuantityRemaining("");
    setLotCostPerUnit("");
    setLotNotes("");
    setLotStatus("active");
    setEditingLot(null);
    setShowLotForm(false);
  };

  const startEditLot = (lot: ProductLot) => {
    setEditingLot(lot);
    setLotProductId(String(lot.menuItemId));
    setLotNumber(lot.lotNumber);
    setLotBatchDate(lot.batchDate ? new Date(lot.batchDate).toISOString().split("T")[0] : "");
    setLotExpirationDate(lot.expirationDate ? new Date(lot.expirationDate).toISOString().split("T")[0] : "");
    setLotQuantityProduced(String(lot.quantityProduced));
    setLotQuantityRemaining(String(lot.quantityRemaining));
    setLotCostPerUnit(lot.costPerUnit ? String(lot.costPerUnit) : "");
    setLotNotes(lot.notes || "");
    setLotStatus(lot.status);
    setShowLotForm(true);
  };

  const createProductMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/menu"] });
      toast({ title: "Product Created", description: "New product has been added." });
      resetProductForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create product.", variant: "destructive" });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, formData }: { id: number; formData: FormData }) => {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: "PATCH",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/menu"] });
      toast({ title: "Product Updated", description: "Product has been updated." });
      resetProductForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update product.", variant: "destructive" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/products/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/menu"] });
      toast({ title: "Product Deleted", description: "Product has been removed." });
      setDeleteProductDialog(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete product.", variant: "destructive" });
    },
  });

  const handleProductSubmit = () => {
    const formData = new FormData();
    formData.append("name", productName);
    formData.append("description", productDescription);
    formData.append("category", productCategory);
    formData.append("price", productPrice);
    if (productSku) formData.append("sku", productSku);
    if (productImageFile) {
      formData.append("image", productImageFile);
    }

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, formData });
    } else {
      createProductMutation.mutate(formData);
    }
  };

  const handleSkuSearch = async () => {
    if (!skuSearch.trim()) return;
    setSkuSearchError("");
    setSkuSearchResult(null);
    try {
      const res = await fetch(`/api/admin/products/sku/${encodeURIComponent(skuSearch.trim())}`, { credentials: "include" });
      if (!res.ok) {
        const data = await res.json();
        setSkuSearchError(data.message || "Product not found");
        return;
      }
      const data = await res.json();
      setSkuSearchResult(data);
    } catch {
      setSkuSearchError("Failed to search SKU");
    }
  };

  const createLotMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/admin/lots", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lots"] });
      toast({ title: "Lot Created", description: "New batch lot has been recorded." });
      resetLotForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create lot.", variant: "destructive" });
    },
  });

  const updateLotMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return await apiRequest(`/api/admin/lots/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lots"] });
      toast({ title: "Lot Updated", description: "Batch lot has been updated." });
      resetLotForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update lot.", variant: "destructive" });
    },
  });

  const deleteLotMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/lots/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lots"] });
      toast({ title: "Lot Deleted", description: "Batch lot has been removed." });
      setDeleteLotDialog(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete lot.", variant: "destructive" });
    },
  });

  const handleLotSubmit = () => {
    const data: any = {
      menuItemId: Number(lotProductId),
      lotNumber: lotNumber,
      batchDate: lotBatchDate,
      quantityProduced: Number(lotQuantityProduced),
      quantityRemaining: Number(lotQuantityRemaining),
      status: lotStatus,
    };
    if (lotExpirationDate) data.expirationDate = lotExpirationDate;
    if (lotCostPerUnit) data.costPerUnit = Number(lotCostPerUnit);
    if (lotNotes) data.notes = lotNotes;

    if (editingLot) {
      updateLotMutation.mutate({ id: editingLot.id, data });
    } else {
      createLotMutation.mutate(data);
    }
  };

  const handleProductImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProductImageFile(file);
      const reader = new FileReader();
      reader.onload = (ev) => setProductImagePreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const approveWholesaleMutation = useMutation({
    mutationFn: async ({ id, approved, notes }: { id: number; approved: boolean; notes?: string }) => {
      return await apiRequest(`/api/admin/wholesale/${id}/approve`, {
        method: "PATCH",
        body: JSON.stringify({ approved, notes }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/wholesale"] });
      toast({ title: "Updated", description: "Wholesale customer status updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update status.", variant: "destructive" });
    },
  });

  // Order Pause Settings
  type OrderPauseSettings = {
    enabled: boolean;
    message: string;
    startTime: string | null;
    endTime: string | null;
  };

  const { data: orderPauseSettings, isLoading: pauseLoading } = useQuery<OrderPauseSettings>({
    queryKey: ["/api/admin/order-pause"],
    enabled: isAuthenticated && isAdmin,
    retry: false,
  });

  const [pauseEnabled, setPauseEnabled] = useState(false);
  const [pauseMessage, setPauseMessage] = useState("We are temporarily not accepting orders. Please check back soon!");
  const [pauseStartTime, setPauseStartTime] = useState("");
  const [pauseEndTime, setPauseEndTime] = useState("");
  const [notifyCustomers, setNotifyCustomers] = useState(false);

  useEffect(() => {
    if (orderPauseSettings) {
      setPauseEnabled(orderPauseSettings.enabled);
      setPauseMessage(orderPauseSettings.message || "We are temporarily not accepting orders. Please check back soon!");
      setPauseStartTime(orderPauseSettings.startTime ? new Date(orderPauseSettings.startTime).toISOString().slice(0, 16) : "");
      setPauseEndTime(orderPauseSettings.endTime ? new Date(orderPauseSettings.endTime).toISOString().slice(0, 16) : "");
    }
  }, [orderPauseSettings]);

  const updateOrderPauseMutation = useMutation({
    mutationFn: async (data: { enabled: boolean; message: string; startTime: string | null; endTime: string | null; notifyCustomers: boolean }) => {
      return await apiRequest("/api/admin/order-pause", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/order-pause"] });
      queryClient.invalidateQueries({ queryKey: ["/api/order-status"] });
      const desc = notifyCustomers 
        ? "Order settings saved. Notifications are being sent to opted-in customers."
        : "Order pause settings have been saved.";
      toast({ title: "Settings Updated", description: desc });
      setNotifyCustomers(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update settings.", variant: "destructive" });
    },
  });

  const handleSaveOrderPause = () => {
    updateOrderPauseMutation.mutate({
      enabled: pauseEnabled,
      message: pauseMessage,
      startTime: pauseStartTime ? new Date(pauseStartTime).toISOString() : null,
      endTime: pauseEndTime ? new Date(pauseEndTime).toISOString() : null,
      notifyCustomers,
    });
  };

  const { data: shipStationStatus, isLoading: shipStationStatusLoading } = useQuery<{ connected: boolean; carriers: string[] }>({
    queryKey: ["/api/shipstation/status"],
    enabled: isAuthenticated && !!adminRole?.isSuperAdmin,
    retry: false,
  });

  type SocialMediaSettings = {
    facebookUrl: string;
    instagramUrl: string;
    facebookPageId: string;
    instagramHandle: string;
    metaBusinessId: string;
    metaAssetId: string;
  };

  const { data: socialMedia, isLoading: socialLoading } = useQuery<SocialMediaSettings>({
    queryKey: ["/api/admin/social-media"],
    enabled: isAuthenticated && (!!adminRole?.isSuperAdmin || !!adminRole?.marketing),
    retry: false,
  });

  useEffect(() => {
    if (socialMedia) {
      setFacebookUrl(socialMedia.facebookUrl || "");
      setInstagramUrl(socialMedia.instagramUrl || "");
      setFacebookPageId(socialMedia.facebookPageId || "");
      setInstagramHandle(socialMedia.instagramHandle || "");
      setMetaBusinessId(socialMedia.metaBusinessId || "");
      setMetaAssetId(socialMedia.metaAssetId || "");
    }
  }, [socialMedia]);

  const updateSocialMediaMutation = useMutation({
    mutationFn: async (data: SocialMediaSettings) => {
      return await apiRequest("/api/admin/social-media", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/social-media"] });
      toast({ title: "Saved", description: "Social media settings updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update social media settings.", variant: "destructive" });
    },
  });

  const handleSaveSocialMedia = () => {
    updateSocialMediaMutation.mutate({ facebookUrl, instagramUrl, facebookPageId, instagramHandle, metaBusinessId, metaAssetId });
  };

  const promoForm = useForm<PromotionFormData>({
    defaultValues: {
      title: "",
      description: "",
      discountType: "percentage",
      discountValue: 10,
      code: "",
      isActive: true,
      startDate: new Date().toISOString().split("T")[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    },
  });

  const createPromoMutation = useMutation({
    mutationFn: async (data: PromotionFormData) => {
      return await apiRequest("/api/admin/promotions", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          discountValue: data.discountType === "percentage" ? data.discountValue : data.discountValue * 100,
          startDate: new Date(data.startDate),
          endDate: new Date(data.endDate),
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/promotions"] });
      promoForm.reset();
      setShowPromoForm(false);
      toast({ title: "Promotion Created", description: "The promotion has been added." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create promotion.", variant: "destructive" });
    },
  });

  const deletePromoMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/promotions/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/promotions"] });
      toast({ title: "Deleted", description: "Promotion has been removed." });
    },
  });

  const createTeamMemberMutation = useMutation({
    mutationFn: async (data: { name: string; email: string; permMarketing: boolean; permCustomerService: boolean; permFinance: boolean; isActive: boolean }) => {
      return await apiRequest("/api/admin/team", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/team"] });
      toast({ title: "Team Member Added", description: "New team member has been added." });
      setShowTeamForm(false);
      setTeamName("");
      setTeamEmail("");
      setTeamPermMarketing(false);
      setTeamPermCS(false);
      setTeamPermFinance(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add team member.", variant: "destructive" });
    },
  });

  const updateTeamMemberMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; [key: string]: any }) => {
      return await apiRequest(`/api/admin/team/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/team"] });
      toast({ title: "Updated", description: "Team member updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update team member.", variant: "destructive" });
    },
  });

  const deleteTeamMemberMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/team/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/team"] });
      toast({ title: "Deleted", description: "Team member has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete team member.", variant: "destructive" });
    },
  });

  const [adminVerifyId, setAdminVerifyId] = useState<number | null>(null);
  const [adminVerifyCode, setAdminVerifyCode] = useState("");

  const sendAdminVerificationMutation = useMutation({
    mutationFn: async (adminUserId: number) => {
      return await apiRequest("/api/admin/verify/send", {
        method: "POST",
        body: JSON.stringify({ type: "email", adminUserId }),
      });
    },
    onSuccess: (_, adminUserId) => {
      setAdminVerifyId(adminUserId);
      setAdminVerifyCode("");
      toast({ title: "Code Sent", description: "Verification code sent to email." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send verification code.", variant: "destructive" });
    },
  });

  const confirmAdminVerificationMutation = useMutation({
    mutationFn: async ({ adminUserId, code }: { adminUserId: number; code: string }) => {
      return await apiRequest("/api/admin/verify/confirm", {
        method: "POST",
        body: JSON.stringify({ adminUserId, code }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/team"] });
      setAdminVerifyId(null);
      setAdminVerifyCode("");
      toast({ title: "Verified", description: "Email verified successfully." });
    },
    onError: () => {
      toast({ title: "Invalid Code", description: "The code is invalid or expired.", variant: "destructive" });
    },
  });

  // Customer management mutations
  const [showCreateCustomer, setShowCreateCustomer] = useState(false);
  const [newCustomerFirst, setNewCustomerFirst] = useState("");
  const [newCustomerLast, setNewCustomerLast] = useState("");
  const [newCustomerEmail, setNewCustomerEmail] = useState("");
  const [newCustomerPhone, setNewCustomerPhone] = useState("");

  const freezeCustomerMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return await apiRequest(`/api/admin/customers/${id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/customers"] });
      toast({ title: "Updated", description: "Customer account status updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update customer status.", variant: "destructive" });
    },
  });

  const deleteCustomerMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/admin/customers/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/customers"] });
      toast({ title: "Deleted", description: "Customer account has been permanently removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete customer.", variant: "destructive" });
    },
  });

  const createCustomerMutation = useMutation({
    mutationFn: async (data: { email: string; firstName: string; lastName: string; phone?: string }) => {
      return await apiRequest("/api/admin/customers", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/customers"] });
      toast({ title: "Customer Created", description: "New customer account has been created." });
      setShowCreateCustomer(false);
      setNewCustomerFirst("");
      setNewCustomerLast("");
      setNewCustomerEmail("");
      setNewCustomerPhone("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err?.message || "Failed to create customer.", variant: "destructive" });
    },
  });

  const deleteWholesaleMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/wholesale/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/wholesale"] });
      toast({ title: "Deleted", description: "Wholesale customer has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete wholesale customer.", variant: "destructive" });
    },
  });

  const createCharityMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string; website?: string; ein?: string; isActive: boolean }) => {
      return await apiRequest("/api/admin/charities", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/charities"] });
      toast({ title: "Charity Created", description: "The charity has been added." });
      resetCharityForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create charity.", variant: "destructive" });
    },
  });

  const updateCharityMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; name?: string; description?: string; website?: string; ein?: string; isActive?: boolean }) => {
      return await apiRequest(`/api/admin/charities/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/charities"] });
      toast({ title: "Updated", description: "Charity has been updated." });
      resetCharityForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update charity.", variant: "destructive" });
    },
  });

  const deleteCharityMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/charities/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/charities"] });
      toast({ title: "Deleted", description: "Charity has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete charity.", variant: "destructive" });
    },
  });

  const resetCharityForm = () => {
    setShowCharityForm(false);
    setEditingCharity(null);
    setCharityName("");
    setCharityDescription("");
    setCharityWebsite("");
    setCharityEin("");
    setCharityAddress("");
    setCharityCity("");
    setCharityState("");
    setCharityZipCode("");
    setCharityContactName("");
    setCharityContactPhone("");
    setCharityContactEmail("");
    setCharityActive(true);
  };

  const startEditCharity = (charity: Charity) => {
    setEditingCharity(charity);
    setCharityName(charity.name);
    setCharityDescription(charity.description || "");
    setCharityWebsite(charity.website || "");
    setCharityEin(charity.ein || "");
    setCharityAddress((charity as any).address || "");
    setCharityCity((charity as any).city || "");
    setCharityState((charity as any).state || "");
    setCharityZipCode((charity as any).zipCode || "");
    setCharityContactName((charity as any).contactName || "");
    setCharityContactPhone((charity as any).contactPhone || "");
    setCharityContactEmail((charity as any).contactEmail || "");
    setCharityActive(charity.isActive);
    setShowCharityForm(true);
  };

  const handleCharitySubmit = () => {
    const data = {
      name: charityName,
      description: charityDescription || undefined,
      website: charityWebsite || undefined,
      ein: charityEin || undefined,
      address: charityAddress || undefined,
      city: charityCity || undefined,
      state: charityState || undefined,
      zipCode: charityZipCode || undefined,
      contactName: charityContactName || undefined,
      contactPhone: charityContactPhone || undefined,
      contactEmail: charityContactEmail || undefined,
      isActive: charityActive,
    };
    if (editingCharity) {
      updateCharityMutation.mutate({ id: editingCharity.id, ...data });
    } else {
      createCharityMutation.mutate(data);
    }
  };

  const formatMoney = (cents: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);

  const getCharityName = (charityId: number | null | undefined) => {
    if (!charityId || !charitiesList) return null;
    const charity = charitiesList.find(c => c.id === charityId);
    return charity?.name || null;
  };

  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, status, trackingNumber, scheduledPickupDate, scheduledPickupTime }: { id: number; status: string; trackingNumber?: string; scheduledPickupDate?: string; scheduledPickupTime?: string }) => {
      return await apiRequest(`/api/admin/orders/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ status, trackingNumber, scheduledPickupDate, scheduledPickupTime }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({ title: "Updated", description: "Order status has been updated." });
      setCompleteOrderModal(null);
      setTrackingNumber("");
      setScheduledPickupDate("");
      setScheduledPickupTime("");
    },
  });

  const editOrderMutation = useMutation({
    mutationFn: async ({ id, ...updates }: { id: number; [key: string]: any }) => {
      return await apiRequest(`/api/admin/orders/${id}`, {
        method: "PUT",
        body: JSON.stringify(updates),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({ title: "Order Updated", description: "Order details have been saved." });
      setEditOrderModal(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update order.", variant: "destructive" });
    },
  });

  const deleteOrderMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/orders/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({ title: "Order Deleted", description: "The order has been permanently removed." });
      setDeleteOrderModal(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete order.", variant: "destructive" });
    },
  });

  const openEditModal = (order: OrderWithItems) => {
    setEditForm({
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone,
      isDelivery: order.isDelivery,
      deliveryAddress: order.deliveryAddress || "",
      totalAmount: (order.totalAmount / 100).toFixed(2),
      paymentStatus: order.paymentStatus || "pending",
      status: order.status,
      trackingNumber: order.trackingNumber || "",
      scheduledPickupDate: order.scheduledPickupDate || "",
      scheduledPickupTime: order.scheduledPickupTime || "",
      fulfillmentNotes: order.fulfillmentNotes || "",
    });
    setEditOrderModal(order);
  };

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);


  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container px-4 py-8 md:px-6 md:py-12">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold font-display text-destructive mb-4">Access Denied</h1>
            <p className="text-muted-foreground mb-6">
              You don't have admin privileges to access this page.
            </p>
            <a href="/">
              <Button>Return to Menu</Button>
            </a>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container px-4 py-8 md:px-6 md:py-12">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display" data-testid="text-page-title">Admin Panel</h1>
            <p className="text-muted-foreground mt-2">Manage promotions, orders, and customers</p>
          </div>

          {(() => {
            const sa = adminRole?.isSuperAdmin;
            const showProducts = sa || adminRole?.marketing;
            const showPromotions = sa || adminRole?.marketing;
            const showOrders = sa || adminRole?.customerService || adminRole?.finance;
            const showCustomers = sa || adminRole?.marketing || adminRole?.customerService;
            const showWholesale = sa || adminRole?.finance;
            const showInquiries = sa || adminRole?.customerService;
            const showCharities = sa || adminRole?.finance;
            const showDonations = sa || adminRole?.finance;
            const showFulfillment = showOrders;
            const showSettings = sa;
            const showTeam = sa;
            const visibleTabCount = [showProducts, showPromotions, showOrders, showFulfillment, showCustomers, showWholesale, showInquiries, showCharities, showDonations, showSettings, showTeam].filter(Boolean).length;
            const defaultTab = (sa || adminRole?.marketing) ? "products" : adminRole?.customerService ? "orders" : adminRole?.finance ? "wholesale" : "products";
            return (
          <Tabs defaultValue={defaultTab} className="space-y-6">
            <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${visibleTabCount || 7}, minmax(0, 1fr))` }}>
              {showProducts && (
              <TabsTrigger value="products" className="flex items-center gap-2" data-testid="tab-products">
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">Products</span>
              </TabsTrigger>
              )}
              {showPromotions && (
              <TabsTrigger value="promotions" className="flex items-center gap-2" data-testid="tab-promotions">
                <Tag className="h-4 w-4" />
                <span className="hidden sm:inline">Promotions</span>
              </TabsTrigger>
              )}
              {showOrders && (
              <TabsTrigger value="orders" className="flex items-center gap-2" data-testid="tab-orders">
                <ShoppingBag className="h-4 w-4" />
                <span className="hidden sm:inline">Orders</span>
              </TabsTrigger>
              )}
              {showFulfillment && (
              <TabsTrigger value="fulfillment" className="flex items-center gap-2" data-testid="tab-fulfillment">
                <ClipboardList className="h-4 w-4" />
                <span className="hidden sm:inline">Fulfillment</span>
              </TabsTrigger>
              )}
              {showCustomers && (
              <TabsTrigger value="customers" className="flex items-center gap-2" data-testid="tab-customers">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Customers</span>
              </TabsTrigger>
              )}
              {showWholesale && (
              <TabsTrigger value="wholesale" className="flex items-center gap-2" data-testid="tab-wholesale">
                <Building2 className="h-4 w-4" />
                <span className="hidden sm:inline">Wholesale</span>
              </TabsTrigger>
              )}
              {showInquiries && (
              <TabsTrigger value="inquiries" className="flex items-center gap-2" data-testid="tab-inquiries">
                <MessageSquare className="h-4 w-4" />
                <span className="hidden sm:inline">Inquiries</span>
              </TabsTrigger>
              )}
              {showCharities && (
              <TabsTrigger value="charities" className="flex items-center gap-2" data-testid="tab-charities">
                <Heart className="h-4 w-4" />
                <span className="hidden sm:inline">Charities</span>
              </TabsTrigger>
              )}
              {showDonations && (
              <TabsTrigger value="donations" className="flex items-center gap-2" data-testid="tab-donations">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Donations</span>
              </TabsTrigger>
              )}
              {showSettings && (
              <TabsTrigger value="settings" className="flex items-center gap-2" data-testid="tab-settings">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">Settings</span>
              </TabsTrigger>
              )}
              {showTeam && (
              <TabsTrigger value="team" className="flex items-center gap-2" data-testid="tab-team">
                <Shield className="h-4 w-4" />
                <span className="hidden sm:inline">Team</span>
              </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="products" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Products</h2>
                <Button onClick={() => { resetProductForm(); setShowProductForm(true); }} data-testid="button-new-product">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              </div>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2"><Search className="h-4 w-4" /> SKU Scanner</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Input
                      value={skuSearch}
                      onChange={(e) => setSkuSearch(e.target.value.toUpperCase())}
                      placeholder="Enter or scan SKU (e.g. PZ-0001)"
                      onKeyDown={(e) => e.key === "Enter" && handleSkuSearch()}
                      data-testid="input-sku-search"
                    />
                    <Button onClick={handleSkuSearch} data-testid="button-sku-search">
                      <Search className="mr-2 h-4 w-4" /> Look Up
                    </Button>
                  </div>
                  {skuSearchError && (
                    <p className="text-sm text-destructive mt-2" data-testid="text-sku-error">{skuSearchError}</p>
                  )}
                  {skuSearchResult && (
                    <Card className="mt-3 bg-muted/50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold" data-testid="text-sku-result-name">{skuSearchResult.name}</h4>
                            <div className="flex gap-2 mt-1">
                              <Badge variant="outline" data-testid="text-sku-result-sku">{skuSearchResult.sku}</Badge>
                              <Badge variant="secondary">{skuSearchResult.category === "pet_treats" ? "Pet Treats" : skuSearchResult.category === "pet_toys" ? "Pet Toys" : skuSearchResult.category.charAt(0).toUpperCase() + skuSearchResult.category.slice(1)}</Badge>
                            </div>
                            {skuSearchResult.description && <p className="text-sm text-muted-foreground mt-1">{skuSearchResult.description}</p>}
                          </div>
                          <div className="text-right">
                            <span className="text-lg font-bold text-primary">${(skuSearchResult.price / 100).toFixed(2)}</span>
                          </div>
                        </div>
                        {skuSearchResult.lots.length > 0 && (
                          <div className="mt-3 border-t pt-3">
                            <p className="text-sm font-medium mb-2">Active Lots ({skuSearchResult.lots.length})</p>
                            <div className="space-y-1">
                              {skuSearchResult.lots.map(lot => (
                                <div key={lot.id} className="flex justify-between text-sm bg-background rounded px-2 py-1">
                                  <span>Lot #{lot.lotNumber}</span>
                                  <span>{lot.quantityRemaining} remaining</span>
                                  <Badge variant={lot.status === "active" ? "default" : lot.status === "depleted" ? "secondary" : "destructive"} className="text-xs">{lot.status}</Badge>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        <div className="flex gap-2 mt-3">
                          <Button size="sm" variant="outline" onClick={() => startEditProduct(skuSearchResult)} data-testid="button-sku-edit">
                            <Pencil className="mr-1 h-3 w-3" /> Edit
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => { setSkuSearchResult(null); setSkuSearch(""); }}>
                            Clear
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>

              {showProductForm && (
                <Card>
                  <CardHeader>
                    <CardTitle>{editingProduct ? "Edit Product" : "Add Product"}</CardTitle>
                    <CardDescription>{editingProduct ? "Update product details" : "Add a new product to the menu"}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="product-name">Name *</Label>
                          <Input
                            id="product-name"
                            value={productName}
                            onChange={(e) => setProductName(e.target.value)}
                            placeholder="e.g. Margherita Pizza"
                            data-testid="input-product-name"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="product-category">Category *</Label>
                          <Select value={productCategory} onValueChange={setProductCategory}>
                            <SelectTrigger data-testid="select-product-category">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pet_treats">Pet Treats</SelectItem>
                              <SelectItem value="pet_toys">Pet Toys</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="product-sku">SKU</Label>
                          <Input
                            id="product-sku"
                            value={productSku}
                            onChange={(e) => setProductSku(e.target.value.toUpperCase())}
                            placeholder="Auto-generated if empty"
                            data-testid="input-product-sku"
                          />
                          <p className="text-xs text-muted-foreground">Leave blank to auto-generate</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="product-description">Description</Label>
                        <Textarea
                          id="product-description"
                          value={productDescription}
                          onChange={(e) => setProductDescription(e.target.value)}
                          placeholder="Describe the product..."
                          rows={3}
                          data-testid="input-product-description"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="product-price">Price (in cents) *</Label>
                          <Input
                            id="product-price"
                            type="number"
                            value={productPrice}
                            onChange={(e) => setProductPrice(e.target.value)}
                            placeholder="e.g. 1500 for $15.00"
                            data-testid="input-product-price"
                          />
                          {productPrice && (
                            <p className="text-xs text-muted-foreground">
                              Display price: ${(Number(productPrice) / 100).toFixed(2)}
                            </p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="product-image">Product Image</Label>
                          <Input
                            id="product-image"
                            type="file"
                            accept="image/*"
                            onChange={handleProductImageChange}
                            data-testid="input-product-image"
                          />
                          {productImagePreview && (
                            <div className="mt-2 relative w-24 h-24 rounded-lg overflow-hidden border">
                              <img src={productImagePreview} alt="Preview" className="w-full h-full object-cover" />
                              <button type="button" onClick={() => { setProductImageFile(null); setProductImagePreview(""); }} className="absolute top-1 right-1 bg-background/80 rounded-full p-0.5">
                                <XCircle className="h-4 w-4 text-destructive" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button
                          onClick={handleProductSubmit}
                          disabled={!productName || !productPrice || createProductMutation.isPending || updateProductMutation.isPending}
                          data-testid="button-save-product"
                        >
                          {(createProductMutation.isPending || updateProductMutation.isPending) && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          {editingProduct ? "Update Product" : "Create Product"}
                        </Button>
                        <Button variant="outline" onClick={resetProductForm} data-testid="button-cancel-product">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="flex gap-2 flex-wrap">
                {[
                  { value: "all", label: "All" },
                  { value: "pet_treats", label: "Pet Treats" },
                  { value: "pet_toys", label: "Pet Toys" },
                  { value: "other", label: "Other" },
                ].map((cat) => (
                  <Button
                    key={cat.value}
                    variant={productFilter === cat.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => setProductFilter(cat.value)}
                    data-testid={`filter-product-${cat.value}`}
                  >
                    {cat.label}
                  </Button>
                ))}
              </div>

              {productsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(products || [])
                    .filter(p => productFilter === "all" || p.category === productFilter)
                    .map((product) => (
                    <Card key={product.id} className="overflow-hidden" data-testid={`card-product-${product.id}`}>
                      {product.imageUrl && (
                        <div className="h-40 overflow-hidden bg-muted">
                          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" data-testid={`img-product-${product.id}`} />
                        </div>
                      )}
                      <CardContent className="p-4 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold" data-testid={`text-product-name-${product.id}`}>{product.name}</h3>
                            <div className="flex gap-1 mt-1 flex-wrap">
                              <Badge variant="secondary" data-testid={`badge-product-category-${product.id}`}>
                                {product.category === "pet_treats" ? "Pet Treats" : product.category === "pet_toys" ? "Pet Toys" : product.category.charAt(0).toUpperCase() + product.category.slice(1)}
                              </Badge>
                              {product.sku && (
                                <Badge variant="outline" className="font-mono text-xs" data-testid={`badge-product-sku-${product.id}`}>
                                  {product.sku}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <span className="text-lg font-bold text-primary" data-testid={`text-product-price-${product.id}`}>
                            ${(product.price / 100).toFixed(2)}
                          </span>
                        </div>
                        {product.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-product-desc-${product.id}`}>
                            {product.description}
                          </p>
                        )}
                        <div className="flex gap-2 pt-2">
                          <Button variant="outline" size="sm" onClick={() => startEditProduct(product)} data-testid={`button-edit-product-${product.id}`}>
                            <Pencil className="mr-1 h-3 w-3" /> Edit
                          </Button>
                          <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => setDeleteProductDialog(product)} data-testid={`button-delete-product-${product.id}`}>
                            <Trash2 className="mr-1 h-3 w-3" /> Delete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {!productsLoading && products && products.filter(p => productFilter === "all" || p.category === productFilter).length === 0 && (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    <Package className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No products found{productFilter !== "all" ? ` in "${productFilter}" category` : ""}.</p>
                    <Button variant="link" onClick={() => { resetProductForm(); setShowProductForm(true); }} className="mt-2">
                      Add your first product
                    </Button>
                  </CardContent>
                </Card>
              )}

              {(adminRole?.isSuperAdmin || adminRole?.marketing) && (
              <div className="border-t pt-6 mt-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold">Lot / Batch Tracking</h2>
                  <Button onClick={() => { resetLotForm(); setShowLotForm(true); }} data-testid="button-new-lot">
                    <Plus className="mr-2 h-4 w-4" /> Add Lot
                  </Button>
                </div>

                {showLotForm && (
                  <Card className="mb-4">
                    <CardHeader>
                      <CardTitle>{editingLot ? "Edit Lot" : "Add New Lot"}</CardTitle>
                      <CardDescription>{editingLot ? "Update batch lot details" : "Record a new production batch"}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="lot-product">Product *</Label>
                            <Select value={lotProductId} onValueChange={setLotProductId}>
                              <SelectTrigger data-testid="select-lot-product">
                                <SelectValue placeholder="Select product" />
                              </SelectTrigger>
                              <SelectContent>
                                {(products || []).map(p => (
                                  <SelectItem key={p.id} value={String(p.id)}>{p.name} {p.sku ? `(${p.sku})` : ""}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lot-number">Lot Number *</Label>
                            <Input id="lot-number" value={lotNumber} onChange={(e) => setLotNumber(e.target.value)} placeholder="e.g. LOT-2026-001" data-testid="input-lot-number" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lot-status">Status</Label>
                            <Select value={lotStatus} onValueChange={setLotStatus}>
                              <SelectTrigger data-testid="select-lot-status">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="depleted">Depleted</SelectItem>
                                <SelectItem value="recalled">Recalled</SelectItem>
                                <SelectItem value="expired">Expired</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="lot-batch-date">Batch Date *</Label>
                            <Input id="lot-batch-date" type="date" value={lotBatchDate} onChange={(e) => setLotBatchDate(e.target.value)} data-testid="input-lot-batch-date" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lot-expiration-date">Expiration Date</Label>
                            <Input id="lot-expiration-date" type="date" value={lotExpirationDate} onChange={(e) => setLotExpirationDate(e.target.value)} data-testid="input-lot-expiration-date" />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="lot-qty-produced">Quantity Produced *</Label>
                            <Input id="lot-qty-produced" type="number" value={lotQuantityProduced} onChange={(e) => setLotQuantityProduced(e.target.value)} placeholder="e.g. 100" data-testid="input-lot-qty-produced" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lot-qty-remaining">Quantity Remaining *</Label>
                            <Input id="lot-qty-remaining" type="number" value={lotQuantityRemaining} onChange={(e) => setLotQuantityRemaining(e.target.value)} placeholder="e.g. 100" data-testid="input-lot-qty-remaining" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lot-cost">Cost Per Unit (cents)</Label>
                            <Input id="lot-cost" type="number" value={lotCostPerUnit} onChange={(e) => setLotCostPerUnit(e.target.value)} placeholder="e.g. 250 for $2.50" data-testid="input-lot-cost" />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="lot-notes">Notes</Label>
                          <Textarea id="lot-notes" value={lotNotes} onChange={(e) => setLotNotes(e.target.value)} placeholder="Optional batch notes..." rows={2} data-testid="input-lot-notes" />
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button
                            onClick={handleLotSubmit}
                            disabled={!lotProductId || !lotNumber || !lotBatchDate || !lotQuantityProduced || !lotQuantityRemaining || createLotMutation.isPending || updateLotMutation.isPending}
                            data-testid="button-save-lot"
                          >
                            {(createLotMutation.isPending || updateLotMutation.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {editingLot ? "Update Lot" : "Create Lot"}
                          </Button>
                          <Button variant="outline" onClick={resetLotForm} data-testid="button-cancel-lot">Cancel</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="flex gap-2 flex-wrap mb-4">
                  <Button variant={lotFilterProduct === "all" ? "default" : "outline"} size="sm" onClick={() => setLotFilterProduct("all")} data-testid="filter-lot-all">
                    All Products
                  </Button>
                  {(products || []).map(p => (
                    <Button key={p.id} variant={lotFilterProduct === String(p.id) ? "default" : "outline"} size="sm" onClick={() => setLotFilterProduct(String(p.id))} data-testid={`filter-lot-${p.id}`}>
                      {p.name}
                    </Button>
                  ))}
                </div>

                {lotsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <div className="space-y-2">
                    {(lots || [])
                      .filter(l => lotFilterProduct === "all" || String(l.menuItemId) === lotFilterProduct)
                      .map(lot => {
                        const product = (products || []).find(p => p.id === lot.menuItemId);
                        return (
                          <Card key={lot.id} data-testid={`card-lot-${lot.id}`}>
                            <CardContent className="p-4">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-semibold" data-testid={`text-lot-number-${lot.id}`}>Lot #{lot.lotNumber}</span>
                                    <Badge variant={lot.status === "active" ? "default" : lot.status === "depleted" ? "secondary" : "destructive"} data-testid={`badge-lot-status-${lot.id}`}>
                                      {lot.status}
                                    </Badge>
                                    {product && <Badge variant="outline">{product.name}</Badge>}
                                    {product?.sku && <Badge variant="outline" className="font-mono text-xs">{product.sku}</Badge>}
                                  </div>
                                  <div className="text-sm text-muted-foreground mt-1 flex gap-4 flex-wrap">
                                    <span>Batch: {lot.batchDate ? new Date(lot.batchDate).toLocaleDateString() : "N/A"}</span>
                                    {lot.expirationDate && <span>Expires: {new Date(lot.expirationDate).toLocaleDateString()}</span>}
                                    <span data-testid={`text-lot-qty-${lot.id}`}>Qty: {lot.quantityRemaining}/{lot.quantityProduced}</span>
                                    {lot.costPerUnit && <span>Cost: ${(Number(lot.costPerUnit) / 100).toFixed(2)}/unit</span>}
                                  </div>
                                  {lot.notes && <p className="text-sm text-muted-foreground mt-1 italic">{lot.notes}</p>}
                                </div>
                                <div className="flex gap-2 shrink-0">
                                  <Button variant="outline" size="sm" onClick={() => startEditLot(lot)} data-testid={`button-edit-lot-${lot.id}`}>
                                    <Pencil className="mr-1 h-3 w-3" /> Edit
                                  </Button>
                                  <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => setDeleteLotDialog(lot)} data-testid={`button-delete-lot-${lot.id}`}>
                                    <Trash2 className="mr-1 h-3 w-3" /> Delete
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    {(lots || []).filter(l => lotFilterProduct === "all" || String(l.menuItemId) === lotFilterProduct).length === 0 && (
                      <Card>
                        <CardContent className="py-8 text-center text-muted-foreground">
                          <Package className="h-12 w-12 mx-auto mb-3 opacity-50" />
                          <p>No lots found. Create your first production batch above.</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </div>
              )}
            </TabsContent>

            <TabsContent value="promotions" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Promotions</h2>
                <Button onClick={() => setShowPromoForm(!showPromoForm)} data-testid="button-new-promo">
                  <Plus className="mr-2 h-4 w-4" />
                  New Promotion
                </Button>
              </div>

              {showPromoForm && (
                <Card>
                  <CardHeader>
                    <CardTitle>Create Promotion</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={promoForm.handleSubmit((data) => createPromoMutation.mutate(data))} className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="title">Title</Label>
                          <Input id="title" {...promoForm.register("title", { required: true })} data-testid="input-promo-title" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="code">Promo Code</Label>
                          <Input id="code" placeholder="SAVE10" {...promoForm.register("code")} data-testid="input-promo-code" />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" {...promoForm.register("description", { required: true })} data-testid="input-promo-desc" />
                      </div>
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="grid gap-2">
                          <Label>Discount Type</Label>
                          <Select value={promoForm.watch("discountType")} onValueChange={(v) => promoForm.setValue("discountType", v)}>
                            <SelectTrigger data-testid="select-discount-type">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="percentage">Percentage</SelectItem>
                              <SelectItem value="fixed">Fixed Amount</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="discountValue">
                            {promoForm.watch("discountType") === "percentage" ? "Discount %" : "Amount ($)"}
                          </Label>
                          <Input
                            id="discountValue"
                            type="number"
                            {...promoForm.register("discountValue", { valueAsNumber: true })}
                            data-testid="input-discount-value"
                          />
                        </div>
                        <div className="flex items-center gap-2 pt-6">
                          <Switch
                            checked={promoForm.watch("isActive")}
                            onCheckedChange={(v) => promoForm.setValue("isActive", v)}
                            data-testid="switch-active"
                          />
                          <Label>Active</Label>
                        </div>
                      </div>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="startDate">Start Date</Label>
                          <Input id="startDate" type="date" {...promoForm.register("startDate")} data-testid="input-start-date" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="endDate">End Date</Label>
                          <Input id="endDate" type="date" {...promoForm.register("endDate")} data-testid="input-end-date" />
                        </div>
                      </div>
                      <div className="flex gap-2 justify-end">
                        <Button type="button" variant="outline" onClick={() => setShowPromoForm(false)}>Cancel</Button>
                        <Button type="submit" disabled={createPromoMutation.isPending} data-testid="button-create-promo">
                          {createPromoMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                          Create
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              )}

              {promosLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <div className="space-y-3">
                  {promotions?.map((promo) => (
                    <Card key={promo.id} data-testid={`promo-card-${promo.id}`}>
                      <CardContent className="flex items-center justify-between py-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{promo.title}</span>
                            {promo.code && <Badge variant="outline">{promo.code}</Badge>}
                            <Badge variant={promo.isActive ? "default" : "secondary"}>
                              {promo.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{promo.description}</p>
                          <p className="text-sm text-muted-foreground">
                            {promo.discountType === "percentage" ? `${promo.discountValue}% off` : `$${promo.discountValue / 100} off`}
                            {" • "}
                            {new Date(promo.startDate).toLocaleDateString()} - {new Date(promo.endDate).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => deletePromoMutation.mutate(promo.id)}
                          data-testid={`button-delete-promo-${promo.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                  {promotions?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No promotions yet.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="orders" className="space-y-6">
              <div className="flex gap-2 items-center justify-between mb-4 flex-wrap">
                <div className="flex gap-2 items-center flex-1 min-w-0">
                  <Search className="h-5 w-5 text-muted-foreground shrink-0" />
                  <Input
                    placeholder="Search by reference, name, email, or phone..."
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    className="max-w-md"
                    data-testid="input-order-search"
                  />
                </div>
                {(adminRole?.isSuperAdmin || adminRole?.finance) && (
                  <Button
                    variant="outline"
                    onClick={() => setShowExportPanel(!showExportPanel)}
                    data-testid="button-toggle-export"
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Export for QuickBooks
                  </Button>
                )}
              </div>

              {showExportPanel && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Download className="h-5 w-5" />
                      Export Orders (QuickBooks CSV)
                    </CardTitle>
                    <CardDescription>
                      Download order data as a CSV file compatible with QuickBooks import.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-4 items-end">
                      <div className="space-y-1.5">
                        <Label htmlFor="export-start">Start Date</Label>
                        <Input
                          id="export-start"
                          type="date"
                          value={exportStartDate}
                          onChange={(e) => setExportStartDate(e.target.value)}
                          className="w-40"
                          data-testid="input-export-start-date"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="export-end">End Date</Label>
                        <Input
                          id="export-end"
                          type="date"
                          value={exportEndDate}
                          onChange={(e) => setExportEndDate(e.target.value)}
                          className="w-40"
                          data-testid="input-export-end-date"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="export-type">Order Type</Label>
                        <Select value={exportType} onValueChange={setExportType}>
                          <SelectTrigger className="w-36" data-testid="select-export-type">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Orders</SelectItem>
                            <SelectItem value="retail">Retail Only</SelectItem>
                            <SelectItem value="wholesale">Wholesale Only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => {
                            const params = new URLSearchParams();
                            if (exportStartDate) params.set("startDate", exportStartDate);
                            if (exportEndDate) params.set("endDate", exportEndDate);
                            if (exportType !== "all") params.set("type", exportType);
                            const url = `/api/admin/orders/export-csv${params.toString() ? `?${params}` : ""}`;
                            window.open(url, "_blank");
                          }}
                          data-testid="button-download-csv"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download CSV
                        </Button>
                        <div className="flex gap-1">
                          {[
                            { label: "30 days", days: 30 },
                            { label: "90 days", days: 90 },
                            { label: "This year", days: -1 },
                          ].map((preset) => (
                            <Button
                              key={preset.label}
                              variant="ghost"
                              size="sm"
                              className="text-xs"
                              onClick={() => {
                                const end = new Date();
                                setExportEndDate(end.toISOString().split("T")[0]);
                                if (preset.days === -1) {
                                  setExportStartDate(`${end.getFullYear()}-01-01`);
                                } else {
                                  const start = new Date();
                                  start.setDate(start.getDate() - preset.days);
                                  setExportStartDate(start.toISOString().split("T")[0]);
                                }
                              }}
                              data-testid={`button-preset-${preset.label.replace(/\s/g, "-")}`}
                            >
                              {preset.label}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-3">
                      CSV includes: date, order reference, customer details, line items, quantities, prices, discounts, delivery fees, totals, payment method, PayPal transaction ID, and order status. Import into QuickBooks via File → Import → CSV.
                    </p>
                  </CardContent>
                </Card>
              )}

              {orderSearch.length >= 2 && searchResults ? (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">Found {searchResults.length} orders matching '{orderSearch}'</p>
                  <div className="space-y-3">
                    {searchResults.map((order) => (
                      <Card key={order.id} data-testid={`search-order-${order.id}`}>
                        <CardContent className="py-4">
                          <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
                            <div>
                              <span className="font-bold text-primary mr-2">{order.orderRef || `#${order.id}`}</span>
                              <span className="font-medium">{order.customerName}</span>
                              <Badge variant="outline" className="ml-2">{order.status}</Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-primary">
                                {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(order.totalAmount / 100)}
                              </span>
                              <Button size="sm" variant="outline" onClick={() => openEditModal(order)} data-testid={`edit-search-order-${order.id}`}>
                                <Pencil className="h-3.5 w-3.5 mr-1" /> Edit
                              </Button>
                              <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => setDeleteOrderModal(order)} data-testid={`delete-search-order-${order.id}`}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">
                            {order.customerEmail} {order.customerPhone && `• ${order.customerPhone}`}
                          </div>
                          <div className="text-sm">
                            {order.items?.map((item, idx) => (
                              <span key={item.id}>
                                {item.quantity}x {item.menuItem?.name || 'Unknown'}
                                {idx < order.items.length - 1 && ', '}
                              </span>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {searchResults.length === 0 && (
                      <p className="text-center text-muted-foreground py-4">No orders found.</p>
                    )}
                  </div>
                </div>
              ) : ordersLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-semibold">Pending Orders</h2>
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100">
                        {orders?.filter(o => o.status === 'pending' || o.status === 'confirmed').length || 0}
                      </Badge>
                    </div>
                    <div className="space-y-3">
                      {orders?.filter(o => o.status === 'pending' || o.status === 'confirmed').map((order) => (
                        <Card key={order.id} className="bg-yellow-50 dark:bg-yellow-950/30" data-testid={`admin-order-${order.id}`}>
                          <CardContent className="py-4">
                            <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
                              <div>
                                <span className="font-medium">{order.orderRef || `#${order.id}`}</span>
                                <span className="text-muted-foreground ml-2">{order.customerName}</span>
                                <Badge variant="outline" className="ml-2">{order.status}</Badge>
                              </div>
                              <span className="font-bold text-primary">
                                {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(order.totalAmount / 100)}
                              </span>
                            </div>
                            <div className="text-sm text-muted-foreground mb-3">
                              {order.customerEmail} • {order.customerPhone}
                              {order.isDelivery && <span className="block mt-1">Delivery: {order.deliveryAddress}</span>}
                            </div>
                            <div className="text-sm mb-3">
                              {order.items?.map((item, idx) => (
                                <span key={item.id}>
                                  {item.quantity}x {item.menuItem?.name || 'Unknown'}
                                  {idx < order.items.length - 1 && ', '}
                                </span>
                              ))}
                            </div>
                            {order.charityDonationAmount != null && order.charityDonationAmount > 0 && (
                              <div className="mb-3">
                                <Badge variant="outline" className="bg-pink-50 text-pink-800 dark:bg-pink-950 dark:text-pink-200" data-testid={`badge-donation-${order.id}`}>
                                  <Heart className="h-3 w-3 mr-1" />
                                  Charity Donation: {formatMoney(order.charityDonationAmount)}
                                </Badge>
                              </div>
                            )}
                            <div className="flex items-center gap-2 flex-wrap">
                              <Button 
                                size="sm" 
                                onClick={() => {
                                  setCompleteOrderModal(order);
                                  setTrackingNumber(order.trackingNumber || "");
                                  setScheduledPickupDate(order.scheduledPickupDate || "");
                                  setScheduledPickupTime(order.scheduledPickupTime || "");
                                }}
                                disabled={updateOrderMutation.isPending}
                                data-testid={`complete-order-${order.id}`}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" /> Mark Complete
                              </Button>
                              <Select
                                value={order.status}
                                onValueChange={(status) => updateOrderMutation.mutate({ id: order.id, status })}
                              >
                                <SelectTrigger className="w-32" data-testid={`select-order-status-${order.id}`}>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {orderStatusOptions.map((s) => (
                                    <SelectItem key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Button size="sm" variant="outline" onClick={() => openEditModal(order)} data-testid={`edit-order-${order.id}`}>
                                <Pencil className="h-4 w-4 mr-1" /> Edit
                              </Button>
                              <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => setDeleteOrderModal(order)} data-testid={`delete-order-${order.id}`}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      {orders?.filter(o => o.status === 'pending' || o.status === 'confirmed').length === 0 && (
                        <p className="text-center text-muted-foreground py-4 bg-muted/50 rounded-lg">No pending orders</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-semibold">Completed Orders</h2>
                      <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                        {orders?.filter(o => o.status === 'completed').length || 0}
                      </Badge>
                    </div>
                    <div className="space-y-3">
                      {orders?.filter(o => o.status === 'completed').slice(0, showAllCompleted ? undefined : 10).map((order) => (
                        <Card key={order.id} className="bg-green-50 dark:bg-green-950/30" data-testid={`admin-order-completed-${order.id}`}>
                          <CardContent className="py-4">
                            <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
                              <div>
                                <span className="font-medium">{order.orderRef || `#${order.id}`}</span>
                                <span className="text-muted-foreground ml-2">{order.customerName}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-primary">
                                  {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(order.totalAmount / 100)}
                                </span>
                                <Button size="sm" variant="ghost" onClick={() => openEditModal(order)} data-testid={`edit-completed-order-${order.id}`}>
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                                <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => setDeleteOrderModal(order)} data-testid={`delete-completed-order-${order.id}`}>
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </div>
                            <div className="text-sm text-muted-foreground mb-1">
                              {order.customerEmail} • {order.customerPhone}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'N/A'} • 
                              {order.items?.map((item, idx) => (
                                <span key={item.id}>
                                  {' '}{item.quantity}x {item.menuItem?.name || 'Unknown'}
                                  {idx < order.items.length - 1 && ',' }
                                </span>
                              ))}
                            </div>
                            {order.charityDonationAmount != null && order.charityDonationAmount > 0 && (
                              <div className="mt-2">
                                <Badge variant="outline" className="bg-pink-50 text-pink-800 dark:bg-pink-950 dark:text-pink-200" data-testid={`badge-donation-completed-${order.id}`}>
                                  <Heart className="h-3 w-3 mr-1" />
                                  Charity Donation: {formatMoney(order.charityDonationAmount)}
                                </Badge>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                      {(orders?.filter(o => o.status === 'completed').length || 0) > 10 && (
                        <Button variant="outline" className="w-full" onClick={() => setShowAllCompleted(!showAllCompleted)} data-testid="button-show-all-completed">
                          {showAllCompleted ? "Show Less" : `Show All ${orders?.filter(o => o.status === 'completed').length} Completed Orders`}
                        </Button>
                      )}
                      {orders?.filter(o => o.status === 'completed').length === 0 && (
                        <p className="text-center text-muted-foreground py-4 bg-muted/50 rounded-lg">No completed orders yet</p>
                      )}
                    </div>
                  </div>

                  {orders?.filter(o => o.status === 'cancelled').length > 0 && (
                    <div className="space-y-4">
                      <h2 className="text-xl font-semibold text-muted-foreground">Cancelled Orders</h2>
                      <div className="space-y-3">
                        {orders?.filter(o => o.status === 'cancelled').map((order) => (
                          <Card key={order.id} className="bg-red-50 dark:bg-red-950/30 opacity-50" data-testid={`admin-order-cancelled-${order.id}`}>
                            <CardContent className="py-3">
                              <div className="flex items-center justify-between text-sm">
                                <span>{order.orderRef || `#${order.id}`} - {order.customerName}</span>
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">
                                    {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(order.totalAmount / 100)}
                                  </span>
                                  <Button size="sm" variant="ghost" onClick={() => openEditModal(order)} data-testid={`edit-cancelled-order-${order.id}`}>
                                    <Pencil className="h-3.5 w-3.5" />
                                  </Button>
                                  <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => setDeleteOrderModal(order)} data-testid={`delete-cancelled-order-${order.id}`}>
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </TabsContent>

            <TabsContent value="fulfillment" className="space-y-6">
              <FulfillmentTab />
            </TabsContent>

            <TabsContent value="customers" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Customers</h2>
                <Button onClick={() => setShowCreateCustomer(!showCreateCustomer)} data-testid="button-add-customer">
                  <UserPlus className="mr-2 h-4 w-4" />
                  Add Customer
                </Button>
              </div>

              {showCreateCustomer && (
                <Card>
                  <CardHeader>
                    <CardTitle>Create Customer Account</CardTitle>
                    <CardDescription>Manually create a new customer account</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="new-cust-first">First Name *</Label>
                        <Input id="new-cust-first" value={newCustomerFirst} onChange={(e) => setNewCustomerFirst(e.target.value)} data-testid="input-new-customer-first" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="new-cust-last">Last Name *</Label>
                        <Input id="new-cust-last" value={newCustomerLast} onChange={(e) => setNewCustomerLast(e.target.value)} data-testid="input-new-customer-last" />
                      </div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="new-cust-email">Email *</Label>
                        <Input id="new-cust-email" type="email" value={newCustomerEmail} onChange={(e) => setNewCustomerEmail(e.target.value)} data-testid="input-new-customer-email" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="new-cust-phone">Phone (optional)</Label>
                        <Input id="new-cust-phone" value={newCustomerPhone} onChange={(e) => setNewCustomerPhone(e.target.value)} data-testid="input-new-customer-phone" />
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => setShowCreateCustomer(false)}>Cancel</Button>
                      <Button
                        onClick={() => createCustomerMutation.mutate({
                          email: newCustomerEmail,
                          firstName: newCustomerFirst,
                          lastName: newCustomerLast,
                          phone: newCustomerPhone || undefined,
                        })}
                        disabled={createCustomerMutation.isPending || !newCustomerFirst || !newCustomerLast || !newCustomerEmail}
                        data-testid="button-save-new-customer"
                      >
                        {createCustomerMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Create Account
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {customersLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <div className="space-y-3">
                  {customers?.map((customer) => (
                    <Card key={customer.id} className={customer.accountStatus === 'frozen' ? 'border-blue-300 dark:border-blue-700 bg-blue-50/50 dark:bg-blue-950/20' : ''} data-testid={`customer-card-${customer.id}`}>
                      <CardContent className="py-4">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div>
                            <span className="font-medium">{customer.firstName} {customer.lastName}</span>
                            <span className="text-muted-foreground ml-2">{customer.email}</span>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap">
                            {customer.accountStatus === 'frozen' && (
                              <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100">
                                <Snowflake className="h-3 w-3 mr-1" /> Frozen
                              </Badge>
                            )}
                            {(!customer.accountStatus || customer.accountStatus === 'active') && (
                              <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                                <UserCheck className="h-3 w-3 mr-1" /> Active
                              </Badge>
                            )}
                            <Badge variant="outline">{customer.orderCount} orders</Badge>
                            {customer.profile?.smsOptInPromos && <Badge variant="secondary">SMS Promos</Badge>}
                            {customer.profile?.smsOptInOrders && <Badge variant="secondary">SMS Orders</Badge>}
                          </div>
                        </div>
                        {customer.profile && (
                          <p className="text-sm text-muted-foreground mt-1">
                            {customer.profile.phone && `${customer.profile.phone} • `}
                            {customer.profile.city && `${customer.profile.city}, ${customer.profile.state}`}
                          </p>
                        )}
                        <div className="flex gap-2 mt-3 flex-wrap">
                          {(!customer.accountStatus || customer.accountStatus === 'active') ? (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-blue-600 border-blue-200 hover:bg-blue-50"
                              onClick={() => freezeCustomerMutation.mutate({ id: customer.id, status: 'frozen' })}
                              disabled={freezeCustomerMutation.isPending}
                              data-testid={`freeze-customer-${customer.id}`}
                            >
                              <Snowflake className="h-3.5 w-3.5 mr-1" /> Freeze
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-600 border-green-200 hover:bg-green-50"
                              onClick={() => freezeCustomerMutation.mutate({ id: customer.id, status: 'active' })}
                              disabled={freezeCustomerMutation.isPending}
                              data-testid={`unfreeze-customer-${customer.id}`}
                            >
                              <UserCheck className="h-3.5 w-3.5 mr-1" /> Unfreeze
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                            onClick={() => {
                              if (confirm(`Permanently delete ${customer.firstName} ${customer.lastName}'s account? This cannot be undone.`)) {
                                deleteCustomerMutation.mutate(customer.id);
                              }
                            }}
                            disabled={deleteCustomerMutation.isPending}
                            data-testid={`delete-customer-${customer.id}`}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {customers?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No customers yet.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="wholesale" className="space-y-4">
              <h2 className="text-xl font-semibold">Wholesale Customers</h2>
              <p className="text-sm text-muted-foreground">Approve or manage wholesale business accounts</p>
              {wholesaleLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <div className="space-y-3">
                  {wholesaleCustomers?.map((customer) => (
                    <Card key={customer.id} data-testid={`wholesale-card-${customer.id}`}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div>
                            <CardTitle className="text-base">{customer.businessName}</CardTitle>
                            <CardDescription>
                              {customer.contactName} • {customer.email} • {customer.phone}
                            </CardDescription>
                          </div>
                          <Badge 
                            variant={customer.isApproved ? "default" : "secondary"}
                            className={customer.isApproved ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" : ""}
                          >
                            {customer.isApproved ? (
                              <><CheckCircle className="h-3 w-3 mr-1" /> Approved</>
                            ) : (
                              "Pending"
                            )}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm text-muted-foreground mb-3">
                          <p>{customer.address}, {customer.city}, {customer.state} {customer.zipCode}</p>
                          {customer.taxId && <p>Tax ID: {customer.taxId}</p>}
                          {customer.notes && <p className="mt-2 italic">Notes: {customer.notes}</p>}
                          {(customer.charityId || customer.donationPercentage) && (
                            <div className="flex items-center gap-2 mt-2 flex-wrap">
                              {customer.charityId && (
                                <Badge variant="outline" className="bg-pink-50 text-pink-800 dark:bg-pink-950 dark:text-pink-200">
                                  <Heart className="h-3 w-3 mr-1" />
                                  {getCharityName(customer.charityId) || `Charity #${customer.charityId}`}
                                </Badge>
                              )}
                              {customer.donationPercentage != null && customer.donationPercentage > 0 && (
                                <Badge variant="secondary">{customer.donationPercentage}% donation</Badge>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2 flex-wrap">
                          {!customer.isApproved && (
                            <Button
                              size="sm"
                              onClick={() => approveWholesaleMutation.mutate({ id: customer.id, approved: true })}
                              disabled={approveWholesaleMutation.isPending}
                              data-testid={`approve-wholesale-${customer.id}`}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" /> Approve
                            </Button>
                          )}
                          {customer.isApproved && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => approveWholesaleMutation.mutate({ id: customer.id, approved: false })}
                              disabled={approveWholesaleMutation.isPending}
                              data-testid={`revoke-wholesale-${customer.id}`}
                            >
                              <XCircle className="h-4 w-4 mr-1" /> Revoke
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                            onClick={() => {
                              if (confirm(`Permanently delete ${customer.businessName}'s wholesale account?`)) {
                                deleteWholesaleMutation.mutate(customer.id);
                              }
                            }}
                            disabled={deleteWholesaleMutation.isPending}
                            data-testid={`delete-wholesale-${customer.id}`}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {wholesaleCustomers?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No wholesale applications yet.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="inquiries" className="space-y-4">
              <h2 className="text-xl font-semibold">Contact Inquiries</h2>
              <p className="text-sm text-muted-foreground">Inquiries are sent to ordersfrancos@gmail.com</p>
              {inquiriesLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <div className="space-y-3">
                  {inquiries?.map((inquiry) => (
                    <Card key={inquiry.id} data-testid={`inquiry-card-${inquiry.id}`}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">{inquiry.subject}</CardTitle>
                          <Badge variant={inquiry.status === "new" ? "default" : "secondary"}>{inquiry.status}</Badge>
                        </div>
                        <CardDescription>
                          {inquiry.name} • {inquiry.email} • {new Date(inquiry.createdAt!).toLocaleDateString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm">{inquiry.message}</p>
                      </CardContent>
                    </Card>
                  ))}
                  {inquiries?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No inquiries yet.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="charities" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Charities</h2>
                <Button onClick={() => { if (showCharityForm && !editingCharity) { resetCharityForm(); } else { resetCharityForm(); setShowCharityForm(true); } }} data-testid="button-new-charity">
                  <Plus className="mr-2 h-4 w-4" />
                  New Charity
                </Button>
              </div>

              {showCharityForm && (
                <Card>
                  <CardHeader>
                    <CardTitle>{editingCharity ? "Edit Charity" : "Create Charity"}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="charity-name">Charity Name *</Label>
                          <Input id="charity-name" value={charityName} onChange={(e) => setCharityName(e.target.value)} data-testid="input-charity-name" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="charity-ein">Tax ID (EIN)</Label>
                          <Input id="charity-ein" placeholder="XX-XXXXXXX" value={charityEin} onChange={(e) => setCharityEin(e.target.value)} data-testid="input-charity-ein" />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="charity-description">Description</Label>
                        <Textarea id="charity-description" value={charityDescription} onChange={(e) => setCharityDescription(e.target.value)} data-testid="input-charity-description" />
                      </div>
                      <div className="grid gap-2">
                        <Label className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Address</Label>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="charity-address">Street Address</Label>
                        <Input id="charity-address" placeholder="123 Main St" value={charityAddress} onChange={(e) => setCharityAddress(e.target.value)} data-testid="input-charity-address" />
                      </div>
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="grid gap-2">
                          <Label htmlFor="charity-city">City</Label>
                          <Input id="charity-city" value={charityCity} onChange={(e) => setCharityCity(e.target.value)} data-testid="input-charity-city" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="charity-state">State</Label>
                          <Input id="charity-state" placeholder="MT" value={charityState} onChange={(e) => setCharityState(e.target.value)} data-testid="input-charity-state" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="charity-zip">ZIP Code</Label>
                          <Input id="charity-zip" value={charityZipCode} onChange={(e) => setCharityZipCode(e.target.value)} data-testid="input-charity-zip" />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Contact Information</Label>
                      </div>
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="grid gap-2">
                          <Label htmlFor="charity-contact-name">Contact Name</Label>
                          <Input id="charity-contact-name" value={charityContactName} onChange={(e) => setCharityContactName(e.target.value)} data-testid="input-charity-contact-name" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="charity-contact-phone">Contact Phone</Label>
                          <Input id="charity-contact-phone" type="tel" placeholder="(555) 555-5555" value={charityContactPhone} onChange={(e) => setCharityContactPhone(e.target.value)} data-testid="input-charity-contact-phone" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="charity-contact-email">Contact Email</Label>
                          <Input id="charity-contact-email" type="email" value={charityContactEmail} onChange={(e) => setCharityContactEmail(e.target.value)} data-testid="input-charity-contact-email" />
                        </div>
                      </div>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="charity-website">Website</Label>
                          <Input id="charity-website" placeholder="https://..." value={charityWebsite} onChange={(e) => setCharityWebsite(e.target.value)} data-testid="input-charity-website" />
                        </div>
                        <div className="flex items-center gap-2 pt-6">
                          <Switch checked={charityActive} onCheckedChange={setCharityActive} data-testid="switch-charity-active" />
                          <Label>Active</Label>
                        </div>
                      </div>
                      <div className="flex gap-2 justify-end">
                        <Button type="button" variant="outline" onClick={resetCharityForm}>Cancel</Button>
                        <Button
                          onClick={handleCharitySubmit}
                          disabled={!charityName || createCharityMutation.isPending || updateCharityMutation.isPending}
                          data-testid="button-save-charity"
                        >
                          {(createCharityMutation.isPending || updateCharityMutation.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                          {editingCharity ? "Update" : "Create"}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {charitiesLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                <div className="space-y-3">
                  {charitiesList?.map((charity) => (
                    <Card key={charity.id} data-testid={`charity-card-${charity.id}`}>
                      <CardContent className="flex items-start justify-between py-4">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium">{charity.name}</span>
                            {charity.ein && <Badge variant="outline">EIN: {charity.ein}</Badge>}
                            <Badge variant={charity.isActive ? "default" : "secondary"}>
                              {charity.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          {charity.description && <p className="text-sm text-muted-foreground">{charity.description}</p>}
                          {((charity as any).address || (charity as any).city) && (
                            <p className="text-sm text-muted-foreground" data-testid={`text-charity-address-${charity.id}`}>
                              {(charity as any).address}{(charity as any).address && (charity as any).city ? ", " : ""}
                              {(charity as any).city}{(charity as any).state ? `, ${(charity as any).state}` : ""}{(charity as any).zipCode ? ` ${(charity as any).zipCode}` : ""}
                            </p>
                          )}
                          {((charity as any).contactName || (charity as any).contactPhone || (charity as any).contactEmail) && (
                            <p className="text-sm text-muted-foreground" data-testid={`text-charity-contact-${charity.id}`}>
                              {(charity as any).contactName && <span>{(charity as any).contactName}</span>}
                              {(charity as any).contactPhone && <span> · {(charity as any).contactPhone}</span>}
                              {(charity as any).contactEmail && <span> · {(charity as any).contactEmail}</span>}
                            </p>
                          )}
                          {charity.website && (
                            <a href={charity.website} target="_blank" rel="noopener noreferrer" className="text-sm text-primary underline" data-testid={`link-charity-website-${charity.id}`}>
                              {charity.website}
                            </a>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => startEditCharity(charity)}
                            data-testid={`button-edit-charity-${charity.id}`}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="text-destructive"
                            onClick={() => {
                              if (confirm(`Delete charity "${charity.name}"?`)) {
                                deleteCharityMutation.mutate(charity.id);
                              }
                            }}
                            data-testid={`button-delete-charity-${charity.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {charitiesList?.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No charities yet.</p>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="donations" className="space-y-6">
              <h2 className="text-xl font-semibold">Donation Analytics</h2>

              {donationsLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : donationSummary ? (
                <div className="space-y-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Top Charities by Total Donations</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {donationSummary.byCharity?.length > 0 ? (
                          <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={donationSummary.byCharity}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                              <YAxis tickFormatter={(v) => `$${(v / 100).toFixed(0)}`} />
                              <Tooltip formatter={(value: number) => formatMoney(value)} />
                              <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        ) : (
                          <p className="text-center text-muted-foreground py-8">No donation data yet.</p>
                        )}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Sales by Wholesaler City</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {donationSummary.byLocation?.length > 0 ? (
                          <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={donationSummary.byLocation}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="city" tick={{ fontSize: 12 }} />
                              <YAxis tickFormatter={(v) => `$${(v / 100).toFixed(0)}`} />
                              <Tooltip formatter={(value: number) => formatMoney(value)} />
                              <Bar dataKey="total" fill="hsl(var(--chart-2, 160 60% 45%))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        ) : (
                          <p className="text-center text-muted-foreground py-8">No sales data yet.</p>
                        )}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Top Products Generating Donations</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {donationSummary.byProduct?.length > 0 ? (
                          <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={donationSummary.byProduct}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                              <YAxis tickFormatter={(v) => `$${(v / 100).toFixed(0)}`} />
                              <Tooltip formatter={(value: number) => formatMoney(value)} />
                              <Bar dataKey="total" fill="hsl(var(--chart-3, 30 80% 55%))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        ) : (
                          <p className="text-center text-muted-foreground py-8">No product data yet.</p>
                        )}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Donation Trends Over Time</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {donationSummary.byMonth?.length > 0 ? (
                          <ResponsiveContainer width="100%" height={250}>
                            <LineChart data={donationSummary.byMonth}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                              <YAxis tickFormatter={(v) => `$${(v / 100).toFixed(0)}`} />
                              <Tooltip formatter={(value: number) => formatMoney(value)} />
                              <Line type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                            </LineChart>
                          </ResponsiveContainer>
                        ) : (
                          <p className="text-center text-muted-foreground py-8">No trend data yet.</p>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">QR Scan Monitoring</CardTitle>
                      <CardDescription>Wholesaler scan stats and conversion rates. Rows highlighted in red indicate conversion rate below 30% (potential over-scanning).</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {qrScansLoading ? (
                        <div className="flex justify-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                      ) : qrScansSummary && qrScansSummary.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm" data-testid="table-qr-scans">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 pr-4 font-medium">Business Name</th>
                                <th className="text-right py-2 px-4 font-medium">Total Scans</th>
                                <th className="text-right py-2 px-4 font-medium">Converted</th>
                                <th className="text-right py-2 pl-4 font-medium">Conversion Rate</th>
                              </tr>
                            </thead>
                            <tbody>
                              {qrScansSummary.map((row, idx) => (
                                <tr
                                  key={idx}
                                  className={`border-b ${row.conversionRate < 30 ? "bg-red-50 dark:bg-red-950/30" : ""}`}
                                  data-testid={`row-qr-scan-${idx}`}
                                >
                                  <td className="py-2 pr-4">
                                    {row.businessName}
                                    {row.conversionRate < 30 && (
                                      <Badge variant="secondary" className="ml-2 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100">
                                        <AlertCircle className="h-3 w-3 mr-1" /> Low
                                      </Badge>
                                    )}
                                  </td>
                                  <td className="text-right py-2 px-4">{row.totalScans}</td>
                                  <td className="text-right py-2 px-4">{row.convertedScans}</td>
                                  <td className="text-right py-2 pl-4 font-medium">{row.conversionRate.toFixed(1)}%</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-center text-muted-foreground py-8">No QR scan data yet.</p>
                      )}
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">No donation data available.</p>
              )}
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <h2 className="text-xl font-semibold">App Settings</h2>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PauseCircle className="h-5 w-5" />
                    Order Pause Settings
                  </CardTitle>
                  <CardDescription>
                    Temporarily pause orders with a custom message for customers.
                    Set start and end times to automatically enable/disable.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {pauseLoading ? (
                    <div className="flex justify-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                  ) : (
                    <>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="pause-enabled">Pause Orders</Label>
                          <p className="text-sm text-muted-foreground">
                            When enabled, customers will see your message and cannot place orders
                          </p>
                        </div>
                        <Switch
                          id="pause-enabled"
                          checked={pauseEnabled}
                          onCheckedChange={setPauseEnabled}
                          data-testid="switch-pause-orders"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="pause-message">Customer Message</Label>
                        <Textarea
                          id="pause-message"
                          value={pauseMessage}
                          onChange={(e) => setPauseMessage(e.target.value)}
                          placeholder="Enter a message to display to customers..."
                          className="min-h-[100px]"
                          data-testid="input-pause-message"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="pause-start">Start Time (Optional)</Label>
                          <Input
                            id="pause-start"
                            type="datetime-local"
                            value={pauseStartTime}
                            onChange={(e) => setPauseStartTime(e.target.value)}
                            data-testid="input-pause-start"
                          />
                          <p className="text-xs text-muted-foreground">
                            Leave empty to start immediately when enabled
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="pause-end">End Time (Optional)</Label>
                          <Input
                            id="pause-end"
                            type="datetime-local"
                            value={pauseEndTime}
                            onChange={(e) => setPauseEndTime(e.target.value)}
                            data-testid="input-pause-end"
                          />
                          <p className="text-xs text-muted-foreground">
                            Leave empty to stay paused until manually disabled
                          </p>
                        </div>
                      </div>

                      {pauseEnabled && (
                        <div className="p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg border border-yellow-200 dark:border-yellow-800">
                          <p className="text-sm text-yellow-800 dark:text-yellow-200">
                            <strong>Preview:</strong> {pauseMessage}
                          </p>
                          {pauseEndTime && (
                            <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
                              Orders will resume on {new Date(pauseEndTime).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}

                      <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                        <div className="space-y-0.5">
                          <Label htmlFor="notify-customers">Notify Customers</Label>
                          <p className="text-sm text-muted-foreground">
                            Send a notification to customers who opted in for order updates (via text) about this schedule change
                          </p>
                        </div>
                        <Switch
                          id="notify-customers"
                          checked={notifyCustomers}
                          onCheckedChange={setNotifyCustomers}
                          data-testid="switch-notify-customers"
                        />
                      </div>

                      <Button 
                        onClick={handleSaveOrderPause}
                        disabled={updateOrderPauseMutation.isPending}
                        data-testid="button-save-pause-settings"
                      >
                        {updateOrderPauseMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {notifyCustomers ? "Save & Notify Customers" : "Save Settings"}
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Share2 className="h-5 w-5" />
                    Social Media &amp; Meta Business Suite
                  </CardTitle>
                  <CardDescription>
                    Manage your Facebook and Instagram accounts through Meta Business Suite for marketing and promotions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {socialLoading ? (
                    <div className="flex justify-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                  ) : (
                    <>
                      <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 border border-blue-200 dark:border-blue-800">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600">
                            <SiFacebook className="h-5 w-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">Meta Business Suite</h4>
                            <p className="text-xs text-muted-foreground">Manage Facebook &amp; Instagram from one place</p>
                          </div>
                        </div>
                        <div className="grid gap-3 md:grid-cols-2 mb-3">
                          <div className="space-y-1">
                            <Label htmlFor="meta-business-id" className="text-xs">Business ID</Label>
                            <Input
                              id="meta-business-id"
                              placeholder="e.g., 114967432968753"
                              value={metaBusinessId}
                              onChange={(e) => setMetaBusinessId(e.target.value)}
                              data-testid="input-meta-business-id"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="meta-asset-id" className="text-xs">Asset / Page ID</Label>
                            <Input
                              id="meta-asset-id"
                              placeholder="e.g., 101211091246659"
                              value={metaAssetId}
                              onChange={(e) => setMetaAssetId(e.target.value)}
                              data-testid="input-meta-asset-id"
                            />
                          </div>
                        </div>
                        {metaBusinessId && metaAssetId && (
                          <a
                            href={`https://business.facebook.com/latest/home?asset_id=${metaAssetId}&business_id=${metaBusinessId}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 underline"
                            data-testid="link-meta-business-suite"
                          >
                            Open Meta Business Suite Dashboard &rarr;
                          </a>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-800">
                          <SiFacebook className="h-6 w-6 text-blue-600 flex-shrink-0 mt-0.5" />
                          <div className="flex-1 space-y-3">
                            <h4 className="font-medium text-foreground">Facebook Page</h4>
                            <div className="grid gap-3 md:grid-cols-2">
                              <div className="space-y-1">
                                <Label htmlFor="fb-url" className="text-xs">Page URL</Label>
                                <Input
                                  id="fb-url"
                                  placeholder="https://facebook.com/yourpage"
                                  value={facebookUrl}
                                  onChange={(e) => setFacebookUrl(e.target.value)}
                                  data-testid="input-facebook-url"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor="fb-page-id" className="text-xs">Page ID</Label>
                                <Input
                                  id="fb-page-id"
                                  placeholder="e.g., 101211091246659"
                                  value={facebookPageId}
                                  onChange={(e) => setFacebookPageId(e.target.value)}
                                  data-testid="input-facebook-page-id"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-start gap-3 p-4 rounded-xl bg-pink-50 dark:bg-pink-950/30 border border-pink-100 dark:border-pink-800">
                          <SiInstagram className="h-6 w-6 text-pink-600 flex-shrink-0 mt-0.5" />
                          <div className="flex-1 space-y-3">
                            <h4 className="font-medium text-foreground">Instagram</h4>
                            <div className="grid gap-3 md:grid-cols-2">
                              <div className="space-y-1">
                                <Label htmlFor="ig-url" className="text-xs">Profile URL</Label>
                                <Input
                                  id="ig-url"
                                  placeholder="https://instagram.com/yourhandle"
                                  value={instagramUrl}
                                  onChange={(e) => setInstagramUrl(e.target.value)}
                                  data-testid="input-instagram-url"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor="ig-handle" className="text-xs">Handle</Label>
                                <Input
                                  id="ig-handle"
                                  placeholder="@yourhandle"
                                  value={instagramHandle}
                                  onChange={(e) => setInstagramHandle(e.target.value)}
                                  data-testid="input-instagram-handle"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {(facebookUrl || instagramUrl || (metaBusinessId && metaAssetId)) && (
                        <div className="p-4 bg-muted/50 rounded-lg border text-sm space-y-2">
                          <p className="font-medium text-foreground">Connected Accounts:</p>
                          {metaBusinessId && metaAssetId && (
                            <p className="flex items-center gap-2">
                              <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-600"><SiFacebook className="h-3 w-3 text-white" /></span>
                              <span className="text-muted-foreground">Meta Business Suite: </span>
                              <a href={`https://business.facebook.com/latest/home?asset_id=${metaAssetId}&business_id=${metaBusinessId}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                                Business #{metaBusinessId}
                              </a>
                            </p>
                          )}
                          {facebookUrl && (
                            <p className="flex items-center gap-2">
                              <SiFacebook className="h-4 w-4 text-blue-600" />
                              <a href={facebookUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">{facebookUrl}</a>
                            </p>
                          )}
                          {instagramUrl && (
                            <p className="flex items-center gap-2">
                              <SiInstagram className="h-4 w-4 text-pink-600" />
                              <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="text-pink-600 underline">{instagramUrl}</a>
                              {instagramHandle && <span className="text-muted-foreground">({instagramHandle})</span>}
                            </p>
                          )}
                        </div>
                      )}

                      <Button
                        onClick={handleSaveSocialMedia}
                        disabled={updateSocialMediaMutation.isPending}
                        data-testid="button-save-social-media"
                      >
                        {updateSocialMediaMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Social Media Settings
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    ShipStation Shipping
                  </CardTitle>
                  <CardDescription>
                    ShipStation integration for shipping rates and label printing (USPS, UPS, and more).
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {shipStationStatusLoading ? (
                    <div className="flex justify-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                  ) : shipStationStatus?.connected ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 p-4 rounded-xl bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <div>
                          <p className="font-medium text-green-800 dark:text-green-200" data-testid="text-shipstation-connected">Connected to ShipStation</p>
                          <p className="text-sm text-green-600 dark:text-green-400">
                            {shipStationStatus.carriers.length > 0
                              ? `Carriers: ${shipStationStatus.carriers.join(", ")}`
                              : "API key is active"}
                          </p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Shipping rates and label printing are available in the Fulfillment pipeline. Manage carriers and settings in your ShipStation dashboard.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                        <AlertCircle className="h-5 w-5 text-amber-600" />
                        <div>
                          <p className="font-medium text-amber-800 dark:text-amber-200">Not Connected</p>
                          <p className="text-sm text-amber-600 dark:text-amber-400">
                            ShipStation API key is not configured or invalid.
                          </p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Add your ShipStation API Key in the environment secrets to enable shipping. Find it in ShipStation under Settings &gt; API Settings.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="team" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Team Members</h2>
                <Button onClick={() => setShowTeamForm(!showTeamForm)} data-testid="button-add-team-member">
                  <UserPlus className="mr-2 h-4 w-4" />
                  Add Member
                </Button>
              </div>

              {showTeamForm && (
                <Card>
                  <CardHeader>
                    <CardTitle>Add Team Member</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="team-name">Name</Label>
                        <Input
                          id="team-name"
                          value={teamName}
                          onChange={(e) => setTeamName(e.target.value)}
                          data-testid="input-team-name"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="team-email">Email</Label>
                        <Input
                          id="team-email"
                          type="email"
                          value={teamEmail}
                          onChange={(e) => setTeamEmail(e.target.value)}
                          data-testid="input-team-email"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-6 flex-wrap">
                      <div className="flex items-center gap-2">
                        <Switch checked={teamPermMarketing} onCheckedChange={setTeamPermMarketing} data-testid="switch-team-marketing" />
                        <Label>Marketing</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={teamPermCS} onCheckedChange={setTeamPermCS} data-testid="switch-team-cs" />
                        <Label>Customer Service</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={teamPermFinance} onCheckedChange={setTeamPermFinance} data-testid="switch-team-finance" />
                        <Label>Finance</Label>
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button type="button" variant="outline" onClick={() => setShowTeamForm(false)}>Cancel</Button>
                      <Button
                        onClick={() => createTeamMemberMutation.mutate({
                          name: teamName,
                          email: teamEmail,
                          permMarketing: teamPermMarketing,
                          permCustomerService: teamPermCS,
                          permFinance: teamPermFinance,
                          isActive: true,
                        })}
                        disabled={createTeamMemberMutation.isPending || !teamName || !teamEmail}
                        data-testid="button-save-team-member"
                      >
                        {createTeamMemberMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-3">
                {teamMembers?.map((member) => (
                  <Card key={member.id} data-testid={`team-card-${member.id}`}>
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{member.name}</span>
                          <span className="text-muted-foreground">{member.email}</span>
                          {(member as any).emailVerified ? (
                            <Badge variant="outline" className="text-green-600 border-green-600 gap-1" data-testid={`badge-verified-${member.id}`}>
                              <CheckCircle2 className="h-3 w-3" /> Verified
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-amber-600 border-amber-600 gap-1" data-testid={`badge-unverified-${member.id}`}>
                              <AlertCircle className="h-3 w-3" /> Not Verified
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          {!(member as any).emailVerified && (
                            adminVerifyId === member.id ? (
                              <div className="flex items-center gap-1">
                                <Input
                                  placeholder="Code"
                                  value={adminVerifyCode}
                                  onChange={(e) => setAdminVerifyCode(e.target.value)}
                                  maxLength={6}
                                  className="w-24 h-8 text-sm"
                                  data-testid={`input-verify-code-${member.id}`}
                                />
                                <Button
                                  size="sm"
                                  onClick={() => confirmAdminVerificationMutation.mutate({ adminUserId: member.id, code: adminVerifyCode })}
                                  disabled={adminVerifyCode.length !== 6 || confirmAdminVerificationMutation.isPending}
                                  data-testid={`button-confirm-verify-${member.id}`}
                                >
                                  {confirmAdminVerificationMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Verify"}
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => { setAdminVerifyId(null); setAdminVerifyCode(""); }}>
                                  <XCircle className="h-3 w-3" />
                                </Button>
                              </div>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => sendAdminVerificationMutation.mutate(member.id)}
                                disabled={sendAdminVerificationMutation.isPending}
                                data-testid={`button-send-verify-${member.id}`}
                              >
                                {sendAdminVerificationMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Send className="h-3 w-3 mr-1" /> Verify Email</>}
                              </Button>
                            )
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            className="text-destructive"
                            onClick={() => deleteTeamMemberMutation.mutate(member.id)}
                            data-testid={`button-delete-team-${member.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 flex-wrap">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={member.permMarketing}
                            onCheckedChange={(v) => updateTeamMemberMutation.mutate({ id: member.id, permMarketing: v })}
                            data-testid={`switch-marketing-${member.id}`}
                          />
                          <Badge variant={member.permMarketing ? "default" : "secondary"} className={member.permMarketing ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100" : ""}>
                            Marketing
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={member.permCustomerService}
                            onCheckedChange={(v) => updateTeamMemberMutation.mutate({ id: member.id, permCustomerService: v })}
                            data-testid={`switch-cs-${member.id}`}
                          />
                          <Badge variant={member.permCustomerService ? "default" : "secondary"} className={member.permCustomerService ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100" : ""}>
                            Customer Service
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={member.permFinance}
                            onCheckedChange={(v) => updateTeamMemberMutation.mutate({ id: member.id, permFinance: v })}
                            data-testid={`switch-finance-${member.id}`}
                          />
                          <Badge variant={member.permFinance ? "default" : "secondary"} className={member.permFinance ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100" : ""}>
                            Finance
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {(!teamMembers || teamMembers.length === 0) && (
                  <p className="text-center text-muted-foreground py-8">No team members yet.</p>
                )}
              </div>
            </TabsContent>
          </Tabs>
            );
          })()}
        </div>
      </main>

      <Dialog open={!!deleteProductDialog} onOpenChange={(open) => { if (!open) setDeleteProductDialog(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Delete Product
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{deleteProductDialog?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDeleteProductDialog(null)} data-testid="button-cancel-delete-product">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteProductDialog && deleteProductMutation.mutate(deleteProductDialog.id)}
              disabled={deleteProductMutation.isPending}
              data-testid="button-confirm-delete-product"
            >
              {deleteProductMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteLotDialog} onOpenChange={(open) => { if (!open) setDeleteLotDialog(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Delete Lot
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete lot "{deleteLotDialog?.lotNumber}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDeleteLotDialog(null)} data-testid="button-cancel-delete-lot">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteLotDialog && deleteLotMutation.mutate(deleteLotDialog.id)}
              disabled={deleteLotMutation.isPending}
              data-testid="button-confirm-delete-lot"
            >
              {deleteLotMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!completeOrderModal} onOpenChange={(open) => { if (!open) setCompleteOrderModal(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Complete Order #{completeOrderModal?.id}
            </DialogTitle>
            <DialogDescription>
              {completeOrderModal?.isDelivery
                ? "Enter the shipping tracking number before marking this order as complete."
                : "Enter the pickup date and time for the customer."}
            </DialogDescription>
          </DialogHeader>

          {completeOrderModal?.isDelivery ? (
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <Label htmlFor="tracking-number" className="flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Tracking Number *
                </Label>
                <Input
                  id="tracking-number"
                  placeholder="Enter tracking number"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  data-testid="input-tracking-number"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Customer: {completeOrderModal.customerName} ({completeOrderModal.customerEmail})
              </p>
              {completeOrderModal.deliveryAddress && (
                <p className="text-xs text-muted-foreground">
                  Delivery to: {completeOrderModal.deliveryAddress}
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <Label htmlFor="pickup-date" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Pickup Date *
                </Label>
                <Input
                  id="pickup-date"
                  type="date"
                  value={scheduledPickupDate}
                  onChange={(e) => setScheduledPickupDate(e.target.value)}
                  data-testid="input-pickup-date"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pickup-time" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Pickup Time *
                </Label>
                <Input
                  id="pickup-time"
                  type="time"
                  value={scheduledPickupTime}
                  onChange={(e) => setScheduledPickupTime(e.target.value)}
                  data-testid="input-pickup-time"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Customer: {completeOrderModal?.customerName} ({completeOrderModal?.customerEmail})
              </p>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setCompleteOrderModal(null)} data-testid="button-cancel-complete">
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (!completeOrderModal) return;
                updateOrderMutation.mutate({
                  id: completeOrderModal.id,
                  status: "completed",
                  ...(completeOrderModal.isDelivery
                    ? { trackingNumber }
                    : { scheduledPickupDate, scheduledPickupTime }),
                });
              }}
              disabled={
                updateOrderMutation.isPending ||
                (completeOrderModal?.isDelivery ? !trackingNumber.trim() : (!scheduledPickupDate || !scheduledPickupTime))
              }
              data-testid="button-confirm-complete"
            >
              {updateOrderMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Complete Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={!!editOrderModal} onOpenChange={(open) => { if (!open) setEditOrderModal(null); }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-5 w-5" />
              Edit Order {editOrderModal?.orderRef || `#${editOrderModal?.id}`}
            </DialogTitle>
            <DialogDescription>
              Update order details. Changes are saved immediately.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Customer Name</Label>
              <Input id="edit-name" value={editForm.customerName} onChange={(e) => setEditForm({...editForm, customerName: e.target.value})} data-testid="input-edit-customer-name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Customer Email</Label>
              <Input id="edit-email" type="email" value={editForm.customerEmail} onChange={(e) => setEditForm({...editForm, customerEmail: e.target.value})} data-testid="input-edit-customer-email" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Customer Phone</Label>
              <Input id="edit-phone" value={editForm.customerPhone} onChange={(e) => setEditForm({...editForm, customerPhone: e.target.value})} data-testid="input-edit-customer-phone" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-total">Total Amount ($)</Label>
              <Input id="edit-total" type="number" step="0.01" min="0" value={editForm.totalAmount} onChange={(e) => setEditForm({...editForm, totalAmount: e.target.value})} data-testid="input-edit-total-amount" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Order Status</Label>
              <Select value={editForm.status} onValueChange={(v) => setEditForm({...editForm, status: v})}>
                <SelectTrigger data-testid="select-edit-order-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="preparing">Preparing</SelectItem>
                  <SelectItem value="ready">Ready</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-payment-status">Payment Status</Label>
              <Select value={editForm.paymentStatus} onValueChange={(v) => setEditForm({...editForm, paymentStatus: v})}>
                <SelectTrigger data-testid="select-edit-payment-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="refunded">Refunded</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 flex items-center gap-3 pt-6">
              <Switch checked={editForm.isDelivery} onCheckedChange={(v) => setEditForm({...editForm, isDelivery: v})} data-testid="switch-edit-delivery" />
              <Label>{editForm.isDelivery ? "Delivery" : "Pickup"}</Label>
            </div>
            {editForm.isDelivery && (
              <div className="space-y-2">
                <Label htmlFor="edit-address">Delivery Address</Label>
                <Input id="edit-address" value={editForm.deliveryAddress} onChange={(e) => setEditForm({...editForm, deliveryAddress: e.target.value})} data-testid="input-edit-delivery-address" />
              </div>
            )}
            {editForm.isDelivery && (
              <div className="space-y-2">
                <Label htmlFor="edit-tracking">Tracking Number</Label>
                <Input id="edit-tracking" value={editForm.trackingNumber} onChange={(e) => setEditForm({...editForm, trackingNumber: e.target.value})} data-testid="input-edit-tracking" />
              </div>
            )}
            {!editForm.isDelivery && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="edit-pickup-date">Pickup Date</Label>
                  <Input id="edit-pickup-date" type="date" value={editForm.scheduledPickupDate} onChange={(e) => setEditForm({...editForm, scheduledPickupDate: e.target.value})} data-testid="input-edit-pickup-date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-pickup-time">Pickup Time</Label>
                  <Input id="edit-pickup-time" type="time" value={editForm.scheduledPickupTime} onChange={(e) => setEditForm({...editForm, scheduledPickupTime: e.target.value})} data-testid="input-edit-pickup-time" />
                </div>
              </>
            )}
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="edit-notes">Fulfillment Notes</Label>
              <Textarea id="edit-notes" value={editForm.fulfillmentNotes} onChange={(e) => setEditForm({...editForm, fulfillmentNotes: e.target.value})} placeholder="Internal notes about this order..." data-testid="input-edit-fulfillment-notes" />
            </div>
            {editOrderModal && (
              <div className="md:col-span-2 text-sm text-muted-foreground border-t pt-3 mt-2">
                <p>Payment Method: <span className="font-medium capitalize">{editOrderModal.paymentMethod}</span></p>
                <p>Order Items: {editOrderModal.items?.map((item, idx) => `${item.quantity}x ${item.menuItem?.name || 'Unknown'}${idx < editOrderModal.items.length - 1 ? ', ' : ''}`).join('')}</p>
                {editOrderModal.paypalOrderId && <p>PayPal Order ID: {editOrderModal.paypalOrderId}</p>}
              </div>
            )}
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setEditOrderModal(null)} data-testid="button-cancel-edit-order">Cancel</Button>
            <Button
              onClick={() => {
                if (!editOrderModal) return;
                const totalCents = Math.round(parseFloat(editForm.totalAmount) * 100);
                if (isNaN(totalCents) || totalCents < 0) {
                  toast({ title: "Invalid Amount", description: "Please enter a valid total amount.", variant: "destructive" });
                  return;
                }
                editOrderMutation.mutate({
                  id: editOrderModal.id,
                  customerName: editForm.customerName,
                  customerEmail: editForm.customerEmail,
                  customerPhone: editForm.customerPhone,
                  isDelivery: editForm.isDelivery,
                  deliveryAddress: editForm.deliveryAddress,
                  totalAmount: totalCents,
                  paymentStatus: editForm.paymentStatus,
                  status: editForm.status,
                  trackingNumber: editForm.trackingNumber,
                  scheduledPickupDate: editForm.scheduledPickupDate,
                  scheduledPickupTime: editForm.scheduledPickupTime,
                  fulfillmentNotes: editForm.fulfillmentNotes,
                });
              }}
              disabled={editOrderMutation.isPending || !editForm.customerName || !editForm.customerEmail}
              data-testid="button-save-edit-order"
            >
              {editOrderMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteOrderModal} onOpenChange={(open) => { if (!open) setDeleteOrderModal(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Delete Order
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to permanently delete order <strong>{deleteOrderModal?.orderRef || `#${deleteOrderModal?.id}`}</strong>? This action cannot be undone and will remove the order and all its items.
            </DialogDescription>
          </DialogHeader>
          {deleteOrderModal && (
            <div className="text-sm border rounded-lg p-3 bg-muted/50 space-y-1">
              <p><strong>Customer:</strong> {deleteOrderModal.customerName}</p>
              <p><strong>Total:</strong> {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(deleteOrderModal.totalAmount / 100)}</p>
              <p><strong>Status:</strong> {deleteOrderModal.status}</p>
              <p><strong>Items:</strong> {deleteOrderModal.items?.map(i => `${i.quantity}x ${i.menuItem?.name || 'Unknown'}`).join(', ')}</p>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDeleteOrderModal(null)} data-testid="button-cancel-delete-order">Cancel</Button>
            <Button
              variant="destructive"
              onClick={() => deleteOrderModal && deleteOrderMutation.mutate(deleteOrderModal.id)}
              disabled={deleteOrderMutation.isPending}
              data-testid="button-confirm-delete-order"
            >
              {deleteOrderMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
