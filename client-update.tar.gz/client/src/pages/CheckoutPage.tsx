import { useCart } from "@/lib/CartContext";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateOrder } from "@/hooks/use-orders";
import montanaBadge from "@assets/montana-badge_1772867253604.png";
import { useLocation, Link } from "wouter";
import CardCheckout from "@/components/CardCheckout";
import { useEffect, useState } from "react";
import { Calendar, MapPin, CheckCircle, AlertCircle, Loader2, CreditCard, Clock, Package, RefreshCw, Store, MessageSquare, HandHeart, Banknote } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { CustomerProfile, Charity } from "@shared/schema";
import { useOrderPauseStatus } from "@/components/OrderPauseModal";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const checkoutSchema = z.object({
  customerName: z.string().min(1, "Name is required"),
  customerEmail: z.string().email("Invalid email"),
  customerPhone: z.string().min(10, "Phone number is required"),
  streetAddress: z.string().optional(),
  secondaryAddress: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  shippingStreetAddress: z.string().optional(),
  shippingCity: z.string().optional(),
  shippingState: z.string().optional(),
  shippingZipCode: z.string().optional(),
});

type CheckoutForm = z.infer<typeof checkoutSchema>;

interface AddressValidationResult {
  valid: boolean | null;
  vacant?: boolean;
  standardizedAddress?: {
    streetAddress: string;
    secondaryAddress?: string;
    city: string;
    state: string;
    ZIPCode: string;
    ZIPPlus4?: string;
  };
  corrections?: Array<{ code: string; text: string }>;
  warnings?: string[];
  error?: string;
}

export default function CheckoutPage() {
  const { items, total, isDelivery, clearCart, hasPetTreats, hasFoodItems, shippingFee, hasAutoRenewal, deliveryFee, selectedShippingRate, petTreatPickup, appliedPromo, discountAmount } = useCart();
  const [, setLocation] = useLocation();
  const createOrder = useCreateOrder();
  const [addressValidation, setAddressValidation] = useState<AddressValidationResult | null>(null);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [isFormValid, setIsFormValid] = useState(false);
  const [smsOptIn, setSmsOptIn] = useState(false);
  const [selectedCharityId, setSelectedCharityId] = useState<string>("");
  const [isSubscribing, setIsSubscribing] = useState(false);

  const isLocalPickupOnly = !isDelivery && (!hasPetTreats || petTreatPickup);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { isPaused, isSunday, message: pauseMessage, resumeTime, startTime, closedDay } = useOrderPauseStatus();

  const { data: profile } = useQuery<CustomerProfile>({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  const { data: charities = [] } = useQuery<Charity[]>({
    queryKey: ["/api/charities"],
  });

  const validateAddressMutation = useMutation({
    mutationFn: async (data: { streetAddress: string; city: string; state: string; zipCode?: string; secondaryAddress?: string }) => {
      const response = await apiRequest("/api/validate-address", {
        method: "POST",
        body: JSON.stringify(data),
      });
      return response as unknown as AddressValidationResult;
    },
    onSuccess: (result) => {
      setAddressValidation(result);
    },
    onError: () => {
      setAddressValidation({ valid: null, error: "Could not validate address" });
    },
  });

  // Calculate default pickup date: 3 days from now
  const pickupDate = new Date();
  pickupDate.setDate(pickupDate.getDate() + 3);
  const formattedPickupDate = pickupDate.toDateString();

  const { register, handleSubmit, formState: { errors, isValid }, watch, setValue, reset, getValues, trigger } = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema),
    mode: "onChange",
    defaultValues: {
      streetAddress: "",
      secondaryAddress: "",
      city: "",
      state: "",
      zipCode: "",
      shippingStreetAddress: "",
      shippingCity: "",
      shippingState: "",
      shippingZipCode: "",
    },
  });

  useEffect(() => {
    if (user || profile) {
      reset({
        customerName: user ? `${user.firstName || ""} ${user.lastName || ""}`.trim() : "",
        customerEmail: user?.email || "",
        customerPhone: profile?.phone || "",
        streetAddress: profile?.address || "",
        secondaryAddress: "",
        city: profile?.city || "",
        state: profile?.state || "",
        zipCode: profile?.zipCode || "",
      });
      if (profile?.smsOptInOrders) {
        setSmsOptIn(true);
      }
      if (profile?.charityId && !selectedCharityId) {
        setSelectedCharityId(String(profile.charityId));
      }
    }
  }, [user, profile, reset]);

  const watchedFields = watch();

  useEffect(() => {
    const checkValidity = async () => {
      const result = await trigger();
      setIsFormValid(result);
    };
    checkValidity();
  }, [watchedFields.customerName, watchedFields.customerEmail, watchedFields.customerPhone, watchedFields.streetAddress, trigger]);

  useEffect(() => {
    if (items.length === 0 && !orderPlaced) {
      setLocation("/cart");
    }
  }, [items, setLocation, orderPlaced]);

  const handleValidateAddress = () => {
    const values = getValues();
    if (values.streetAddress && values.city && values.state) {
      setAddressValidation(null);
      validateAddressMutation.mutate({
        streetAddress: values.streetAddress,
        city: values.city,
        state: values.state,
        zipCode: values.zipCode,
        secondaryAddress: values.secondaryAddress,
      });
    }
  };

  const applyStandardizedAddress = () => {
    if (addressValidation?.standardizedAddress) {
      const addr = addressValidation.standardizedAddress;
      setValue("streetAddress", addr.streetAddress);
      setValue("city", addr.city);
      setValue("state", addr.state);
      setValue("zipCode", addr.ZIPPlus4 ? `${addr.ZIPCode}-${addr.ZIPPlus4}` : addr.ZIPCode);
      if (addr.secondaryAddress) {
        setValue("secondaryAddress", addr.secondaryAddress);
      }
    }
  };

  const buildAddresses = (data: CheckoutForm) => {
    const deliveryAddress = isDelivery && data.streetAddress
      ? `${data.streetAddress}${data.secondaryAddress ? ', ' + data.secondaryAddress : ''}, ${data.city}, ${data.state} ${data.zipCode}`
      : undefined;

    const shippingAddress = hasPetTreats && data.shippingStreetAddress
      ? `${data.shippingStreetAddress}, ${data.shippingCity}, ${data.shippingState} ${data.shippingZipCode}`
      : undefined;

    return { deliveryAddress, shippingAddress };
  };

  const buildOrderItems = () =>
    items.map(item => ({
      menuItemId: item.id,
      quantity: item.quantity,
      price: item.price,
      isCustomPizza: item.isCustomPizza || false,
      customItemName: item.isCustomPizza ? item.name : undefined,
      customItemDetails: item.isCustomPizza ? item.description : undefined,
    }));

  // One-time card payment success
  const handleCardPaymentSuccess = async (transactionId: string) => {
    toast({
      title: "Payment Successful",
      description: "Your payment was processed. Completing your order...",
    });

    const data = getValues();
    const { deliveryAddress, shippingAddress } = buildAddresses(data);

    try {
      await createOrder.mutateAsync({
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        deliveryAddress: deliveryAddress || shippingAddress,
        paymentMethod: "card",
        paypalOrderId: transactionId,
        isDelivery,
        pickupDate: pickupDate.toISOString(),
        totalAmount: total,
        smsOptIn,
        promoCode: appliedPromo?.code,
        discountAmount,
        charityId: selectedCharityId ? Number(selectedCharityId) : undefined,
        items: buildOrderItems(),
      });

      setOrderPlaced(true);
      clearCart();
    } catch (err) {
      console.error(err);
      toast({
        title: "Order Error",
        description: "Payment was successful but there was an error creating your order. Please contact us.",
        variant: "destructive",
      });
    }
  };

  const handleCardPaymentError = (error: string) => {
    toast({
      title: "Payment Failed",
      description: error,
      variant: "destructive",
    });
  };

  // Subscription card payment: charge + create CIM profile for recurring billing
  const handleSubscriptionCardPayment = async (transactionId: string, customerProfileId?: string | null, paymentProfileId?: string | null) => {
    const data = getValues();
    const { deliveryAddress, shippingAddress } = buildAddresses(data);

    try {
      await createOrder.mutateAsync({
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        deliveryAddress: deliveryAddress || shippingAddress,
        paymentMethod: "card",
        paypalOrderId: transactionId,
        isDelivery,
        pickupDate: pickupDate.toISOString(),
        totalAmount: total,
        smsOptIn,
        promoCode: appliedPromo?.code,
        discountAmount,
        charityId: selectedCharityId ? Number(selectedCharityId) : undefined,
        items: buildOrderItems(),
      });

      const petItems = items.filter(i => i.category === "pet_treats" && i.isAutoRenewal);
      if (petItems.length > 0 && shippingAddress) {
        try {
          await apiRequest("/api/pet-subscriptions", {
            method: "POST",
            body: JSON.stringify({
              customerName: data.customerName,
              customerEmail: data.customerEmail,
              customerPhone: data.customerPhone,
              shippingAddress: shippingAddress || "Local Pickup",
              items: petItems.map(i => ({ menuItemId: i.id, quantity: i.quantity })),
              totalAmount: petItems.reduce((sum, i) => sum + i.price * i.quantity, 0),
              paypalVaultId: paymentProfileId || undefined,
              paypalCustomerId: customerProfileId || undefined,
            }),
          });
        } catch (subErr) {
          console.error("Subscription creation error (non-fatal):", subErr);
        }
      }

      setOrderPlaced(true);
      clearCart();

      toast({
        title: "Subscription Active!",
        description: customerProfileId
          ? "Your card has been saved securely for monthly auto-renewal."
          : "Order placed! Note: card was not saved for auto-renewal — you may need to re-subscribe next month.",
      });
    } catch (err) {
      console.error(err);
      toast({
        title: "Order Error",
        description: "Payment was successful but there was an error creating your order. Please contact us.",
        variant: "destructive",
      });
    } finally {
      setIsSubscribing(false);
    }
  };

  const handleSubscribeAndPay = async (cardDetails: { cardNumber: string; expirationDate: string; cardCode: string }) => {
    const data = getValues();
    const valid = await trigger();
    if (!valid) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setIsSubscribing(true);

    try {
      const amountInDollars = (total / 100).toFixed(2);
      const nameParts = data.customerName.trim().split(" ");
      const firstName = nameParts[0];
      const lastName = nameParts.slice(1).join(" ") || undefined;

      const response = await fetch("/authnet/charge-and-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cardNumber: cardDetails.cardNumber,
          expirationDate: cardDetails.expirationDate,
          cardCode: cardDetails.cardCode,
          amount: amountInDollars,
          firstName,
          lastName,
          email: data.customerEmail,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Payment declined");
      }

      await handleSubscriptionCardPayment(
        result.transactionId,
        result.customerProfileId,
        result.paymentProfileId
      );
    } catch (error: any) {
      console.error("Subscription payment error:", error);
      setIsSubscribing(false);
      toast({
        title: "Payment Error",
        description: error.message || "Could not process subscription payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCashCheckout = async () => {
    const data = getValues();
    const valid = await trigger();
    if (!valid) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields before placing your order.",
        variant: "destructive",
      });
      return;
    }

    try {
      await createOrder.mutateAsync({
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        paymentMethod: "cash",
        isDelivery: false,
        pickupDate: pickupDate.toISOString(),
        totalAmount: total,
        smsOptIn,
        promoCode: appliedPromo?.code,
        discountAmount,
        charityId: selectedCharityId ? Number(selectedCharityId) : undefined,
        items: buildOrderItems(),
      });

      setOrderPlaced(true);
      clearCart();
    } catch (err) {
      console.error(err);
      toast({
        title: "Order Error",
        description: "There was an error creating your order. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  return (
    <div className="min-h-screen bg-background pb-20 flex flex-col">
      <Navigation />

      <main className="container flex-1 px-4 py-8 md:px-6 md:py-12 max-w-5xl mx-auto">
        <h1 className="mb-8 text-4xl font-bold font-display">Checkout</h1>

        {isSunday && !isPaused && (
          <Alert className="mb-6 border-blue-500 bg-blue-50 dark:bg-blue-950/30" data-testid="alert-sunday-notice">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800 dark:text-blue-200">Sunday Order</AlertTitle>
            <AlertDescription className="text-blue-700 dark:text-blue-300">
              <p>We're closed on Sundays, but you can still place your order! It will be processed on Monday and you'll be notified when it's ready via your preferred notification method (email, text, or both).</p>
            </AlertDescription>
          </Alert>
        )}

        {isPaused && (
          <Alert variant="destructive" className="mb-6 border-red-500 bg-red-50 dark:bg-red-950/30" data-testid="alert-orders-paused">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Orders Currently Paused</AlertTitle>
            <AlertDescription>
              <p className="mb-2">{pauseMessage}</p>
              <div className="flex flex-wrap gap-4 text-sm">
                {startTime && (
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    <span>Started: {new Date(startTime).toLocaleString()}</span>
                  </div>
                )}
                {resumeTime && (
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>Resumes: {new Date(resumeTime).toLocaleString()}</span>
                  </div>
                )}
              </div>
              <p className="mt-2 font-medium">You cannot place orders at this time. Please check back later.</p>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Left Column: Form */}
          <div className="space-y-8">
            <Card className="border-border/50 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">1</div>
                  Your Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="customerName">Full Name</Label>
                  <Input id="customerName" {...register("customerName")} placeholder="Jane Doe" className="rounded-xl" data-testid="input-customer-name" />
                  {errors.customerName && <p className="text-sm text-destructive">{errors.customerName.message}</p>}
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="customerEmail">Email</Label>
                  <Input id="customerEmail" type="email" {...register("customerEmail")} placeholder="jane@example.com" className="rounded-xl" data-testid="input-customer-email" />
                  {errors.customerEmail && <p className="text-sm text-destructive">{errors.customerEmail.message}</p>}
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="customerPhone">Phone Number</Label>
                  <Input id="customerPhone" type="tel" {...register("customerPhone")} placeholder="(555) 123-4567" className="rounded-xl" data-testid="input-customer-phone" />
                  {errors.customerPhone && <p className="text-sm text-destructive">{errors.customerPhone.message}</p>}
                </div>

                <div className="flex items-center justify-between rounded-xl border p-4" data-testid="checkout-sms-optin">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="h-5 w-5 text-primary shrink-0" />
                    <div>
                      <Label htmlFor="smsOptIn" className="text-sm font-medium cursor-pointer">Text me order updates</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Get confirmation and status updates via SMS</p>
                    </div>
                  </div>
                  <Switch
                    id="smsOptIn"
                    checked={smsOptIn}
                    onCheckedChange={setSmsOptIn}
                    data-testid="switch-sms-optin"
                  />
                </div>
                {smsOptIn && (
                  <p className="text-xs text-muted-foreground px-1" data-testid="text-sms-consent">
                    By opting in, you consent to receive automated text messages from Franco's Pet Store
                    at the phone number provided. Consent is not a condition of purchase. Msg frequency varies.
                    Msg & data rates may apply. Reply STOP to cancel, HELP for help.
                    View <a href="/terms" className="underline text-primary">Terms</a> & <a href="/privacy" className="underline text-primary">Privacy Policy</a>.
                  </p>
                )}

                {charities.length > 0 && (
                  <div className="space-y-3 pt-4 border-t">
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <HandHeart className="h-4 w-4 text-primary" /> Support a Charity
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Choose a charity to support with your purchase. A portion of your order will be donated on your behalf.
                    </p>
                    <Select
                      value={selectedCharityId}
                      onValueChange={(val) => setSelectedCharityId(val === "none" ? "" : val)}
                    >
                      <SelectTrigger className="rounded-xl" data-testid="select-checkout-charity">
                        <SelectValue placeholder="Select a charity (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No charity selected</SelectItem>
                        {charities.map((charity) => (
                          <SelectItem key={charity.id} value={String(charity.id)} data-testid={`charity-option-${charity.id}`}>
                            {charity.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {selectedCharityId && charities.find(c => c.id === Number(selectedCharityId)) && (
                      <div className="rounded-xl border bg-muted/50 p-3 space-y-1" data-testid="checkout-charity-details">
                        <p className="font-medium text-sm">{charities.find(c => c.id === Number(selectedCharityId))?.name}</p>
                        {charities.find(c => c.id === Number(selectedCharityId))?.description && (
                          <p className="text-xs text-muted-foreground">{charities.find(c => c.id === Number(selectedCharityId))?.description}</p>
                        )}
                        {charities.find(c => c.id === Number(selectedCharityId))?.website && (
                          <a href={charities.find(c => c.id === Number(selectedCharityId))?.website || ""} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline" data-testid="link-charity-website">
                            Learn more
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {isDelivery && (
                  <div className="space-y-4 animate-in slide-in-from-top-2 pt-4 border-t">
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <MapPin className="h-4 w-4" /> Delivery Address
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="streetAddress">Street Address</Label>
                      <Input
                        id="streetAddress"
                        {...register("streetAddress")}
                        placeholder="123 Main St"
                        className="rounded-xl"
                        data-testid="input-street-address"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="secondaryAddress">Apt, Suite, Unit (Optional)</Label>
                      <Input
                        id="secondaryAddress"
                        {...register("secondaryAddress")}
                        placeholder="Apt 4B"
                        className="rounded-xl"
                        data-testid="input-secondary-address"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="city">City</Label>
                        <Input
                          id="city"
                          {...register("city")}
                          placeholder="Glendive"
                          className="rounded-xl"
                          data-testid="input-city"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="state">State</Label>
                        <Input
                          id="state"
                          {...register("state")}
                          placeholder="MT"
                          maxLength={2}
                          className="rounded-xl uppercase"
                          data-testid="input-state"
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="zipCode">ZIP Code</Label>
                      <Input
                        id="zipCode"
                        {...register("zipCode")}
                        placeholder="59330"
                        className="rounded-xl"
                        data-testid="input-zip-code"
                      />
                    </div>

                    <div className="flex flex-col gap-3">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleValidateAddress}
                        disabled={validateAddressMutation.isPending}
                        className="w-full"
                        data-testid="button-validate-address"
                      >
                        {validateAddressMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Verifying...
                          </>
                        ) : (
                          <>
                            <MapPin className="h-4 w-4 mr-2" />
                            Verify Address
                          </>
                        )}
                      </Button>

                      {addressValidation && (
                        <div className={`p-3 rounded-lg text-sm ${
                          addressValidation.valid === true
                            ? "bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800"
                            : addressValidation.valid === false
                            ? "bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800"
                            : "bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800"
                        }`}>
                          {addressValidation.valid === true && (
                            <div className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                              <div>
                                <p className="font-medium text-green-800 dark:text-green-200">Address verified</p>
                                {addressValidation.standardizedAddress && (
                                  <div className="mt-2">
                                    <p className="text-green-700 dark:text-green-300 text-xs">Standardized address:</p>
                                    <p className="text-green-800 dark:text-green-200">
                                      {addressValidation.standardizedAddress.streetAddress}
                                      {addressValidation.standardizedAddress.secondaryAddress && `, ${addressValidation.standardizedAddress.secondaryAddress}`}
                                      <br />
                                      {addressValidation.standardizedAddress.city}, {addressValidation.standardizedAddress.state} {addressValidation.standardizedAddress.ZIPCode}
                                      {addressValidation.standardizedAddress.ZIPPlus4 && `-${addressValidation.standardizedAddress.ZIPPlus4}`}
                                    </p>
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      className="p-0 h-auto mt-1 text-green-700 dark:text-green-300 underline hover:no-underline"
                                      onClick={applyStandardizedAddress}
                                      data-testid="button-apply-standardized"
                                    >
                                      Use this address
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                          {addressValidation.valid === false && (
                            <div className="flex items-start gap-2">
                              <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 shrink-0" />
                              <div>
                                <p className="font-medium text-red-800 dark:text-red-200">Address not found</p>
                                <p className="text-red-700 dark:text-red-300 text-xs mt-1">
                                  Please check your address and try again. Delivery is only available within town limits.
                                </p>
                              </div>
                            </div>
                          )}
                          {addressValidation.valid === null && (
                            <div className="flex items-start gap-2">
                              <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 shrink-0" />
                              <p className="text-yellow-800 dark:text-yellow-200">
                                {addressValidation.error || "Could not verify address. You can still proceed with your order."}
                              </p>
                            </div>
                          )}
                          {addressValidation.vacant && (
                            <p className="text-yellow-700 dark:text-yellow-300 text-xs mt-2">
                              Note: This address appears to be vacant.
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {hasPetTreats && petTreatPickup && (
              <Card className="border-border/50 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600">
                      <Store className="h-4 w-4" />
                    </div>
                    Local Pickup (Pet Treats)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-xl bg-blue-50 dark:bg-blue-950/30 p-4 border border-blue-100 dark:border-blue-800">
                    <p className="text-sm font-medium text-foreground">Pick up at our store</p>
                    <p className="text-sm text-muted-foreground mt-1">313 S. Merrill Ave, Glendive, MT 59330</p>
                    <p className="text-xs text-muted-foreground mt-2">We'll notify you when your order is ready for pickup.</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {hasPetTreats && !petTreatPickup && (
              <Card className="border-border/50 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600">
                      <Package className="h-4 w-4" />
                    </div>
                    Shipping Address (Pet Treats)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Pet treats will be shipped to this address.
                    {hasAutoRenewal && (
                      <span className="flex items-center gap-1 mt-1 text-primary font-medium">
                        <RefreshCw className="h-3 w-3" /> Monthly auto-renewal active — Free shipping
                      </span>
                    )}
                  </p>

                  <div className="grid gap-2">
                    <Label htmlFor="shippingStreetAddress">Street Address</Label>
                    <Input
                      id="shippingStreetAddress"
                      {...register("shippingStreetAddress")}
                      placeholder="123 Main St"
                      className="rounded-xl"
                      data-testid="input-shipping-street"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="shippingCity">City</Label>
                      <Input
                        id="shippingCity"
                        {...register("shippingCity")}
                        placeholder="Glendive"
                        className="rounded-xl"
                        data-testid="input-shipping-city"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="shippingState">State</Label>
                      <Input
                        id="shippingState"
                        {...register("shippingState")}
                        placeholder="MT"
                        maxLength={2}
                        className="rounded-xl uppercase"
                        data-testid="input-shipping-state"
                      />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="shippingZipCode">ZIP Code</Label>
                    <Input
                      id="shippingZipCode"
                      {...register("shippingZipCode")}
                      placeholder="59330"
                      className="rounded-xl"
                      data-testid="input-shipping-zip"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="border-border/50 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">{hasPetTreats ? 3 : 2}</div>
                  <CreditCard className="h-4 w-4" /> Payment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-950 rounded-xl border border-emerald-100 dark:border-emerald-800">
                  <div className="h-10 w-10 rounded-lg bg-emerald-600 flex items-center justify-center">
                    <CreditCard className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-emerald-900 dark:text-emerald-100">Credit or Debit Card</p>
                    <p className="text-sm text-emerald-700 dark:text-emerald-300">Powered by Authorize.net — 256-bit SSL secured</p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-3 text-center">
                  Your card information is never stored on our servers.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Order Summary & Pay */}
          <div className="space-y-6">
            <div className="rounded-3xl bg-white p-8 shadow-xl border border-border/50 sticky top-24">
              <h3 className="text-2xl font-bold mb-6 font-display">Order Total</h3>

              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-muted-foreground">
                  <span>Items ({items.reduce((s, i) => s + i.quantity, 0)})</span>
                  <span>{formatPrice(total - deliveryFee - shippingFee)}</span>
                </div>
                {isDelivery && hasFoodItems && (
                  <div className="flex justify-between text-primary font-medium">
                    <span>Local Delivery Fee</span>
                    <span>$5.00</span>
                  </div>
                )}
                {hasPetTreats && petTreatPickup && (
                  <div className="flex justify-between font-medium">
                    <span className="flex items-center gap-1">
                      <Store className="h-3.5 w-3.5" /> Local Pickup
                    </span>
                    <span className="text-green-600">FREE</span>
                  </div>
                )}
                {hasPetTreats && !petTreatPickup && shippingFee > 0 && selectedShippingRate && (
                  <div className="space-y-1">
                    <div className="flex justify-between font-medium">
                      <span className="flex items-center gap-1">
                        <Package className="h-3.5 w-3.5" /> {selectedShippingRate.service}
                      </span>
                      <span className="text-blue-600">{formatPrice(shippingFee)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{selectedShippingRate.estimatedDays}</p>
                  </div>
                )}
                {hasPetTreats && !petTreatPickup && shippingFee === 0 && hasAutoRenewal && (
                  <div className="flex justify-between font-medium">
                    <span className="flex items-center gap-1">
                      <Package className="h-3.5 w-3.5" /> Shipping
                    </span>
                    <span className="text-green-600">FREE</span>
                  </div>
                )}
                {hasAutoRenewal && (
                  <div className="flex items-center gap-1 text-xs text-primary">
                    <RefreshCw className="h-3 w-3" />
                    <span>Monthly auto-renewal included</span>
                  </div>
                )}
                {appliedPromo && discountAmount > 0 && (
                  <div className="flex justify-between font-medium text-green-600">
                    <span className="flex items-center gap-1">
                      Discount ({appliedPromo.code})
                    </span>
                    <span>-{formatPrice(discountAmount)}</span>
                  </div>
                )}
                <div className="h-px bg-border my-4" />
                <div className="flex justify-between items-end">
                  <span className="text-xl font-bold text-foreground">Total</span>
                  <span className="text-4xl font-bold text-primary font-display">{formatPrice(total)}</span>
                </div>
              </div>

              <div className="rounded-xl bg-orange-50 p-4 mb-8 border border-orange-100">
                <div className="flex items-center gap-2 text-orange-800 mb-1">
                  <Calendar className="h-5 w-5" />
                  <span className="font-bold">Estimated Pickup/Delivery</span>
                </div>
                <p className="text-sm text-orange-700 ml-7">
                  {formattedPickupDate}
                </p>
              </div>

              <div className="space-y-4">
                {!isFormValid && (
                  <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg border border-yellow-200 dark:border-yellow-800">
                    <p className="text-sm text-yellow-800 dark:text-yellow-200">
                      Please fill in all required fields above before paying.
                    </p>
                  </div>
                )}

                {(isSubscribing || createOrder.isPending) ? (
                  <div className="flex items-center justify-center p-6">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <span className="ml-3 text-lg font-medium">
                      {isSubscribing ? "Setting up your subscription..." : "Creating your order..."}
                    </span>
                  </div>
                ) : orderPlaced ? (
                  <div className="flex items-center justify-center gap-2 p-4 bg-green-50 dark:bg-green-950 rounded-xl border border-green-200 dark:border-green-800">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      Order Placed Successfully!
                    </span>
                  </div>
                ) : isPaused ? (
                  <div className="p-4 bg-red-50 dark:bg-red-950 rounded-xl border border-red-200 dark:border-red-800 text-center">
                    <AlertCircle className="h-5 w-5 text-red-600 mx-auto mb-2" />
                    <p className="font-medium text-red-800 dark:text-red-200">
                      Orders are currently paused
                    </p>
                    <p className="text-sm text-red-600 dark:text-red-300 mt-1">
                      {resumeTime ? `Please check back after ${new Date(resumeTime).toLocaleString()}` : "Please check back later"}
                    </p>
                  </div>
                ) : isLocalPickupOnly && !hasAutoRenewal ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-800">
                      <p className="text-sm text-amber-800 dark:text-amber-200">
                        <strong>Pay at Pickup:</strong> Pay cash when you pick up your order, or use a card below.
                      </p>
                    </div>
                    <CardCheckout
                      amount={(total / 100).toFixed(2)}
                      onPaymentSuccess={handleCardPaymentSuccess}
                      onPaymentError={handleCardPaymentError}
                      disabled={!isFormValid}
                      firstName={getValues().customerName?.split(" ")[0]}
                      lastName={getValues().customerName?.split(" ").slice(1).join(" ")}
                      email={getValues().customerEmail}
                    />
                    <Button
                      type="button"
                      onClick={handleCashCheckout}
                      disabled={!isFormValid || createOrder.isPending}
                      variant="outline"
                      className="w-full rounded-xl py-5 text-base font-semibold border-2"
                      data-testid="button-cash-checkout"
                    >
                      <Banknote className="h-5 w-5 mr-2" />
                      Pay {formatPrice(total)} Cash at Pickup
                    </Button>
                  </div>
                ) : hasAutoRenewal ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-800">
                      <div className="flex items-start gap-2">
                        <RefreshCw className="h-4 w-4 mt-0.5 text-blue-600 shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                            Monthly Subscription
                          </p>
                          <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                            Your card will be saved securely for automatic monthly renewals via Authorize.net. You can cancel anytime from your profile.
                          </p>
                        </div>
                      </div>
                    </div>
                    <SubscriptionCardForm
                      amount={(total / 100).toFixed(2)}
                      disabled={!isFormValid}
                      onSubmit={handleSubscribeAndPay}
                    />
                  </div>
                ) : (
                  <CardCheckout
                    amount={(total / 100).toFixed(2)}
                    onPaymentSuccess={handleCardPaymentSuccess}
                    onPaymentError={handleCardPaymentError}
                    disabled={!isFormValid || (isDelivery && !getValues().streetAddress)}
                    firstName={getValues().customerName?.split(" ")[0]}
                    lastName={getValues().customerName?.split(" ").slice(1).join(" ")}
                    email={getValues().customerEmail}
                  />
                )}

                <p className="text-xs text-center text-muted-foreground" data-testid="text-payment-info">
                  {isLocalPickupOnly && !hasAutoRenewal
                    ? "Pay with a card or cash at pickup. Your order is confirmed immediately upon card payment."
                    : "Your card is processed securely through Authorize.net. Orders are confirmed after payment verification."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t bg-muted/30 py-12 mt-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-4xl mx-auto space-y-6 text-sm text-muted-foreground leading-relaxed">
            <div className="flex items-center justify-center">
              <img src={montanaBadge} alt="Made in Montana, USA" className="h-20 w-20 object-contain" data-testid="img-montana-badge-footer" />
            </div>
            <p className="font-semibold text-foreground">&copy; 2026 Franco's Pet Store. All Rights Reserved.</p>
            <p>
              No part of the Content may be copied, reproduced, distributed, transmitted, displayed, performed, modified, or otherwise used without the prior written permission of Franco's Pet Store, except as expressly permitted under these <Link href="/terms" className="text-primary underline hover:text-primary/80">Terms of Service</Link> and <Link href="/privacy" className="text-primary underline hover:text-primary/80">Privacy Policy</Link>.
            </p>
            <p>
              <Link href="/why-freeze-dried" className="text-primary underline hover:text-primary/80">Why Freeze-Dried?</Link>
              {" · "}
              <Link href="/environmental" className="text-primary underline hover:text-primary/80">Environmental Initiative</Link>
              {" · "}
              <Link href="/our-story" className="text-primary underline hover:text-primary/80">Our Story</Link>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Inline form component for subscriptions — collects card then calls parent handler
function SubscriptionCardForm({
  amount,
  disabled,
  onSubmit,
}: {
  amount: string;
  disabled: boolean;
  onSubmit: (card: { cardNumber: string; expirationDate: string; cardCode: string }) => Promise<void>;
}) {
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function formatCardNumber(value: string) {
    return value.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  }

  function formatExpiry(value: string) {
    const digits = value.replace(/\D/g, "").slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2);
    return digits;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (disabled || isProcessing) return;
    setError(null);

    const rawCard = cardNumber.replace(/\s/g, "");
    const [expMonth, expYear] = expiry.split("/");

    if (!rawCard || rawCard.length < 13 || !expMonth || !expYear) {
      setError("Please enter valid card details");
      return;
    }

    const expirationDate = `20${expYear.slice(-2)}-${expMonth.padStart(2, "0")}`;

    setIsProcessing(true);
    try {
      await onSubmit({ cardNumber: rawCard, expirationDate, cardCode: cvv });
    } catch (err: any) {
      setError(err.message || "Payment failed");
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-4 bg-muted/40 rounded-xl border space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <CreditCard className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Card for Monthly Billing</span>
        </div>

        <div className="space-y-1">
          <Label htmlFor="sub-cardNumber" className="text-sm">Card Number</Label>
          <Input
            id="sub-cardNumber"
            data-testid="input-sub-card-number"
            placeholder="1234 5678 9012 3456"
            value={cardNumber}
            onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
            inputMode="numeric"
            autoComplete="cc-number"
            maxLength={19}
            required
            disabled={isProcessing}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label htmlFor="sub-expiry" className="text-sm">Expiration</Label>
            <Input
              id="sub-expiry"
              data-testid="input-sub-card-expiry"
              placeholder="MM/YY"
              value={expiry}
              onChange={(e) => setExpiry(formatExpiry(e.target.value))}
              inputMode="numeric"
              autoComplete="cc-exp"
              maxLength={5}
              required
              disabled={isProcessing}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="sub-cvv" className="text-sm">CVV</Label>
            <Input
              id="sub-cvv"
              data-testid="input-sub-card-cvv"
              placeholder="123"
              value={cvv}
              onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
              inputMode="numeric"
              autoComplete="cc-csc"
              maxLength={4}
              required
              disabled={isProcessing}
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-950 rounded-lg border border-red-200 dark:border-red-800">
          <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 shrink-0" />
          <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
        </div>
      )}

      <Button
        type="submit"
        disabled={disabled || isProcessing || !cardNumber || !expiry || !cvv}
        className="w-full rounded-xl py-6 text-lg font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
        data-testid="button-subscribe-pay"
      >
        {isProcessing ? (
          <>
            <Loader2 className="h-5 w-5 mr-2 animate-spin" />
            Processing Subscription...
          </>
        ) : (
          <>
            <RefreshCw className="h-5 w-5 mr-2" />
            Subscribe & Pay ${amount}/mo
          </>
        )}
      </Button>
    </form>
  );
}
