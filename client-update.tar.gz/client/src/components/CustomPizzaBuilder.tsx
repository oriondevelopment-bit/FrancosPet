import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pizza, Plus, Info } from "lucide-react";
import { useCart } from "@/lib/CartContext";

const TOPPINGS = [
  { id: "beef", name: "Beef", price: 100 },
  { id: "italian-sausage", name: "Italian Sausage", price: 100 },
  { id: "pepperoni", name: "Pepperoni", price: 100 },
  { id: "green-peppers", name: "Green Peppers", price: 100 },
  { id: "onions", name: "Onions", price: 100 },
  { id: "olives", name: "Olives", price: 100 },
  { id: "mushrooms", name: "Mushrooms", price: 100 },
];

const BASE_PRICE = 1300;
const EXTRA_CHEESE_PRICE = 100;

export function CustomPizzaBuilder() {
  const { addCustomPizza } = useCart();
  const [selectedToppings, setSelectedToppings] = useState<string[]>([]);
  const [extraCheese, setExtraCheese] = useState(false);

  const toggleTopping = (toppingId: string) => {
    setSelectedToppings((prev) =>
      prev.includes(toppingId)
        ? prev.filter((id) => id !== toppingId)
        : [...prev, toppingId]
    );
  };

  const calculateTotal = () => {
    let total = BASE_PRICE;
    total += selectedToppings.length * 100;
    if (extraCheese) total += EXTRA_CHEESE_PRICE;
    return total;
  };

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(cents / 100);
  };

  const handleAddToCart = () => {
    const toppingNames = selectedToppings.map(
      (id) => TOPPINGS.find((t) => t.id === id)?.name || id
    );
    
    addCustomPizza({
      toppings: toppingNames,
      extraCheese,
      price: calculateTotal(),
    });
    
    setSelectedToppings([]);
    setExtraCheese(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="overflow-hidden border-2 border-primary/20 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-gray-800 dark:to-gray-900">
        <CardHeader className="bg-primary/10 pb-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <Pizza className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-2xl font-display text-gray-900 dark:text-white">Build Your Own Pizza</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                  Start at {formatPrice(BASE_PRICE)} + {formatPrice(100)} per topping
                </p>
              </div>
            </div>
            <Badge variant="secondary" className="text-lg px-4 py-1" data-testid="custom-pizza-total">
              {formatPrice(calculateTotal())}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="pt-6 space-y-6">
          <div>
            <h3 className="font-semibold mb-3 text-gray-900 dark:text-white">Choose Your Toppings</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {TOPPINGS.map((topping) => (
                <label
                  key={topping.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedToppings.includes(topping.id)
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                  data-testid={`topping-${topping.id}`}
                >
                  <Checkbox
                    checked={selectedToppings.includes(topping.id)}
                    onCheckedChange={() => toggleTopping(topping.id)}
                    data-testid={`checkbox-${topping.id}`}
                  />
                  <div className="flex-1">
                    <span className="font-medium text-gray-900 dark:text-white">{topping.name}</span>
                    <span className="text-xs text-gray-600 dark:text-gray-300 block">+{formatPrice(topping.price)}</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="border-t pt-4">
            <label
              className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                extraCheese
                  ? "border-secondary bg-secondary/10"
                  : "border-border hover:border-secondary/50"
              }`}
              data-testid="topping-extra-cheese"
            >
              <Checkbox
                checked={extraCheese}
                onCheckedChange={(checked) => setExtraCheese(checked === true)}
                data-testid="checkbox-extra-cheese"
              />
              <div className="flex-1">
                <span className="font-medium text-gray-900 dark:text-white">Extra Cheese</span>
                <span className="text-sm text-gray-600 dark:text-gray-300 block">+{formatPrice(EXTRA_CHEESE_PRICE)}</span>
              </div>
            </label>
            
            {extraCheese && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="mt-3 flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30 p-3 rounded-lg"
              >
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Extra cheese requires an additional 5 minutes cooking time.</span>
              </motion.div>
            )}
          </div>

          <div className="flex items-center justify-between pt-2">
            <div>
              <p className="text-sm text-muted-foreground">
                {selectedToppings.length} topping{selectedToppings.length !== 1 ? "s" : ""} selected
                {extraCheese && " + extra cheese"}
              </p>
            </div>
            <Button
              size="lg"
              onClick={handleAddToCart}
              className="rounded-full px-8 shadow-lg"
              data-testid="button-add-custom-pizza"
            >
              <Plus className="mr-2 h-5 w-5" />
              Add to Order
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
